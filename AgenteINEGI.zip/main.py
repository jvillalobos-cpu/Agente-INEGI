"""CLI local del proyecto INEGI Baja California.

Uso:
    python main.py setup-db
    python main.py run-etl
    python main.py query --tipo Colonia --valor "Zona Rio" [--output reporte.xlsx]
"""
import argparse
import sys
from pathlib import Path

from logger_setup import get_logger

logger = get_logger("main")


def cmd_setup_db(_args: argparse.Namespace) -> None:
    from setup_db import setup_database

    setup_database()


def cmd_run_etl(_args: argparse.Namespace) -> None:
    from etl_pipeline import run_etl

    run_etl()


def cmd_query(args: argparse.Namespace) -> None:
    from query_engine import analizar_locacion, exportar_a_excel

    output_path = Path(args.output) if args.output else None
    summary = analizar_locacion(args.tipo, args.valor)
    path = exportar_a_excel(summary, args.tipo, args.valor, output_path)
    print(f"Reporte generado: {path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Motor de consultas geográficas INEGI - Baja California")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("setup-db", help="Inicializa la base de datos y PostGIS.").set_defaults(func=cmd_setup_db)
    subparsers.add_parser("run-etl", help="Ejecuta el pipeline ETL completo.").set_defaults(func=cmd_run_etl)

    query_parser = subparsers.add_parser("query", help="Consulta una zona por Colonia o CP.")
    query_parser.add_argument("--tipo", required=True, choices=["Colonia", "CP"], help="Tipo de búsqueda.")
    query_parser.add_argument("--valor", required=True, help="Valor a buscar (nombre de colonia o código postal).")
    query_parser.add_argument("--output", required=False, help="Ruta del archivo Excel de salida.")
    query_parser.set_defaults(func=cmd_query)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        logger.error("Error ejecutando comando '%s': %s", args.command, exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
