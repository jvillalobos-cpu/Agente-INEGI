-- Fase 3: "Traductor" Colonia/CP -> AGEB.
-- Calcula, para cada intersección entre un polígono de colonia/CP y un AGEB/manzana del
-- Marco Geoestadístico, la fracción de área de la geometría censal que cae dentro del
-- polígono de búsqueda. Esa fracción se usa como peso para prorratear las variables
-- numéricas del censo cuando la colonia no coincide exactamente con los límites de AGEB.
--
-- Idempotente: DROP + CREATE de la vista materializada, sin duplicar filas base.

DROP MATERIALIZED VIEW IF EXISTS mv_colonia_ageb_interseccion;

CREATE MATERIALIZED VIEW mv_colonia_ageb_interseccion AS
SELECT
    c.id AS colonia_cp_id,
    c.colonia,
    c.cp,
    c.municipio,
    g.cve_geo,
    g.cve_ent,
    g.cve_mun,
    g.cve_loc,
    g.cve_ageb,
    -- Fracción del área del AGEB/manzana que cae dentro de la colonia/CP.
    CASE
        WHEN ST_Area(g.geom) > 0 THEN
            ST_Area(ST_Intersection(g.geom, c.geom)) / ST_Area(g.geom)
        ELSE 0
    END AS fraccion_area
FROM colonias_cp c
JOIN inegi_geometrias g
    ON ST_Intersects(c.geom, g.geom)
WHERE ST_IsValid(c.geom) AND ST_IsValid(g.geom);

CREATE INDEX IF NOT EXISTS idx_mv_interseccion_colonia
    ON mv_colonia_ageb_interseccion (colonia);
CREATE INDEX IF NOT EXISTS idx_mv_interseccion_cp
    ON mv_colonia_ageb_interseccion (cp);
CREATE INDEX IF NOT EXISTS idx_mv_interseccion_cve_geo
    ON mv_colonia_ageb_interseccion (cve_geo);

-- Refrescar tras cada carga del ETL:
-- REFRESH MATERIALIZED VIEW mv_colonia_ageb_interseccion;
