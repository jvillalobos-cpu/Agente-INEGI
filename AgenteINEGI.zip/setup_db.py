"""Fase 1: inicializa la base de datos PostgreSQL local y habilita PostGIS.

Idempotente: puede ejecutarse múltiples veces sin duplicar ni romper el esquema.
"""
from sqlalchemy import create_engine, text

from config import DATABASE_URL
from db_models import metadata
from logger_setup import get_logger

logger = get_logger("setup_db")


def setup_database() -> None:
    engine = create_engine(DATABASE_URL)
    try:
        with engine.begin() as conn:
            logger.info("Habilitando extensión PostGIS (si no existe)...")
            conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis;"))

        logger.info("Creando tablas (si no existen): inegi_geometrias, inegi_censo, colonias_cp...")
        metadata.create_all(engine, checkfirst=True)

        with engine.begin() as conn:
            logger.info("Creando índices espaciales (si no existen)...")
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS idx_inegi_geometrias_geom "
                    "ON inegi_geometrias USING GIST (geom);"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS idx_colonias_cp_geom "
                    "ON colonias_cp USING GIST (geom);"
                )
            )
            conn.execute(
                text(
                    "CREATE INDEX IF NOT EXISTS idx_inegi_censo_cve_geo "
                    "ON inegi_censo (cve_geo);"
                )
            )

        logger.info("Setup de base de datos completado exitosamente.")
    except Exception:
        logger.exception("Error durante el setup de la base de datos.")
        raise
    finally:
        engine.dispose()


if __name__ == "__main__":
    setup_database()
