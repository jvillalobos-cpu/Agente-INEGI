"""Configuración centralizada del proyecto. Todo local, sin llamadas externas."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    # python-dotenv no disponible (p. ej. modo 100% local sin acceso a pip).
    # El modo local (main_local.py) no depende de variables de .env, así que no es necesario.
    pass

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
LOG_DIR = BASE_DIR / "logs"
SQL_DIR = BASE_DIR / "sql"

# --- Mapa con tiles reales (calles, relieve) — 100% local en tiempo de ejecución ---
# Estos archivos se descargan UNA VEZ con internet (python main_local.py setup-mapa) y quedan
# guardados en disco; el servidor local (main_local.py serve) los sirve después sin ninguna
# llamada de red saliente. Si no existen, el servidor usa automáticamente el mapa SVG propio
# (sin tiles) como respaldo — nunca falla por falta de estos archivos.
STATIC_DIR = BASE_DIR / "local_engine" / "static"
TILES_DIR = DATA_DIR / "tiles"
# Debe coincidir con el --zoom-max por defecto de 'setup-mapa' (local_engine/setup_mapa.py):
# más allá de este nivel no hay tiles descargados, así que el mapa amplía el tile de este
# zoom en vez de pedir uno inexistente (si subes el zoom de la descarga, sube esto también).
TILE_MAX_ZOOM_DESCARGADO = 14

for _dir in (OUTPUT_DIR, LOG_DIR):
    _dir.mkdir(parents=True, exist_ok=True)

# --- Conexión PostgreSQL / PostGIS (credenciales vía .env) ---
PGHOST = os.getenv("PGHOST", "localhost")
PGPORT = os.getenv("PGPORT", "5432")
PGDATABASE = os.getenv("PGDATABASE", "inegi_bc")
PGUSER = os.getenv("PGUSER", "postgres")
PGPASSWORD = os.getenv("PGPASSWORD", "")

DATABASE_URL = (
    f"postgresql+psycopg2://{PGUSER}:{PGPASSWORD}@{PGHOST}:{PGPORT}/{PGDATABASE}"
)

# --- Directorios y patrones de archivos de entrada esperados ---
# Ajusta estos valores/patrones según los nombres reales de tus archivos en ./data/.
MARCO_GEOESTADISTICO_DIR = DATA_DIR / "marco_geoestadistico"
CENSO_DIR = DATA_DIR / "censo"
CP_COLONIAS_DIR = DATA_DIR / "cp_colonias"
# DENUE (Directorio Estadístico Nacional de Unidades Económicas, INEGI) — descarga por
# entidad en https://www.inegi.org.mx/app/mapa/denue/. Coloca el CSV (o el ZIP descomprimido
# tal cual, con su carpeta conjunto_de_datos/) en esta carpeta; se busca recursivamente.
DENUE_DIR = DATA_DIR / "denue"
# Índice de Marginación Urbana por AGEB, CONAPO (Consejo Nacional de Población — organismo
# oficial). Fuente pública gratuita, más cercana a un "nivel socioeconómico" oficial que
# AMAI (que es privado/comercial, sin distribución geográfica abierta). Descarga: dataset
# IMU_2020 en https://www.gob.mx/conapo/documentos/indices-de-marginacion-2020-284372 (o el
# mirror https://github.com/IndiceMx/IM_2020). Coloca un CSV con columnas
# cve_geo,poblacion,indice_marginacion,grado_marginacion,indice_normalizado en esta carpeta.
MARGINACION_DIR = DATA_DIR / "marginacion"
# ESEP (Estadística de Salud en Establecimientos Particulares, INEGI) — recursos/equipamiento
# de hospitales privados (camas, quirófanos, equipos de imagen, etc.), geocodificados a AGEB.
# Descarga: https://www.inegi.org.mx/programas/salud/. Coloca un CSV con columnas
# cve_geo,tipo_establecimiento,personal_medico,... (ver local_engine/etl_local.py) aquí.
ESEP_DIR = DATA_DIR / "esep"

# Shapefile de AGEBs (ej. 02a.shp del Marco Geoestadístico clásico, o ageb_urb.shp de SCINCE).
# Coincide con cualquier .shp en la carpeta; se asume que data/marco_geoestadistico/ solo
# contiene el shapefile de AGEB (si tiene otros, ajusta este patrón para ser más específico).
AGEB_SHAPEFILE_GLOB = "*.shp"
# Shapefile de manzanas (si se usa nivel manzana en vez de AGEB).
MANZANA_SHAPEFILE_GLOB = "*m.shp"

# CSV del Censo 2020, tabulado ITER a nivel AGEB/manzana (ej. RESAGEBURB_02CSV20.csv).
CENSO_CSV_GLOB = "*.csv"

# Shapefile o CSV de colonias/CP (ej. cp_colonias.shp o cp_colonias.csv).
CP_COLONIAS_SHAPEFILE_GLOB = "*.shp"
CP_COLONIAS_CSV_GLOB = "*.csv"
# Índice de la capa a usar dentro de un webmap de ArcGIS Online (ver local_engine/
# esri_webmap_reader.py). Por defecto apunta a la capa "SUBSECTORES INTEGRADOS" (campo UTP)
# del mapa de Carta Urbana de IMPLAN Tijuana; ajusta si usas otro webmap con otro orden de capas.
CP_COLONIAS_WEBMAP_LAYER_INDEX = 4

# --- Clave geoestadística ---
# Shapefiles del Marco Geoestadístico (columnas de atributos con prefijo CVE_).
CLAVE_COLUMNS = ["CVE_ENT", "CVE_MUN", "CVE_LOC", "CVE_AGEB"]
# CSV tabular del Censo 2020 (INEGI usa nombres cortos sin prefijo CVE_ en este archivo).
CENSO_CLAVE_COLUMNS = ["ENTIDAD", "MUN", "LOC", "AGEB"]

# --- SRID de trabajo (WGS84) ---
TARGET_SRID = 4326

# --- Entidad objetivo (Baja California) ---
CVE_ENT_BC = "02"

# --- Modo local (SQLite, sin PostgreSQL/PostGIS) ---
SQLITE_DB_PATH = BASE_DIR / "inegi_local.db"

# --- Fuente y fecha de los datos, para referencia en reportes ---
FUENTE_DATOS = "INEGI - Censo de Población y Vivienda 2020"
FECHA_DATOS = "2020"

# --- Estimación de población 15-29 / 30-59 años (INEGI NO publica este desglose a nivel
# AGEB en el Censo 2020; solo existe agregado como "15-59 años" a esa escala) ---
# Prorratea el grupo "15-59" de cada AGEB usando la proporción real 15-29 / 30-59 del
# municipio de Tijuana completo. Valores obtenidos midiendo a nivel de píxel la pirámide
# poblacional oficial de INEGI ("Panorama sociodemográfico de Baja California 2020", pág. 20,
# sección "004 TIJUANA" — INEGI no publica las cifras exactas en texto para ese gráfico,
# solo el dibujo, así que se midió el largo de cada barra contra los ejes de 0-10%):
#   15-19 (4.26%+4.10%) + 20-24 (4.67%+4.49%) + 25-29 (4.54%+4.49%) = 26.54% -> 15-29 años
#   30-34 (8.15%) + 35-39 (8.05%) + 40-44 (7.44%) + 45-49 (6.95%) + 50-54 (5.87%) + 55-59
#   (4.26%) = 40.72% -> 30-59 años
# La suma de todos los grupos midió 99.2% del 100% esperado, lo que da confianza en la
# medición (margen de error de lectura ~1 punto porcentual). Sobre población total de
# Tijuana = 1 922 523 (Censo 2020). Son ESTIMADOS por lectura visual del gráfico oficial,
# no cifras publicadas en texto por INEGI — se muestran siempre marcadas como tal.
# Para reemplazar por cifras exactas: INEGI > Censo de Población y Vivienda 2020 > Tabulados
# > "Población total por municipio según grupos quinquenales de edad" (Tijuana, Baja California).
TOTAL_15A29_MUNICIPIO: float | None = 510_300
TOTAL_30A59_MUNICIPIO: float | None = 782_900
