# Agente INEGI — Baja California

Pipeline de ETL y motor de consultas geográficas locales sobre datos del INEGI
(Marco Geoestadístico + Censo de Población y Vivienda 2020) para Tijuana/Baja California.

**100% local y privado.** No se realizan llamadas a APIs externas ni a internet. Toda la
información se procesa desde archivos locales en `./data/`.

Existen **dos modos** de ejecución:

| Modo | Cuándo usarlo | Motor DB | Librerías |
|---|---|---|---|
| **Local (stdlib)** — `main_local.py` | No puedes instalar nada (equipos restringidos/con firewall) | SQLite (incluido en Python) | Solo librería estándar de Python |
| **Completo** — `main.py` | Tienes PostgreSQL/PostGIS disponible o puedes instalarlo | PostgreSQL + PostGIS | `geopandas`, `pandas`, `openpyxl`, etc. |

---

## Modo Local (recomendado si no puedes instalar nada)

Requiere únicamente Python 3.10+ ya instalado. Nada de `pip install`.

### Datos de entrada esperados (`./data/`)

- `data/marco_geoestadistico/` — Shapefiles de AGEBs (`.shp` + `.dbf` en la misma carpeta,
  ej. `02a.shp`/`02a.dbf`) con columnas `CVE_ENT`, `CVE_MUN`, `CVE_LOC`, `CVE_AGEB`.
- `data/censo/` — CSV del Censo 2020 por AGEB urbano de INEGI. Nombre real de ejemplo:
  `conjunto_de_datos_ageb_urbana_02_cpv2020.csv` (dentro de la subcarpeta `conjunto_de_datos`
  del ZIP `ageb_mza_urbana_02_cpv2020_csv` que descargas de INEGI). Nota: este archivo usa
  claves `ENTIDAD, MUN, LOC, AGEB, MZA` (no `CVE_*`) y trae una fila por manzana más una fila
  resumen por AGEB (`MZA=000`); el ETL usa solo esa fila resumen. Las variables `P_15A29` y
  `P_30A59` del diccionario original no existen a nivel AGEB en el Censo 2020 (solo en
  microdatos) y quedan en 0.
- `data/cp_colonias/` — Shapefile (`.shp` + `.dbf`) **o GeoJSON (`.geojson`)** del catálogo
  de colonias/CP, con columnas/propiedades identificables de colonia/CP/municipio
  (`colonia`, `name`, `cp`, `postal_code`, `municipio`, etc.).

  **Si no tienes un shapefile de colonias**, la forma más simple de conseguir uno sin
  instalar nada es exportar geometría de OpenStreetMap directamente en GeoJSON desde el
  navegador:
  1. Ve a [overpass-turbo.eu](https://overpass-turbo.eu) (herramienta web gratuita).
  2. Ajusta el mapa al área de Tijuana/Baja California que te interese.
  3. Corre una consulta tipo `place=neighbourhood` o `place=suburb` (Wizard: escribe
     `place=neighbourhood in Tijuana` y da clic en "build and run query").
  4. Exporta el resultado como **GeoJSON** (botón "Export" → "download as GeoJSON").
  5. Guarda el archivo en `data/cp_colonias/colonias.geojson`.

  Nota: OSM usa coordenadas lon/lat (WGS84/EPSG:4326). Si tu shapefile de AGEB usa la
  proyección Lambert Cónica Conforme típica de INEGI (detectada automáticamente vía el
  archivo `.prj`), el ETL la reproyecta a lon/lat sin necesidad de ninguna librería SIG.

### Alternativa: capa "UTP" del webmap de IMPLAN Tijuana (sin código postal)

"Colonia" no es una unidad geoestadística oficial en México (a diferencia de AGEB), así
que no siempre hay un shapefile público de colonias descargable directamente. Como
alternativa, el mapa interactivo "Carta Urbana" de IMPLAN Tijuana
(`implan.tijuana.gob.mx`) expone sus datos como un webmap de ArcGIS Online con la
geometría embebida en un solo JSON, incluida una capa de **UTP (Unidad Territorial de
Planeación)** — el proxy más cercano a "colonia" en datos oficiales de planeación urbana.

Para obtenerlo (sin instalar nada, solo el navegador):
1. Abre la página del mapa y abre las herramientas de desarrollador (F12) → pestaña
   "Network"/"Red", filtra por "Fetch/XHR" y busca una solicitud a
   `www.arcgis.com/sharing/rest/content/items/<ID>/data?f=json`.
2. En la consola del navegador (pestaña "Console"), pega:
   ```javascript
   fetch("https://www.arcgis.com/sharing/rest/content/items/<ID>/data?f=json")
     .then(r => r.blob())
     .then(b => { const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "implan_webmap.json"; a.click(); });
   ```
   Esto descarga el JSON completo a tu carpeta de Descargas.
3. Guárdalo como `data/cp_colonias/implan_webmap.json`.
4. El ETL detecta automáticamente que es un webmap (no un GeoJSON normal), reproyecta
   sus coordenadas (Web Mercator/EPSG:3857 → lon/lat) y usa la capa configurada en
   `CP_COLONIAS_WEBMAP_LAYER_INDEX` (config.py, por defecto la capa "SUBSECTORES
   INTEGRADOS" con el campo `UTP`). Revisa el log de `run-etl`: imprime todas las capas
   disponibles con su índice, título y tipo de geometría, por si necesitas ajustar el índice.

Nota: esta capa **no incluye código postal**, solo nombre de zona (UTP) y delegación —
la búsqueda por "CP" seguirá sin resultados hasta conseguir un catálogo con esa columna.

Importante: el parser de shapefiles local **no reproyecta coordenadas** (no hay librería
de proyecciones sin instalar nada). Asegúrate de que el shapefile de AGEBs y el de
colonias/CP estén en el **mismo sistema de coordenadas**.

### Uso

```bash
python main_local.py setup-db      # crea inegi_local.db (SQLite) en la raíz del proyecto
python main_local.py run-etl       # carga shapefiles + censo, calcula asignación Colonia->AGEB
python main_local.py query --tipo Colonia --valor "Zona Rio"   # exporta CSV a ./output/
python main_local.py query --tipo AGEB --valor "0435"          # búsqueda directa por AGEB
python main_local.py serve         # levanta http://127.0.0.1:8000 con el formulario HTML
```

### Búsqueda por AGEB (disponible sin catálogo de colonias)

Si aún no tienes un shapefile de colonias/CP, puedes consultar directamente por clave de
AGEB (4 dígitos, ej. `0435`, o la clave completa de 13 dígitos `0200100010435`) usando
`--tipo AGEB`. Esto solo requiere el censo y la geometría del Marco Geoestadístico —
funciona de inmediato con los datos de INEGI/SCINCE, sin necesitar `data/cp_colonias/`.

Abre `http://127.0.0.1:8000` en tu navegador: un formulario donde escribes Colonia o
CP y ves la tabla de resultados al instante, sin salir de tu máquina.

### Simplificación del "traductor" Colonia → AGEB

La versión PostgreSQL usa `ST_Intersection` para prorratear por área. El modo local, al
no tener una librería de recorte de polígonos, asigna un AGEB a una colonia cuando el
**centroide del AGEB** cae dentro del polígono de la colonia (alternativa contemplada
en el diseño original del proyecto). Es una aproximación razonable salvo en AGEBs muy
grandes que cruzan el límite de una colonia.

---

## Modo Completo (PostgreSQL/PostGIS)

### Requisitos

- Python 3.10+, PostgreSQL con extensión PostGIS, `pip install -r requirements.txt`

### Configuración

```bash
cp .env.example .env   # ajusta credenciales de tu PostgreSQL local
```
`.env` está en `.gitignore` — nunca lo subas al repositorio.

### Datos de entrada esperados (`./data/`)

Igual que el modo local, pero `data/cp_colonias/` sí acepta CSV con columna `geometry`
en WKT (se procesa con `geopandas`).

### Uso

```bash
python main.py setup-db
psql -d <tu_base> -f sql/vista_interseccion.sql   # una sola vez
python main.py run-etl
python main.py query --tipo Colonia --valor "Zona Rio"
python main.py query --tipo CP --valor "22010" --output output/mi_reporte.xlsx
```

## Arquitectura

**Modo local:**
- `local_engine/shapefile_reader.py` / `dbf_reader.py` — parsers de `.shp`/`.dbf` en Python puro.
- `local_engine/geometry.py` — centroide y point-in-polygon en Python puro.
- `local_engine/db_sqlite.py` — esquema SQLite.
- `local_engine/etl_local.py` — ETL + Fase 3 (asignación por centroide).
- `local_engine/query_engine_local.py` — consultas + exportación a CSV.
- `local_engine/server.py` — servidor HTML dinámico (`http.server`).
- `main_local.py` — CLI del modo local.

**Modo completo:**
- `config.py` — configuración centralizada (rutas, credenciales vía `.env`, SRID).
- `db_models.py` — definición de tablas (`inegi_geometrias`, `inegi_censo`, `colonias_cp`).
- `setup_db.py` — Fase 1: inicialización de la base de datos.
- `etl_pipeline.py` — Fase 2: carga y limpieza de shapefiles y CSV del censo.
- `sql/vista_interseccion.sql` — Fase 3: vista materializada de intersección espacial
  (traductor Colonia/CP → AGEB, con prorrateo proporcional por área).
- `query_engine.py` — Fase 4: `analizar_locacion()` y exportación a Excel.
- `main.py` — CLI para orquestar todas las fases.

## Notas de robustez

- Todos los scripts son idempotentes: usan `CREATE ... IF NOT EXISTS` y `UPSERT`
  (`ON CONFLICT`), por lo que pueden ejecutarse múltiples veces sin duplicar datos.
- Los valores confidenciales de INEGI (marcados con `*`) se normalizan a `0`.
- Todo el logging se escribe en `./logs/` y en consola.
