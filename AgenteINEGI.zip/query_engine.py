"""Fase 4: Motor de consultas locales sobre PostGIS y exportación a Excel.

100% local: solo consulta la base de datos PostgreSQL local, no realiza llamadas de red.
"""
from datetime import datetime
from pathlib import Path
from typing import Literal, Optional

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config import DATABASE_URL, FECHA_DATOS, FUENTE_DATOS, OUTPUT_DIR
from etl_pipeline import NUMERIC_CENSO_COLUMNS
from logger_setup import get_logger

logger = get_logger("query_engine")

TipoBusqueda = Literal["Colonia", "CP"]

VARIABLE_LABELS = {
    "vivtot": "Total de viviendas",
    "tvivparhab": "Viviendas particulares habitadas",
    "vivpar_des": "Viviendas particulares deshabitadas",
    "vph_pisoti": "Viviendas con piso diferente de tierra",
    "vph_c_elec": "Viviendas con energía eléctrica",
    "vph_excsa": "Viviendas con servicio sanitario",
    "vph_drenaj": "Viviendas con drenaje",
    "pobtot": "Población total",
    "pobfem": "Población femenina",
    "pobmas": "Población masculina",
    "p_0a14": "Población 0-14 años",
    "p_15a29": "Población 15-29 años",
    "p_30a59": "Población 30-59 años",
    "p_60ymas": "Población 60+ años",
    "pcon_disc": "Población con discapacidad",
    "p15ym_se": "Población sin escolaridad (15+)",
    "vph_inter": "Viviendas con internet",
    "vph_autom": "Viviendas con vehículo",
    "pder_ss": "Población con afiliación a servicios de salud",
    "pder_imss": "Cobertura IMSS",
    "pder_iste": "Cobertura ISSSTE",
    "pder_segpub": "Cobertura seguro público/privado",
    "psinder": "Población sin cobertura de salud",
}

CATEGORIAS = {
    "Vivienda": ["vivtot", "tvivparhab", "vivpar_des", "vph_pisoti", "vph_c_elec", "vph_excsa", "vph_drenaj"],
    "Poblacion": ["pobtot", "pobfem", "pobmas", "p_0a14", "p_15a29", "p_30a59", "p_60ymas", "pcon_disc"],
    "Educacion_Socioeconomico": ["p15ym_se", "vph_inter", "vph_autom"],
    "Salud": ["pder_ss", "pder_imss", "pder_iste", "pder_segpub", "psinder"],
}


class ZonaNoEncontradaError(Exception):
    pass


def _sum_columns_sql() -> str:
    return ", ".join(
        f"COALESCE(SUM(ic.{col} * mv.fraccion_area), 0) AS {col}"
        for col in NUMERIC_CENSO_COLUMNS
    )


def analizar_locacion(
    tipo_busqueda: TipoBusqueda, valor_busqueda: str, engine: Optional[Engine] = None
) -> pd.DataFrame:
    """Busca una zona por Colonia o CP y devuelve un DataFrame con las métricas sumarizadas.

    Utiliza la vista materializada mv_colonia_ageb_interseccion (Fase 3) para prorratear
    proporcionalmente las variables censales según el área de intersección.
    """
    if tipo_busqueda not in ("Colonia", "CP"):
        raise ValueError("tipo_busqueda debe ser 'Colonia' o 'CP'.")

    own_engine = engine is None
    engine = engine or create_engine(DATABASE_URL)

    filtro_columna = "mv.colonia" if tipo_busqueda == "Colonia" else "mv.cp"

    query = text(
        f"""
        SELECT
            mv.colonia,
            mv.cp,
            mv.municipio,
            {_sum_columns_sql()}
        FROM mv_colonia_ageb_interseccion mv
        JOIN inegi_censo ic ON ic.cve_geo = mv.cve_geo
        WHERE {filtro_columna} ILIKE :valor
        GROUP BY mv.colonia, mv.cp, mv.municipio;
        """
    )

    try:
        logger.info("Consultando %s = '%s'...", tipo_busqueda, valor_busqueda)
        with engine.connect() as conn:
            df = pd.read_sql(query, conn, params={"valor": valor_busqueda})

        if df.empty:
            raise ZonaNoEncontradaError(
                f"No se encontraron resultados para {tipo_busqueda} = '{valor_busqueda}'."
            )

        # Agregación final (una colonia puede tener múltiples registros de CP/municipio).
        summary = df[NUMERIC_CENSO_COLUMNS].sum().to_frame(name="valor")
        summary.index.name = "variable"
        summary = summary.reset_index()
        summary["etiqueta"] = summary["variable"].map(VARIABLE_LABELS)
        summary["categoria"] = summary["variable"].apply(_categoria_de)

        logger.info("Consulta exitosa: %d variables agregadas.", len(summary))
        return summary
    except ZonaNoEncontradaError:
        logger.warning("Zona no encontrada: %s = '%s'", tipo_busqueda, valor_busqueda)
        raise
    except Exception:
        logger.exception("Error ejecutando la consulta espacial.")
        raise
    finally:
        if own_engine:
            engine.dispose()


def _categoria_de(variable: str) -> str:
    for categoria, variables in CATEGORIAS.items():
        if variable in variables:
            return categoria
    return "Otro"


def exportar_a_excel(
    summary: pd.DataFrame, tipo_busqueda: str, valor_busqueda: str, output_path: Optional[Path] = None
) -> Path:
    """Exporta el resultado de analizar_locacion a un Excel formateado."""
    if output_path is None:
        safe_valor = "".join(c if c.isalnum() else "_" for c in valor_busqueda)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = OUTPUT_DIR / f"reporte_{tipo_busqueda}_{safe_valor}_{timestamp}.xlsx"

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        meta_df = pd.DataFrame(
            {
                "Campo": ["Tipo de búsqueda", "Valor buscado", "Fuente", "Fecha de datos", "Fecha de generación"],
                "Valor": [
                    tipo_busqueda,
                    valor_busqueda,
                    FUENTE_DATOS,
                    FECHA_DATOS,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ],
            }
        )
        meta_df.to_excel(writer, sheet_name="Resumen", index=False, startrow=0)

        row_cursor = len(meta_df) + 3
        for categoria in CATEGORIAS:
            cat_df = summary[summary["categoria"] == categoria][["etiqueta", "valor"]]
            if cat_df.empty:
                continue
            cat_df.columns = ["Indicador", "Valor"]
            cat_df.to_excel(writer, sheet_name="Resumen", index=False, startrow=row_cursor)
            row_cursor += len(cat_df) + 3

        _format_excel(writer, meta_df, summary)

    logger.info("Reporte exportado a %s", output_path)
    return output_path


def _format_excel(writer: pd.ExcelWriter, meta_df: pd.DataFrame, summary: pd.DataFrame) -> None:
    ws = writer.sheets["Resumen"]

    title_font = Font(bold=True, size=14)
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")

    ws.insert_rows(1)
    ws["A1"] = "Reporte de Análisis de Locación — INEGI"
    ws["A1"].font = title_font

    for row in ws.iter_rows():
        for cell in row:
            if cell.value == "Campo" or cell.value == "Indicador":
                cell.font = header_font
                cell.fill = header_fill
            elif cell.value == "Valor":
                cell.font = header_font
                cell.fill = header_fill

    for col_idx in range(1, 3):
        ws.column_dimensions[get_column_letter(col_idx)].width = 42

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="center")
