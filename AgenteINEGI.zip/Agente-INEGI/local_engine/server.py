"""Servidor web local (http.server, incluido en Python) con formulario HTML dinámico.

Se ejecuta 100% en localhost, sin ninguna llamada de red saliente ni dependencia externa.
"""
import html
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

from local_engine.query_engine_local import (
    CATEGORIAS,
    VARIABLE_LABELS,
    ZonaNoEncontradaError,
    analizar_locacion,
    analizar_por_radio,
)
from logger_setup import get_logger

logger = get_logger("server")

PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Agente INEGI - Baja California</title>
<style>
  body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 2rem auto; padding: 0 1rem; color: #222; }}
  h1 {{ font-size: 1.4rem; }}
  form {{ display: flex; gap: 0.5rem; margin-bottom: 1.5rem; }}
  select, input[type=text] {{ padding: 0.4rem; font-size: 1rem; }}
  button {{ padding: 0.4rem 1rem; font-size: 1rem; cursor: pointer; }}
  table {{ border-collapse: collapse; width: 100%; margin-bottom: 1rem; }}
  th, td {{ border: 1px solid #ccc; padding: 0.4rem 0.6rem; text-align: left; }}
  th {{ background: #2f5496; color: white; }}
  .categoria {{ background: #eef2f8; font-weight: bold; }}
  .error {{ color: #b00020; }}
  .meta {{ color: #555; font-size: 0.9rem; margin-bottom: 1rem; }}
</style>
</head>
<body>
<h1>Agente INEGI — Consulta de Zona (Baja California)</h1>
<p class="meta">100% local — no se envía ninguna información a internet.</p>
<form method="get" action="/">
  <select name="tipo">
    <option value="Colonia" {sel_colonia}>Colonia</option>
    <option value="CP" {sel_cp}>Código Postal</option>
    <option value="AGEB" {sel_ageb}>Clave AGEB</option>
    <option value="Radio" {sel_radio}>Radio (lat,lon,km)</option>
  </select>
  <input type="text" name="valor" placeholder="Ej. Zona Rio, 22010, 0435 o 32.5048,-116.8604,1.5" value="{valor_escaped}">
  <button type="submit">Buscar</button>
</form>
<p class="meta">Radio: escribe "lat,lon,radio_km" (ej. 32.5048,-116.8604,1.5). Usa <code>python main_local.py centro --tipo Colonia --valor "..."</code> para encontrar lat/lon de una zona conocida.</p>
{resultado}
</body>
</html>
"""


def render_resultado(tipo: str, valor: str) -> str:
    if not valor:
        return ""
    n_agebs = None
    try:
        if tipo == "Radio":
            partes = [p.strip() for p in valor.split(",")]
            if len(partes) != 3:
                return '<p class="error">Formato inválido. Usa "lat,lon,radio_km" (ej. 32.5048,-116.8604,1.5).</p>'
            lat, lon, radio_km = (float(p) for p in partes)
            totals, n_agebs = analizar_por_radio(lat, lon, radio_km)
        else:
            totals = analizar_locacion(tipo, valor)
    except ZonaNoEncontradaError:
        return f'<p class="error">No se encontraron resultados para {html.escape(tipo)} = "{html.escape(valor)}".</p>'
    except ValueError:
        return '<p class="error">Formato inválido. Usa "lat,lon,radio_km" (ej. 32.5048,-116.8604,1.5).</p>'
    except Exception:
        logger.exception("Error procesando consulta web.")
        return '<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>'

    titulo_extra = f" — {n_agebs} AGEBs incluidos" if n_agebs is not None else ""
    parts = [f"<h2>Resultado: {html.escape(tipo)} = \"{html.escape(valor)}\"{titulo_extra}</h2>"]
    for categoria, variables in CATEGORIAS.items():
        parts.append(f'<table><tr><th colspan="2" class="categoria">{categoria.replace("_", " / ")}</th></tr>')
        for var in variables:
            valor_num = round(totals.get(var, 0.0), 2)
            parts.append(f"<tr><td>{html.escape(VARIABLE_LABELS[var])}</td><td>{valor_num}</td></tr>")
        parts.append("</table>")

    return "".join(parts)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.info("%s - %s", self.address_string(), format % args)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        tipo = params.get("tipo", ["Colonia"])[0]
        valor = params.get("valor", [""])[0]

        resultado_html = render_resultado(tipo, valor)
        body = PAGE_TEMPLATE.format(
            sel_colonia="selected" if tipo == "Colonia" else "",
            sel_cp="selected" if tipo == "CP" else "",
            sel_ageb="selected" if tipo == "AGEB" else "",
            sel_radio="selected" if tipo == "Radio" else "",
            valor_escaped=html.escape(valor),
            resultado=resultado_html,
        )

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))


def run_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    server = HTTPServer((host, port), Handler)
    logger.info("Servidor local iniciado en http://%s:%d (Ctrl+C para detener)", host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Servidor detenido.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_server()
