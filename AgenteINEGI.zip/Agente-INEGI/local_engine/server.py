"""Servidor web local (http.server, incluido en Python) con formulario HTML dinámico.

Se ejecuta 100% en localhost, sin ninguna llamada de red saliente ni dependencia externa.
"""
import html
import math
import re
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

from local_engine.query_engine_local import (
    CATEGORIAS,
    VARIABLE_LABELS,
    VARIABLES_NO_DISPONIBLES_AGEB,
    ZonaNoEncontradaError,
    analizar_locacion,
    analizar_por_coordenada,
    estimar_edades_15_59,
    ORDEN_CATEGORIAS_DENUE,
    ETIQUETAS_ESEP,
    contar_unidades_salud,
    estimar_nivel_socioeconomico,
    obtener_marginacion,
    obtener_recursos_hospitalarios,
    geometria_para_mapa,
)
from local_engine.svg_map import MAPA_SCRIPT, leyenda_mapa, render_mapa
from logger_setup import get_logger

logger = get_logger("server")

CATEGORIA_LABELS = {
    "Vivienda": "Vivienda",
    "Poblacion": "Población",
    "Educacion_Socioeconomico": "Educación / Socioeconómico",
    "Salud": "Salud",
}

# Paleta minimalista, un tono por categoría (accesible en fondo claro y oscuro).
CATEGORIA_COLOR = {
    "Vivienda": "#2f6f4f",
    "Poblacion": "#2f5496",
    "Educacion_Socioeconomico": "#9a6b1a",
    "Salud": "#9a3b52",
}

DONUT_PALETTE = ["#2f5496", "#c0392b", "#2f6f4f", "#9a6b1a", "#6b6f76"]
DONUT_GRIS = "#c7cbd1"

PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI - Baja California</title>
<style>
  :root {{
    --bg: #f7f8fa;
    --surface: #ffffff;
    --border: #e3e6ea;
    --text: #1c1f24;
    --text-muted: #6b7280;
    --accent: #2f5496;
    --accent-soft: #eaf0fb;
    --error: #b3261e;
    --radius: 10px;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    max-width: 960px; margin: 0 auto; padding: 2.5rem 1.5rem 4rem;
    color: var(--text); background: var(--bg); line-height: 1.5;
  }}
  h1 {{ font-size: 1.5rem; font-weight: 600; margin: 0 0 0.25rem; letter-spacing: -0.01em; }}
  h2 {{ font-size: 1.15rem; font-weight: 600; margin: 0; }}
  .subtitle {{ color: var(--text-muted); font-size: 0.9rem; margin: 0 0 1.75rem; }}
  form.search {{
    display: flex; gap: 0.6rem; margin-bottom: 0.6rem; flex-wrap: wrap;
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 0.9rem; align-items: center;
  }}
  select, input[type=text] {{
    padding: 0.5rem 0.65rem; font-size: 0.95rem; border: 1px solid var(--border);
    border-radius: 6px; background: var(--surface); color: var(--text);
  }}
  input[type=text] {{ flex: 1; min-width: 160px; }}
  input[name=radio] {{ flex: 0 0 130px; min-width: 0; }}
  button {{
    padding: 0.55rem 1.1rem; font-size: 0.95rem; font-weight: 600; cursor: pointer;
    background: var(--accent); color: #fff; border: none; border-radius: 6px;
  }}
  button:hover {{ opacity: 0.92; }}
  button.secondary {{ background: var(--accent-soft); color: var(--accent); }}
  .hint {{ color: var(--text-muted); font-size: 0.82rem; margin: 0.6rem 0 2rem; }}
  .error {{
    color: var(--error); background: #fdecea; border: 1px solid #f5c6c2;
    border-radius: var(--radius); padding: 0.8rem 1rem; font-size: 0.92rem;
  }}
  .result-header {{ display: flex; align-items: baseline; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem; }}
  .result-header .badge {{
    font-size: 0.78rem; font-weight: 600; color: var(--accent); background: var(--accent-soft);
    padding: 0.25rem 0.6rem; border-radius: 999px; white-space: nowrap;
  }}
  .zonas-box {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 0.9rem 1rem; margin: 0.75rem 0 1.5rem;
  }}
  .zonas-box p {{ color: var(--text-muted); font-size: 0.85rem; margin: 0 0 0.7rem; }}
  .zonas-list {{ display: flex; flex-direction: column; gap: 0.45rem; max-height: 220px; overflow-y: auto; margin-bottom: 0.8rem; }}
  .zona-item {{ display: flex; align-items: flex-start; gap: 0.5rem; font-size: 0.84rem; }}
  .zona-item input {{ margin-top: 0.2rem; }}
  .zona-item .zona-cp {{ color: var(--text-muted); font-weight: 600; white-space: nowrap; }}
  .zonas-actions {{ display: flex; gap: 0.5rem; }}
  .zonas-actions button {{ font-size: 0.8rem; padding: 0.4rem 0.8rem; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }}
  .card {{
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 1.1rem 1.2rem 1.25rem; position: relative;
  }}
  .card-head {{
    display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;
    margin: 0 0 0.9rem; padding-bottom: 0.6rem; border-bottom: 1px solid var(--border); position: relative;
  }}
  .card-head h3 {{ font-size: 0.95rem; font-weight: 600; margin: 0; display: flex; align-items: center; gap: 0.5rem; }}
  .card-head .dot {{ width: 0.6rem; height: 0.6rem; border-radius: 50%; display: inline-block; flex: none; }}
  .chart-toggle summary {{
    list-style: none; cursor: pointer; font-size: 0.75rem; font-weight: 600; color: var(--accent);
    background: var(--accent-soft); padding: 0.3rem 0.65rem; border-radius: 999px; white-space: nowrap;
  }}
  .chart-toggle summary::-webkit-details-marker {{ display: none; }}
  .chart-panel {{
    position: absolute; top: calc(100% + 0.4rem); right: 0; z-index: 5; width: 270px;
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 1rem; box-shadow: 0 10px 28px rgba(0,0,0,0.16);
  }}
  .chart-panel .donut-row {{ display: flex; align-items: center; gap: 0.9rem; margin-bottom: 0.6rem; }}
  .chart-panel .donut-title {{ font-size: 0.78rem; font-weight: 600; color: var(--text-muted); margin: 0 0 0.5rem; }}
  .chart-panel .legend {{ font-size: 0.78rem; display: flex; flex-direction: column; gap: 0.3rem; }}
  .chart-panel .legend-item {{ display: flex; align-items: center; gap: 0.4rem; }}
  .chart-panel .legend-dot {{ width: 0.55rem; height: 0.55rem; border-radius: 50%; flex: none; }}
  .chart-panel .legend-val {{ margin-left: auto; font-weight: 600; }}
  .chart-panel .chart-note {{ font-size: 0.72rem; color: var(--text-muted); margin: 0.6rem 0 0; border-top: 1px solid var(--border); padding-top: 0.5rem; }}
  .bar-row-inline {{ margin-bottom: 0.65rem; }}
  .bar-row-inline .bar-top {{ display: flex; justify-content: space-between; align-items: baseline; gap: 0.5rem; margin-bottom: 0.3rem; }}
  .bar-row-inline .bar-label {{ font-size: 0.82rem; color: var(--text-muted); }}
  .bar-row-inline .bar-value {{ font-size: 0.82rem; font-weight: 600; white-space: nowrap; }}
  .bar-track {{ display: block; background: #eef0f3; border-radius: 999px; height: 7px; overflow: hidden; }}
  .bar-fill {{ display: block; height: 100%; border-radius: 999px; }}
  .bar-row-inline.na .bar-value {{ color: var(--text-muted); font-weight: 500; font-style: italic; }}
  .bar-row-inline.na .bar-track {{ background: repeating-linear-gradient(45deg, #eef0f3, #eef0f3 4px, #e2e4e8 4px, #e2e4e8 8px); }}
  .nse-box {{ margin-top: 0.9rem; padding-top: 0.9rem; border-top: 1px dashed var(--border); }}
  .nse-top {{ display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; margin-bottom: 0.3rem; }}
  .nse-badge {{ font-size: 0.72rem; font-weight: 700; padding: 0.15rem 0.55rem; border-radius: 999px; white-space: nowrap; }}
  .nse-note {{ font-size: 0.72rem; color: var(--text-muted); margin: 0.5rem 0 0; }}
  .denue-stats {{ display: flex; gap: 1.5rem; }}
  .denue-stat {{ display: flex; flex-direction: column; gap: 0.15rem; }}
  .denue-num {{ font-size: 1.35rem; font-weight: 700; color: var(--text); }}
  details.audit {{
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 0.8rem 1rem; margin-top: 0.5rem; margin-bottom: 1rem;
  }}
  summary {{ cursor: pointer; font-size: 0.88rem; font-weight: 600; color: var(--accent); }}
  .mapa-toolbar {{ display: flex; align-items: center; justify-content: space-between; gap: 0.6rem; margin-top: 0.8rem; flex-wrap: wrap; }}
  .mapa-hint {{ font-size: 0.78rem; color: var(--text-muted); }}
  .mapa-toolbar-btns {{ display: flex; gap: 0.5rem; }}
  .mapa-centrar, .mapa-completa {{ font-size: 0.78rem; padding: 0.35rem 0.75rem; }}
  .mapa-wrap {{ display: flex; justify-content: center; margin-top: 0.6rem; }}
  .mapa-wrap svg {{ max-width: 100%; height: auto; display: block; border: 1px solid var(--border); border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); touch-action: none; user-select: none; --mapa-bg: #eef2f5; }}
  .mapa-marker:focus {{ outline: none; }}
  .mapa-marker:hover .mapa-marker-halo, .mapa-marker:focus .mapa-marker-halo {{ fill: rgba(63,111,176,0.22); }}
  .mapa-leyenda {{ display: flex; flex-wrap: wrap; gap: 0.9rem; justify-content: center; margin-top: 0.7rem; font-size: 0.8rem; color: var(--text-muted); }}
  .mapa-leg-item {{ display: inline-flex; align-items: center; gap: 0.35rem; }}
  .mapa-leg-dot {{ width: 0.65rem; height: 0.65rem; border-radius: 50%; display: inline-block; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 0.75rem; font-size: 0.85rem; }}
  th, td {{ border: 1px solid var(--border); padding: 0.45rem 0.6rem; text-align: left; }}
  th {{ background: var(--bg); font-weight: 600; }}
  footer {{ margin-top: 2.5rem; color: var(--text-muted); font-size: 0.78rem; text-align: center; }}

  @media (prefers-color-scheme: dark) {{
    :root {{
      --bg: #16181d; --surface: #1f2229; --border: #2c303a; --text: #e7e9ec;
      --text-muted: #9aa1ac; --accent: #6f97e6; --accent-soft: #232c40; --error: #f28b82;
    }}
    .bar-track {{ background: #2a2e37; }}
    .bar-row-inline.na .bar-track {{ background: repeating-linear-gradient(45deg, #2a2e37, #2a2e37 4px, #232630 4px, #232630 8px); }}
    .error {{ background: #3a2222; border-color: #5c3230; }}
    .mapa-wrap svg {{ --mapa-bg: #262a33; }}
  }}
</style>
</head>
<body>
<h1>Agente INEGI — Consulta de Zona</h1>
<p class="subtitle">Baja California · Censo 2020 · 100% local, sin conexión a internet</p>
<form class="search" method="get" action="/">
  <input type="text" name="valor" placeholder="Colonia, código postal, clave AGEB o coordenadas (lat,lon)" value="{valor_escaped}">
  <input type="text" name="radio" placeholder="Radio km (opcional)" value="{radio_escaped}">
  <button type="submit">Buscar</button>
</form>
<p class="hint">Detecta automáticamente qué escribiste: nombre de colonia, código postal (5 dígitos), clave AGEB (4 caracteres, ej. 0435) o coordenadas "lat,lon" (ej. 32.5048,-116.9350). El radio (km) es opcional: si lo llenas, se agrega el censo de todos los AGEBs dentro de ese radio alrededor del centro de la zona (o del punto), en vez de solo la asignación por nombre / el AGEB exacto.</p>
{resultado}
<footer>Fuente: INEGI — Marco Geoestadístico y Censo de Población y Vivienda 2020.</footer>
</body>
</html>
"""


def _donut_svg(segments: list[tuple[str, float, str]], size: int = 100, stroke: int = 14) -> str:
    """Dona SVG (stroke-dasharray sobre un círculo) — sin JS ni librerías externas."""
    total = sum(v for _, v, _ in segments)
    r = (size - stroke) / 2
    c = 2 * math.pi * r
    cx = cy = size / 2
    parts = [
        f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" '
        f'style="transform:rotate(-90deg);flex:none;">'
        f'<circle cx="{cx}" cy="{cy}" r="{r:.2f}" fill="none" stroke="#88888022" stroke-width="{stroke}"/>'
    ]
    if total > 0:
        offset = 0.0
        for _label, value, color in segments:
            frac = value / total
            dash = frac * c
            if dash > 0:
                parts.append(
                    f'<circle cx="{cx}" cy="{cy}" r="{r:.2f}" fill="none" stroke="{color}" '
                    f'stroke-width="{stroke}" stroke-dasharray="{dash:.2f} {max(c - dash, 0):.2f}" '
                    f'stroke-dashoffset="{-offset:.2f}"/>'
                )
            offset += dash
    parts.append("</svg>")
    return "".join(parts)


def _chart_panel(titulo: str, segments: list[tuple[str, float, str]], nota: str = "") -> str:
    total = sum(v for _, v, _ in segments)
    legend = []
    for label, value, color in segments:
        pct = round((value / total) * 100, 1) if total else 0.0
        legend.append(
            '<div class="legend-item">'
            f'<span class="legend-dot" style="background:{color};"></span>'
            f'<span>{html.escape(label)}</span>'
            f'<span class="legend-val">{pct}%</span>'
            "</div>"
        )
    nota_html = f'<p class="chart-note">{html.escape(nota)}</p>' if nota else ""
    return (
        f'<p class="donut-title">{html.escape(titulo)}</p>'
        '<div class="donut-row">'
        f"{_donut_svg(segments)}"
        f'<div class="legend">{"".join(legend)}</div>'
        "</div>"
        f"{nota_html}"
    )


def _grafico_categoria(categoria: str, totals: dict[str, float]) -> str:
    g = lambda v: max(totals.get(v, 0.0), 0.0)  # noqa: E731

    if categoria == "Vivienda":
        vivtot = g("vivtot")
        habitadas, deshabitadas = g("tvivparhab"), g("vivpar_des")
        otras = max(vivtot - habitadas - deshabitadas, 0.0)
        segments = [("Habitadas", habitadas, DONUT_PALETTE[0]), ("Deshabitadas", deshabitadas, DONUT_PALETTE[1])]
        if otras > 0:
            segments.append(("Otras / sin especificar", otras, DONUT_GRIS))
        return _chart_panel("Ocupación del total de viviendas", segments)

    if categoria == "Poblacion":
        sexo = [("Mujeres", g("pobfem"), DONUT_PALETTE[0]), ("Hombres", g("pobmas"), DONUT_PALETTE[1])]
        pobtot = g("pobtot")
        p_0a14, p_60mas = g("p_0a14"), g("p_60ymas")
        resto = max(pobtot - p_0a14 - p_60mas, 0.0)
        estimado = estimar_edades_15_59(totals)
        if estimado is not None:
            edad = [
                ("0-14 años", p_0a14, DONUT_PALETTE[2]),
                ("15-29 años (estimado)", estimado["p_15a29_est"], "#5b8fd1"),
                ("30-59 años (estimado)", estimado["p_30a59_est"], "#c98f3a"),
                ("60+ años", p_60mas, DONUT_PALETTE[3]),
            ]
            nota_edad = (
                "15-29 y 30-59 son un ESTIMADO (prorrateo del grupo 15-59 real de esta zona "
                "usando la proporción municipal configurada) — no es dato oficial de INEGI a nivel AGEB."
            )
        else:
            edad = [
                ("0-14 años", p_0a14, DONUT_PALETTE[2]),
                ("60+ años", p_60mas, DONUT_PALETTE[3]),
                ("15-59 años (no publicado)", resto, DONUT_GRIS),
            ]
            nota_edad = "INEGI no publica el desglose 15-29 / 30-59 a nivel AGEB; solo existe agregado en '15-59'."
        return (
            _chart_panel("Población por sexo", sexo)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Población por edad", edad, nota=nota_edad)
        )

    if categoria == "Educacion_Socioeconomico":
        vivtot = g("vivtot") or 1.0
        pobtot = g("pobtot") or 1.0
        segments = [
            ("Con internet", g("vph_inter"), DONUT_PALETTE[0]),
            ("Sin internet", max(vivtot - g("vph_inter"), 0.0), DONUT_GRIS),
        ]
        segments2 = [
            ("Con vehículo", g("vph_autom"), DONUT_PALETTE[1]),
            ("Sin vehículo", max(vivtot - g("vph_autom"), 0.0), DONUT_GRIS),
        ]
        segments3 = [
            ("Sin escolaridad (15+)", g("p15ym_se"), DONUT_PALETTE[3]),
            ("Resto de la población", max(pobtot - g("p15ym_se"), 0.0), DONUT_GRIS),
        ]
        return (
            _chart_panel("Viviendas con internet", segments)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Viviendas con vehículo", segments2)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Población sin escolaridad (15+)", segments3)
        )

    if categoria == "Salud":
        pobtot = g("pobtot")
        cobertura = [
            ("Con cobertura de salud", g("pder_ss"), DONUT_PALETTE[0]),
            ("Sin cobertura", g("psinder"), DONUT_PALETTE[1]),
        ]
        pder_ss = g("pder_ss") or 1.0
        imss, iste, segpub = g("pder_imss"), g("pder_iste"), g("pder_segpub")
        otro = max(pder_ss - imss - iste - segpub, 0.0)
        tipo = [
            ("IMSS", imss, DONUT_PALETTE[0]),
            ("ISSSTE", iste, DONUT_PALETTE[1]),
            ("Seguro público/privado", segpub, DONUT_PALETTE[2]),
        ]
        if otro > 0:
            tipo.append(("Otro / no especificado", otro, DONUT_GRIS))
        return (
            _chart_panel("Cobertura de salud", cobertura)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Tipo de cobertura (de la población con cobertura)", tipo)
        )

    return ""


def _bar_chart(variables: list[str], totals: dict[str, float], color: str) -> str:
    """Mini gráfico de barras horizontales en HTML/CSS puro, escalado al valor máximo
    del propio segmento. Las variables no publicadas por INEGI a nivel AGEB se marcan
    aparte (barra rayada, sin valor) en vez de mostrar un 0 engañoso."""
    disponibles = [v for v in variables if v not in VARIABLES_NO_DISPONIBLES_AGEB]
    valores = {v: max(totals.get(v, 0.0), 0.0) for v in disponibles}
    maximo = max(valores.values(), default=0.0) or 1.0
    estimado = estimar_edades_15_59(totals) if any(v in VARIABLES_NO_DISPONIBLES_AGEB for v in variables) else None

    filas = []
    for var in variables:
        etiqueta = html.escape(VARIABLE_LABELS[var])
        if var in VARIABLES_NO_DISPONIBLES_AGEB:
            if estimado is not None:
                val_est = estimado[f"{var}_est"]
                filas.append(
                    '<div class="bar-row-inline na">'
                    '<div class="bar-top">'
                    f'<span class="bar-label">{etiqueta}</span>'
                    f'<span class="bar-value">≈ {val_est:,.0f} (estimado)</span>'
                    "</div>"
                    '<span class="bar-track"><span class="bar-fill" style="width:100%;"></span></span>'
                    "</div>"
                )
            else:
                filas.append(
                    '<div class="bar-row-inline na">'
                    '<div class="bar-top">'
                    f'<span class="bar-label">{etiqueta}</span>'
                    '<span class="bar-value">No publicado por INEGI a nivel AGEB</span>'
                    "</div>"
                    '<span class="bar-track"><span class="bar-fill" style="width:100%;"></span></span>'
                    "</div>"
                )
            continue
        val = valores[var]
        pct = round((val / maximo) * 100, 1)
        valor_fmt = f"{val:,.0f}"
        filas.append(
            '<div class="bar-row-inline">'
            '<div class="bar-top">'
            f'<span class="bar-label">{etiqueta}</span>'
            f'<span class="bar-value" style="color:{color};">{valor_fmt}</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct}%;background:{color};"></span></span>'
            "</div>"
        )
    return "".join(filas)


NSE_COLOR = {"Alto": "#2f6f4f", "Medio": "#6b9e3f", "Bajo": "#c98f3a", "Muy bajo": "#b3261e", "Sin referencia": "#6b7280"}


def _nse_html(totals: dict[str, float]) -> str:
    nse = estimar_nivel_socioeconomico(totals)
    if nse is None:
        return ""
    color = NSE_COLOR.get(nse["nivel"], "#6b7280")
    referencia = (
        f' Comparado contra Tijuana completa: p25={nse["p25"]}, p50={nse["p50"]}, p75={nse["p75"]}.'
        if nse["p25"] is not None else ""
    )
    return (
        '<div class="nse-box">'
        '<div class="nse-top">'
        '<span class="bar-label">Nivel socioeconómico (índice estimado, no oficial)</span>'
        f'<span class="nse-badge" style="background:{color}22;color:{color};">{html.escape(nse["nivel"])}</span>'
        "</div>"
        f'<span class="bar-track"><span class="bar-fill" style="width:{nse["indice"]}%;background:{color};"></span></span>'
        f'<p class="nse-note">Índice compuesto (0-100) propio ({nse["indice"]}), calculado localmente a partir de '
        "piso firme, drenaje, electricidad, internet, automóvil y escolaridad. La etiqueta (Alto/Medio/Bajo/Muy "
        "bajo) es POR PERCENTIL relativo a los ~683 AGEBs de Tijuana (cuartiles), no un umbral absoluto — así "
        '"Alto" siempre significa "el 25% mejor posicionado de la ciudad en este índice", nunca un estándar fijo '
        "inventado.{ref} No es la clasificación oficial de NSE de AMAI/INEGI ni un dato de DataMéxico — es un "
        "proxy 100% offline.</p>"
        "</div>"
    ).replace("{ref}", referencia)


MARGINACION_COLOR = {
    "Muy bajo": "#2f6f4f", "Bajo": "#6b9e3f", "Medio": "#c98f3a",
    "Alto": "#b3261e", "Muy alto": "#7a1a12",
}


def _marginacion_html(agebs: list[dict]) -> str:
    marg = obtener_marginacion([a["cve_geo"] for a in agebs])
    if marg is None:
        return ""
    color = MARGINACION_COLOR.get(marg["grado_predominante"], "#6b7280")
    desglose = ", ".join(
        f"{n} {html.escape(g)}" for g, n in sorted(marg["conteo_grados"].items(), key=lambda kv: -kv[1])
    )
    cobertura = ""
    if marg["n_agebs_con_dato"] < marg["n_agebs_total"]:
        cobertura = f' ({marg["n_agebs_con_dato"]} de {marg["n_agebs_total"]} AGEBs con dato disponible)'
    return (
        '<div class="nse-box">'
        '<div class="nse-top">'
        '<span class="bar-label">Marginación urbana (CONAPO, índice OFICIAL)</span>'
        f'<span class="nse-badge" style="background:{color}22;color:{color};">{html.escape(marg["grado_predominante"])}</span>'
        "</div>"
        f'<span class="bar-track"><span class="bar-fill" style="width:{marg["indice_normalizado_pct"]}%;background:{color};"></span></span>'
        f'<p class="nse-note">Grado de marginación urbana predominante: {desglose}{cobertura}. Barra = índice '
        "normalizado promedio ponderado por población (más alto = MENOS marginación / mejor nivel). Fuente: "
        "Índice de Marginación Urbana por AGEB 2020, CONAPO (Consejo Nacional de Población) — dato oficial de "
        "gobierno, no un proxy.</p>"
        "</div>"
    )


DENUE_CATEGORIA_COLOR = {
    "Farmacias": "#2f6f4f",
    "Hospitales": "#7a2c3f",
    "Clínicas (consultorios médicos agrupados)": "#9a3b52",
    "Consultorios médicos (general y especializada)": "#b0546b",
    "Consultorios dentales": "#c66f83",
    "Laboratorios clínicos / de análisis": "#6f5a9a",
    "Laboratorios de imagen (radiología/imagenología)": "#8a76b5",
    "Otros consultorios y servicios de salud": "#c98f3a",
    "Asistencia social (guarderías, asilos, orientación, etc.)": "#8a8f98",
    "Otros servicios de salud": "#8a8f98",
}


def _denue_html(agebs: list[dict]) -> str:
    conteo = contar_unidades_salud([a["cve_geo"] for a in agebs])
    if conteo is None or conteo["unidades_salud"] == 0:
        return ""

    desglose = conteo["desglose"]
    maximo = max(desglose.values(), default=0) or 1
    filas = []
    for cat in ORDEN_CATEGORIAS_DENUE:
        n = desglose.get(cat)
        if not n:
            continue
        color = DENUE_CATEGORIA_COLOR.get(cat, "#8a8f98")
        pct = round((n / maximo) * 100, 1)
        filas.append(
            '<div class="bar-row-inline">'
            '<div class="bar-top">'
            f'<span class="bar-label">{html.escape(cat)}</span>'
            f'<span class="bar-value" style="color:{color};">{n:,}</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct}%;background:{color};"></span></span>'
            "</div>"
        )

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{conteo["unidades_salud"]:,}</span>'
        '<span class="bar-label">Unidades de salud (total: sector SCIAN 62 + farmacias)</span>'
        "</div>"
        "</div>"
        f'<div style="margin-top:0.7rem;">{"".join(filas)}</div>'
        '<p class="nse-note">Establecimientos activos del DENUE (INEGI), geocodificados por INEGI directamente a '
        "su AGEB. Farmacias = SCIAN 4641 (sector Comercio); el resto = sector Servicios de Salud y Asistencia "
        "Social (SCIAN 62, por eso incluye guarderías/asilos/orientación además de clínicas). El corte entre "
        '"Laboratorios clínicos" y "de imagen" es una aproximación por palabras clave en el nombre del '
        "establecimiento (SCIAN no los distingue en una sola clase) — puede haber errores de clasificación "
        "puntuales.</p>"
        "</div>"
    )


def _esep_html(agebs: list[dict]) -> str:
    rec = obtener_recursos_hospitalarios([a["cve_geo"] for a in agebs])
    if rec is None:
        return ""

    filas = []
    for campo, etiqueta in ETIQUETAS_ESEP.items():
        n = rec[campo]
        if n:
            filas.append(f"<li><strong>{n:,}</strong> {html.escape(etiqueta)}</li>")

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{rec["n_hospitales"]:,}</span>'
        '<span class="bar-label">Hospitales privados con equipamiento verificado (ESEP, INEGI)</span>'
        "</div>"
        "</div>"
        f'<ul style="margin:0.6rem 0 0; padding-left:1.1rem; font-size:0.82rem; columns:2; gap:1rem;">{"".join(filas)}</ul>'
        '<p class="nse-note">Recursos materiales reportados directamente por los hospitales privados a INEGI '
        "(Estadística de Salud en Establecimientos Particulares, ESEP 2025) — dato real de capacidad instalada, no "
        "un conteo de negocios ni una aproximación por nombre. Solo cubre hospitales (no consultorios ni "
        "laboratorios independientes); si no aparece nada aquí, la zona no tiene un hospital privado encuestado.</p>"
        "</div>"
    )


def _zonas_form_html(valor: str, radio: str, zonas_todas: list[dict], zonas_usadas: list[dict]) -> str:
    ids_usadas = {z["id"] for z in zonas_usadas}
    items = []
    for z in zonas_todas:
        checked = "checked" if z["id"] in ids_usadas else ""
        items.append(
            '<label class="zona-item">'
            f'<input type="checkbox" name="zona" value="{z["id"]}" {checked}>'
            f'<span><span class="zona-cp">CP {html.escape(str(z["cp"]))}</span> — {html.escape(z["colonia"])}</span>'
            "</label>"
        )
    plural = "zonas" if len(zonas_todas) != 1 else "zona"
    intro = (
        f'Se {"encontró" if len(zonas_todas) == 1 else "encontraron"} {len(zonas_todas)} {plural} de código postal '
        f'que coincide{"n" if len(zonas_todas) != 1 else ""} con "{html.escape(valor)}". '
        "Cada una lista las colonias reales que agrupa (así identificas exactamente qué representa cada CP). "
        "Desmarca las que no correspondan y vuelve a calcular."
    )
    return (
        '<div class="zonas-box">'
        f"<p>{intro}</p>"
        f'<form method="get" action="/">'
        f'<input type="hidden" name="valor" value="{html.escape(valor)}">'
        f'<input type="hidden" name="radio" value="{html.escape(radio)}">'
        '<input type="hidden" name="zonas_form" value="1">'
        f'<div class="zonas-list">{"".join(items)}</div>'
        '<div class="zonas-actions"><button type="submit" class="secondary">Recalcular con selección</button></div>'
        "</form>"
        "</div>"
    )


def _punto_info_html(lat: float, lon: float, info: dict) -> str:
    ageb = info.get("ageb")
    zonas = info.get("zonas") or []

    if ageb:
        ageb_txt = f"AGEB {html.escape(ageb['cve_ageb'])} (clave completa {html.escape(ageb['cve_geo'])})"
    else:
        ageb_txt = "fuera de cualquier AGEB conocido del Marco Geoestadístico"

    if zonas:
        nombres = ", ".join(f"{html.escape(z['colonia'])} (CP {html.escape(str(z['cp']))})" for z in zonas)
        zonas_txt = f"dentro de: {nombres}"
    else:
        zonas_txt = "no cae dentro de ninguna zona de Colonia/CP catalogada"

    return (
        '<div class="zonas-box">'
        f'<p>Coordenada identificada: <strong>{lat:.5f}, {lon:.5f}</strong> — {ageb_txt}; {zonas_txt}.</p>'
        "</div>"
    )


_RE_COORDENADAS = re.compile(r"^\s*(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$")
_RE_CP = re.compile(r"^\d{5}$")
_RE_AGEB_CORTA = re.compile(r"^[0-9A-Za-z]{4}$")
_RE_AGEB_COMPLETA = re.compile(r"^\d{13}$")


def _detectar_tipo(valor: str) -> str:
    """Detecta automáticamente qué está buscando el usuario a partir de un solo campo de
    texto, sin que tenga que elegir el tipo a mano:
    - "lat,lon" con ambos números en rango válido -> Coordenadas.
    - 5 dígitos -> Código Postal.
    - 4 caracteres alfanuméricos o 13 dígitos -> clave de AGEB (corta o completa).
    - cualquier otra cosa -> Colonia (búsqueda por nombre)."""
    v = valor.strip()

    m = _RE_COORDENADAS.match(v)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return "Coordenadas"

    if _RE_CP.match(v):
        return "CP"

    if _RE_AGEB_CORTA.match(v) or _RE_AGEB_COMPLETA.match(v):
        return "AGEB"

    return "Colonia"


def render_resultado(tipo: str, valor: str, radio: str = "", zona_ids: list[str] | None = None) -> str:
    if not valor:
        return ""
    radio = radio.strip()
    radio_km = None
    if radio:
        try:
            radio_km = float(radio)
        except ValueError:
            return '<p class="error">Radio inválido: debe ser un número en kilómetros (ej. 1.5).</p>'
        if tipo not in ("Colonia", "CP", "Coordenadas"):
            return '<p class="error">El radio solo aplica cuando buscas por Colonia, Código Postal o Coordenadas.</p>'

    if tipo == "Coordenadas":
        partes_coord = [p.strip() for p in valor.split(",")]
        if len(partes_coord) != 2:
            return '<p class="error">Formato inválido. Escribe "lat,lon" (ej. 32.5048,-116.9350).</p>'
        try:
            lat, lon = float(partes_coord[0]), float(partes_coord[1])
        except ValueError:
            return '<p class="error">Coordenada inválida: lat y lon deben ser números.</p>'
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            return '<p class="error">Coordenada fuera de rango (lat entre -90 y 90, lon entre -180 y 180).</p>'
        try:
            totals, agebs, info_punto = analizar_por_coordenada(lat, lon, radio_km=radio_km)
        except ZonaNoEncontradaError as e:
            return f'<p class="error">{html.escape(str(e))}</p>'
        except Exception:
            logger.exception("Error procesando consulta web.")
            return '<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>'
        zona_punto = {"id": "coord", "cp": None, "colonia": "Coordenada elegida", "lat": lat, "lon": lon}
        zonas_todas = [zona_punto]
        zonas_usadas = [zona_punto]
    else:
        zona_ids_set = None
        if zona_ids is not None:
            try:
                zona_ids_set = {int(z) for z in zona_ids}
            except ValueError:
                zona_ids_set = set()

        try:
            totals, agebs, zonas_todas, zonas_usadas = analizar_locacion(
                tipo, valor, radio_km=radio_km, zona_ids=zona_ids_set
            )
        except ZonaNoEncontradaError:
            return f'<p class="error">No se encontraron resultados para {html.escape(tipo)} = "{html.escape(valor)}".</p>'
        except ValueError as e:
            return f'<p class="error">{html.escape(str(e))}</p>'
        except Exception:
            logger.exception("Error procesando consulta web.")
            return '<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>'

    badge = f"radio {html.escape(radio)} km · {len(agebs)} AGEBs" if radio_km else f"{len(agebs)} AGEBs"
    parts = [
        '<div class="result-header">'
        f'<h2>{html.escape(tipo)}: "{html.escape(valor)}"</h2>'
        f'<span class="badge">{badge}</span>'
        "</div>"
    ]

    if tipo == "Coordenadas":
        parts.append(_punto_info_html(lat, lon, info_punto))
    elif zonas_todas:
        parts.append(_zonas_form_html(valor, radio, zonas_todas, zonas_usadas))

    if agebs:
        rings_por_ageb, cve_incluidos = geometria_para_mapa(agebs)
        if rings_por_ageb:
            zonas_activas_ids = {z["id"] for z in zonas_usadas}
            svg = render_mapa(rings_por_ageb, cve_incluidos, zonas_todas, zonas_activas_ids, radio_km)
            leyenda = leyenda_mapa(len(cve_incluidos), len(rings_por_ageb) - len(cve_incluidos), radio_km)
            hint_marcadores = (
                " · clic en un punto para incluir/excluir esa zona (recalcula al instante)"
                if zonas_todas and tipo != "Coordenadas" else ""
            )
            parts.append(
                '<details class="audit mapa-details" open>'
                "<summary>Ver mapa de Tijuana</summary>"
                '<div class="mapa-toolbar">'
                f'<span class="mapa-hint">Arrastra para mover · Ctrl/Cmd + rueda para zoom{hint_marcadores}</span>'
                '<span class="mapa-toolbar-btns">'
                '<button type="button" class="mapa-centrar secondary">Centrar en zona</button>'
                '<button type="button" class="mapa-completa secondary">Ver Tijuana completa</button>'
                "</span>"
                "</div>"
                f'<div class="mapa-wrap">{svg}</div>'
                f'<div class="mapa-leyenda">{leyenda}</div>'
                "</details>"
            )

    parts.append('<div class="grid">')
    for categoria, variables in CATEGORIAS.items():
        color = CATEGORIA_COLOR.get(categoria, "#2f5496")
        titulo = CATEGORIA_LABELS.get(categoria, categoria.replace("_", " / "))
        parts.append(
            '<div class="card"><div class="card-head">'
            f'<h3><span class="dot" style="background:{color};"></span>{html.escape(titulo)}</h3>'
            '<details class="chart-toggle"><summary>Gráfico</summary>'
            f'<div class="chart-panel">{_grafico_categoria(categoria, totals)}</div>'
            "</details>"
            "</div>"
        )
        parts.append(_bar_chart(variables, totals, color))
        if categoria == "Educacion_Socioeconomico":
            parts.append(_marginacion_html(agebs))
            parts.append(_nse_html(totals))
        elif categoria == "Salud":
            parts.append(_denue_html(agebs))
            parts.append(_esep_html(agebs))
        parts.append("</div>")
    parts.append("</div>")

    if agebs:
        parts.append(
            f'<details class="audit"><summary>Ver los {len(agebs)} AGEBs incluidos '
            f"(para auditar contra INEGI)</summary>"
            '<table><tr><th>Clave AGEB</th><th>Clave completa (cve_geo)</th><th>Población total</th></tr>'
        )
        for ageb in sorted(agebs, key=lambda a: a["cve_geo"]):
            parts.append(
                f"<tr><td>{html.escape(ageb['cve_ageb'])}</td>"
                f"<td>{html.escape(ageb['cve_geo'])}</td>"
                f"<td>{round(ageb['pobtot'], 2)}</td></tr>"
            )
        parts.append("</table></details>")

    return "".join(parts)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.info("%s - %s", self.address_string(), format % args)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        valor = params.get("valor", [""])[0]
        radio = params.get("radio", [""])[0]
        zona_ids = params.get("zona") if params.get("zonas_form") == ["1"] else None
        tipo = _detectar_tipo(valor)

        resultado_html = render_resultado(tipo, valor, radio, zona_ids)
        body = PAGE_TEMPLATE.format(
            valor_escaped=html.escape(valor),
            radio_escaped=html.escape(radio),
            resultado=resultado_html,
        )
        if "mapa-svg" in resultado_html:
            body = body.replace("</body>", MAPA_SCRIPT + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))


def run_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    server = HTTPServer((host, port), Handler)
    logger.info("Servidor local iniciado en http://%s:%d (Ctrl+C para detener)", host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Servidor detenido.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_server()
