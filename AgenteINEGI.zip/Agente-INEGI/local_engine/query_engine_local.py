"""Motor de consultas local (SQLite, sin PostgreSQL) + exportación a CSV."""
import csv
import json
import unicodedata
from datetime import datetime
from pathlib import Path

from config import FECHA_DATOS, FUENTE_DATOS, OUTPUT_DIR, SQLITE_DB_PATH
from local_engine.db_sqlite import get_connection
from local_engine.etl_local import NUMERIC_CENSO_COLUMNS
from local_engine.geometry import haversine_km, multiring_centroid
from logger_setup import get_logger

logger = get_logger("query_engine_local")


def _sin_acentos(texto: str | None) -> str:
    """Normaliza a mayúsculas sin acentos (NFKD) para comparaciones tolerantes a tildes."""
    if texto is None:
        return ""
    descompuesto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in descompuesto if not unicodedata.combining(c)).upper()

VARIABLE_LABELS = {
    "vivtot": "Total de viviendas", "tvivparhab": "Viviendas particulares habitadas",
    "vivpar_des": "Viviendas particulares deshabitadas",
    "vph_pisoti": "Viviendas con piso diferente de tierra",
    "vph_c_elec": "Viviendas con energía eléctrica", "vph_excsa": "Viviendas con servicio sanitario",
    "vph_drenaj": "Viviendas con drenaje", "pobtot": "Población total",
    "pobfem": "Población femenina", "pobmas": "Población masculina",
    "p_0a14": "Población 0-14 años", "p_15a29": "Población 15-29 años",
    "p_30a59": "Población 30-59 años", "p_60ymas": "Población 60+ años",
    "pcon_disc": "Población con discapacidad", "p15ym_se": "Población sin escolaridad (15+)",
    "vph_inter": "Viviendas con internet", "vph_autom": "Viviendas con vehículo",
    "pder_ss": "Población con afiliación a servicios de salud", "pder_imss": "Cobertura IMSS",
    "pder_iste": "Cobertura ISSSTE", "pder_segpub": "Cobertura seguro público/privado",
    "psinder": "Población sin cobertura de salud",
}

CATEGORIAS = {
    "Vivienda": ["vivtot", "tvivparhab", "vivpar_des", "vph_pisoti", "vph_c_elec", "vph_excsa", "vph_drenaj"],
    "Poblacion": ["pobtot", "pobfem", "pobmas", "p_0a14", "p_15a29", "p_30a59", "p_60ymas", "pcon_disc"],
    "Educacion_Socioeconomico": ["p15ym_se", "vph_inter", "vph_autom"],
    "Salud": ["pder_ss", "pder_imss", "pder_iste", "pder_segpub", "psinder"],
}


class ZonaNoEncontradaError(Exception):
    pass


def analizar_locacion(tipo_busqueda: str, valor_busqueda: str) -> dict[str, float]:
    if tipo_busqueda not in ("Colonia", "CP", "AGEB"):
        raise ValueError("tipo_busqueda debe ser 'Colonia', 'CP' o 'AGEB'.")

    conn = get_connection(SQLITE_DB_PATH)
    conn.create_function("sin_acentos", 1, _sin_acentos)
    try:
        logger.info("Consultando %s = '%s'...", tipo_busqueda, valor_busqueda)

        if tipo_busqueda == "AGEB":
            # Búsqueda directa: no requiere el catálogo de colonias/CP, solo censo + geometría.
            query = "SELECT * FROM inegi_censo WHERE cve_ageb = ? OR cve_geo = ?;"
            valor_norm = valor_busqueda.strip()
            rows = conn.execute(query, (valor_norm.zfill(4), valor_norm)).fetchall()
        else:
            filtro_columna = "c.colonia" if tipo_busqueda == "Colonia" else "c.cp"
            query = f"""
                SELECT ic.*
                FROM colonias_cp c
                JOIN colonia_ageb_asignacion a ON a.colonia_cp_id = c.id
                JOIN inegi_censo ic ON ic.cve_geo = a.cve_geo
                WHERE sin_acentos({filtro_columna}) LIKE sin_acentos(?);
            """
            rows = conn.execute(query, (f"%{valor_busqueda}%",)).fetchall()

        if not rows:
            raise ZonaNoEncontradaError(
                f"No se encontraron resultados para {tipo_busqueda} = '{valor_busqueda}'."
            )

        totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
        for row in rows:
            for col in NUMERIC_CENSO_COLUMNS:
                totals[col] += row[col] or 0.0

        logger.info("Consulta exitosa: %d AGEBs agregados.", len(rows))
        return totals
    except ZonaNoEncontradaError:
        logger.warning("Zona no encontrada: %s = '%s'", tipo_busqueda, valor_busqueda)
        raise
    finally:
        conn.close()


def analizar_por_radio(lat: float, lon: float, radio_km: float) -> tuple[dict[str, float], int]:
    """Agrega el censo de todos los AGEBs cuyo centroide cae dentro de radio_km del punto (lat, lon).

    Devuelve (totals, n_agebs_incluidos). Más preciso que la búsqueda por nombre de
    Colonia/CP cuando el catálogo solo tiene geometría a nivel código postal (que puede
    agrupar varias colonias reales en un mismo polígono).
    """
    if radio_km <= 0:
        raise ValueError("radio_km debe ser mayor que 0.")

    conn = get_connection(SQLITE_DB_PATH)
    try:
        logger.info("Consultando radio de %.2f km alrededor de (%.6f, %.6f)...", radio_km, lat, lon)
        query = """
            SELECT ic.*, g.centroid_x, g.centroid_y
            FROM inegi_geometrias g
            JOIN inegi_censo ic ON ic.cve_geo = g.cve_geo
        """
        rows = conn.execute(query).fetchall()

        seleccionadas = [
            row for row in rows
            if haversine_km(lat, lon, row["centroid_y"], row["centroid_x"]) <= radio_km
        ]

        if not seleccionadas:
            raise ZonaNoEncontradaError(
                f"No se encontraron AGEBs dentro de {radio_km} km de ({lat}, {lon})."
            )

        totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
        for row in seleccionadas:
            for col in NUMERIC_CENSO_COLUMNS:
                totals[col] += row[col] or 0.0

        logger.info("Consulta exitosa: %d AGEBs agregados dentro del radio.", len(seleccionadas))
        return totals, len(seleccionadas)
    except ZonaNoEncontradaError:
        logger.warning("Radio sin resultados: %.2f km alrededor de (%.6f, %.6f)", radio_km, lat, lon)
        raise
    finally:
        conn.close()


def buscar_centros(tipo_busqueda: str, valor_busqueda: str) -> list[dict]:
    """Ayuda a ubicar coordenadas: busca Colonia/CP por nombre y devuelve el centro
    (lat/lon) de cada zona que coincide, para usarlas luego en analizar_por_radio().
    """
    if tipo_busqueda not in ("Colonia", "CP"):
        raise ValueError("tipo_busqueda debe ser 'Colonia' o 'CP'.")

    conn = get_connection(SQLITE_DB_PATH)
    conn.create_function("sin_acentos", 1, _sin_acentos)
    try:
        filtro_columna = "colonia" if tipo_busqueda == "Colonia" else "cp"
        query = f"""
            SELECT cp, colonia, rings_json FROM colonias_cp
            WHERE sin_acentos({filtro_columna}) LIKE sin_acentos(?);
        """
        rows = conn.execute(query, (f"%{valor_busqueda}%",)).fetchall()

        resultados = []
        for row in rows:
            rings = json.loads(row["rings_json"])
            cx, cy = multiring_centroid(rings)  # cx=lon, cy=lat
            resultados.append({
                "cp": row["cp"],
                "colonia": row["colonia"],
                "lat": cy,
                "lon": cx,
            })
        return resultados
    finally:
        conn.close()


def exportar_a_csv(
    totals: dict[str, float], tipo_busqueda: str, valor_busqueda: str, output_path: Path | None = None
) -> Path:
    if output_path is None:
        safe_valor = "".join(c if c.isalnum() else "_" for c in valor_busqueda)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = OUTPUT_DIR / f"reporte_{tipo_busqueda}_{safe_valor}_{timestamp}.csv"

    with output_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["Reporte de Análisis de Locación — INEGI"])
        writer.writerow(["Tipo de búsqueda", tipo_busqueda])
        writer.writerow(["Valor buscado", valor_busqueda])
        writer.writerow(["Fuente", FUENTE_DATOS])
        writer.writerow(["Fecha de datos", FECHA_DATOS])
        writer.writerow(["Fecha de generación", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow([])

        for categoria, variables in CATEGORIAS.items():
            writer.writerow([categoria.replace("_", " / ")])
            writer.writerow(["Indicador", "Valor"])
            for var in variables:
                writer.writerow([VARIABLE_LABELS[var], round(totals.get(var, 0.0), 2)])
            writer.writerow([])

    logger.info("Reporte exportado a %s", output_path)
    return output_path
