"""Modelado e inicialización de la base de datos local (SQLite, incluido en Python).

Sin PostgreSQL/PostGIS. Idempotente: usa CREATE TABLE IF NOT EXISTS y UPSERT nativo de SQLite.
"""
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS inegi_geometrias (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    nivel TEXT NOT NULL,
    centroid_x REAL NOT NULL,
    centroid_y REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS inegi_censo (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    vivtot REAL, tvivparhab REAL, vivpar_des REAL, vph_pisoti REAL,
    vph_c_elec REAL, vph_excsa REAL, vph_drenaj REAL,
    pobtot REAL, pobfem REAL, pobmas REAL, p_0a14 REAL, p_15a29 REAL,
    p_30a59 REAL, p_60ymas REAL, pcon_disc REAL,
    p15ym_se REAL, vph_inter REAL, vph_autom REAL,
    pder_ss REAL, pder_imss REAL, pder_iste REAL, pder_segpub REAL, psinder REAL
);

CREATE TABLE IF NOT EXISTS colonias_cp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    colonia TEXT,
    cp TEXT,
    municipio TEXT,
    rings_json TEXT NOT NULL,
    UNIQUE (colonia, cp, municipio)
);

CREATE TABLE IF NOT EXISTS colonia_ageb_asignacion (
    colonia_cp_id INTEGER NOT NULL REFERENCES colonias_cp(id),
    cve_geo TEXT NOT NULL REFERENCES inegi_geometrias(cve_geo),
    PRIMARY KEY (colonia_cp_id, cve_geo)
);

CREATE INDEX IF NOT EXISTS idx_colonias_cp_colonia ON colonias_cp (colonia);
CREATE INDEX IF NOT EXISTS idx_colonias_cp_cp ON colonias_cp (cp);
"""


def get_connection(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn


def setup_database(db_path: Path) -> None:
    conn = get_connection(db_path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()
