"""Configuración centralizada del proyecto. Todo local, sin llamadas externas."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    # python-dotenv no disponible (p. ej. modo 100% local sin acceso a pip).
    # El modo local (main_local.py) no depende de variables de .env, así que no es necesario.
    pass

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
LOG_DIR = BASE_DIR / "logs"
SQL_DIR = BASE_DIR / "sql"

for _dir in (OUTPUT_DIR, LOG_DIR):
    _dir.mkdir(parents=True, exist_ok=True)

# --- Conexión PostgreSQL / PostGIS (credenciales vía .env) ---
PGHOST = os.getenv("PGHOST", "localhost")
PGPORT = os.getenv("PGPORT", "5432")
PGDATABASE = os.getenv("PGDATABASE", "inegi_bc")
PGUSER = os.getenv("PGUSER", "postgres")
PGPASSWORD = os.getenv("PGPASSWORD", "")

DATABASE_URL = (
    f"postgresql+psycopg2://{PGUSER}:{PGPASSWORD}@{PGHOST}:{PGPORT}/{PGDATABASE}"
)

# --- Directorios y patrones de archivos de entrada esperados ---
# Ajusta estos valores/patrones según los nombres reales de tus archivos en ./data/.
MARCO_GEOESTADISTICO_DIR = DATA_DIR / "marco_geoestadistico"
CENSO_DIR = DATA_DIR / "censo"
CP_COLONIAS_DIR = DATA_DIR / "cp_colonias"

# Shapefile de AGEBs (ej. 02a.shp del Marco Geoestadístico clásico, o ageb_urb.shp de SCINCE).
# Coincide con cualquier .shp en la carpeta; se asume que data/marco_geoestadistico/ solo
# contiene el shapefile de AGEB (si tiene otros, ajusta este patrón para ser más específico).
AGEB_SHAPEFILE_GLOB = "*.shp"
# Shapefile de manzanas (si se usa nivel manzana en vez de AGEB).
MANZANA_SHAPEFILE_GLOB = "*m.shp"

# CSV del Censo 2020, tabulado ITER a nivel AGEB/manzana (ej. RESAGEBURB_02CSV20.csv).
CENSO_CSV_GLOB = "*.csv"

# Shapefile o CSV de colonias/CP (ej. cp_colonias.shp o cp_colonias.csv).
CP_COLONIAS_SHAPEFILE_GLOB = "*.shp"
CP_COLONIAS_CSV_GLOB = "*.csv"
# Índice de la capa a usar dentro de un webmap de ArcGIS Online (ver local_engine/
# esri_webmap_reader.py). Por defecto apunta a la capa "SUBSECTORES INTEGRADOS" (campo UTP)
# del mapa de Carta Urbana de IMPLAN Tijuana; ajusta si usas otro webmap con otro orden de capas.
CP_COLONIAS_WEBMAP_LAYER_INDEX = 4

# --- Clave geoestadística ---
# Shapefiles del Marco Geoestadístico (columnas de atributos con prefijo CVE_).
CLAVE_COLUMNS = ["CVE_ENT", "CVE_MUN", "CVE_LOC", "CVE_AGEB"]
# CSV tabular del Censo 2020 (INEGI usa nombres cortos sin prefijo CVE_ en este archivo).
CENSO_CLAVE_COLUMNS = ["ENTIDAD", "MUN", "LOC", "AGEB"]

# --- SRID de trabajo (WGS84) ---
TARGET_SRID = 4326

# --- Entidad objetivo (Baja California) ---
CVE_ENT_BC = "02"

# --- Modo local (SQLite, sin PostgreSQL/PostGIS) ---
SQLITE_DB_PATH = BASE_DIR / "inegi_local.db"

# --- Fuente y fecha de los datos, para referencia en reportes ---
FUENTE_DATOS = "INEGI - Censo de Población y Vivienda 2020"
FECHA_DATOS = "2020"
