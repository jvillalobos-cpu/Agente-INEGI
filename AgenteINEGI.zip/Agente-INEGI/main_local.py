"""CLI del modo 100% local (sin PostgreSQL, sin librerías externas — solo Python estándar).

Uso:
    python main_local.py setup-db
    python main_local.py run-etl
    python main_local.py query --tipo Colonia --valor "Zona Rio"
    python main_local.py centro --tipo Colonia --valor "Villa Fontana"
    python main_local.py query-radio --lat 32.5048 --lon -116.8604 --radio 1.5
    python main_local.py serve [--port 8000]
"""
import argparse
import sys
from pathlib import Path

from logger_setup import get_logger

logger = get_logger("main_local")


def cmd_setup_db(_args: argparse.Namespace) -> None:
    from config import SQLITE_DB_PATH
    from local_engine.db_sqlite import setup_database

    setup_database(SQLITE_DB_PATH)
    print(f"Base de datos SQLite lista en {SQLITE_DB_PATH}")


def cmd_run_etl(_args: argparse.Namespace) -> None:
    from local_engine.etl_local import run_etl_local

    run_etl_local()


def cmd_query(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import analizar_locacion, exportar_a_csv

    output_path = Path(args.output) if args.output else None
    totals = analizar_locacion(args.tipo, args.valor)
    path = exportar_a_csv(totals, args.tipo, args.valor, output_path)
    print(f"Reporte generado: {path}")


def cmd_centro(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import buscar_centros

    resultados = buscar_centros(args.tipo, args.valor)
    if not resultados:
        print(f"No se encontraron zonas para {args.tipo} = '{args.valor}'.")
        return
    print(f"{len(resultados)} zona(s) encontrada(s):\n")
    for r in resultados:
        print(f"CP {r['cp']}  |  lat={r['lat']:.6f}, lon={r['lon']:.6f}")
        print(f"  Colonias: {r['colonia']}\n")


def cmd_query_radio(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import analizar_por_radio, exportar_a_csv

    output_path = Path(args.output) if args.output else None
    totals, n_agebs = analizar_por_radio(args.lat, args.lon, args.radio)
    valor_desc = f"{args.lat},{args.lon},{args.radio}km"
    path = exportar_a_csv(totals, "Radio", valor_desc, output_path)
    print(f"{n_agebs} AGEBs agregados dentro del radio.")
    print(f"Reporte generado: {path}")


def cmd_serve(args: argparse.Namespace) -> None:
    from local_engine.server import run_server

    run_server(port=args.port)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Agente INEGI - Baja California (modo 100% local, sin librerías externas)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("setup-db", help="Inicializa la base de datos SQLite local.").set_defaults(func=cmd_setup_db)
    subparsers.add_parser("run-etl", help="Ejecuta el pipeline ETL completo (local).").set_defaults(func=cmd_run_etl)

    query_parser = subparsers.add_parser("query", help="Consulta una zona por Colonia o CP.")
    query_parser.add_argument("--tipo", required=True, choices=["Colonia", "CP", "AGEB"])
    query_parser.add_argument("--valor", required=True)
    query_parser.add_argument("--output", required=False)
    query_parser.set_defaults(func=cmd_query)

    centro_parser = subparsers.add_parser(
        "centro", help="Busca Colonia/CP por nombre y muestra sus coordenadas (lat/lon) para usar con query-radio."
    )
    centro_parser.add_argument("--tipo", required=True, choices=["Colonia", "CP"])
    centro_parser.add_argument("--valor", required=True)
    centro_parser.set_defaults(func=cmd_centro)

    radio_parser = subparsers.add_parser(
        "query-radio", help="Agrega el censo de todos los AGEBs dentro de un radio (km) de un punto lat/lon."
    )
    radio_parser.add_argument("--lat", required=True, type=float)
    radio_parser.add_argument("--lon", required=True, type=float)
    radio_parser.add_argument("--radio", required=True, type=float, help="Radio en kilómetros.")
    radio_parser.add_argument("--output", required=False)
    radio_parser.set_defaults(func=cmd_query_radio)

    serve_parser = subparsers.add_parser("serve", help="Levanta el servidor web local (HTML dinámico).")
    serve_parser.add_argument("--port", type=int, default=8000)
    serve_parser.set_defaults(func=cmd_serve)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        logger.error("Error ejecutando comando '%s': %s", args.command, exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
