"""Modelado de tablas PostgreSQL/PostGIS. Ejecución idempotente (CREATE ... IF NOT EXISTS)."""
from sqlalchemy import (
    Column,
    Float,
    Integer,
    MetaData,
    String,
    Table,
    UniqueConstraint,
)
from geoalchemy2 import Geometry

from config import TARGET_SRID

metadata = MetaData()

# Geometrías del Marco Geoestadístico (AGEBs / Manzanas).
inegi_geometrias = Table(
    "inegi_geometrias",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("cve_ent", String(2), nullable=False),
    Column("cve_mun", String(3), nullable=False),
    Column("cve_loc", String(4), nullable=False),
    Column("cve_ageb", String(4), nullable=False),
    Column("cve_geo", String(20), nullable=False, unique=True),
    Column("nivel", String(20), nullable=False),  # 'ageb' o 'manzana'
    Column("geom", Geometry(geometry_type="MULTIPOLYGON", srid=TARGET_SRID), nullable=False),
)

# Datos tabulares del Censo 2020, a nivel AGEB/manzana.
inegi_censo = Table(
    "inegi_censo",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("cve_geo", String(20), nullable=False, unique=True),
    Column("cve_ent", String(2), nullable=False),
    Column("cve_mun", String(3), nullable=False),
    Column("cve_loc", String(4), nullable=False),
    Column("cve_ageb", String(4), nullable=False),
    # Vivienda
    Column("vivtot", Float),
    Column("tvivparhab", Float),
    Column("vivpar_des", Float),
    Column("vph_pisoti", Float),
    Column("vph_c_elec", Float),
    Column("vph_excsa", Float),
    Column("vph_drenaj", Float),
    # Población
    Column("pobtot", Float),
    Column("pobfem", Float),
    Column("pobmas", Float),
    Column("p_0a14", Float),
    Column("p_15a29", Float),
    Column("p_30a59", Float),
    Column("p_60ymas", Float),
    Column("pcon_disc", Float),
    # Educación y socioeconómico
    Column("p15ym_se", Float),
    Column("vph_inter", Float),
    Column("vph_autom", Float),
    # Salud
    Column("pder_ss", Float),
    Column("pder_imss", Float),
    Column("pder_iste", Float),
    Column("pder_segpub", Float),
    Column("psinder", Float),
)

# Polígonos de búsqueda: Colonias y Códigos Postales.
colonias_cp = Table(
    "colonias_cp",
    metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("colonia", String(150)),
    Column("cp", String(10)),
    Column("municipio", String(100)),
    Column("geom", Geometry(geometry_type="MULTIPOLYGON", srid=TARGET_SRID), nullable=False),
    UniqueConstraint("colonia", "cp", "municipio", name="uq_colonia_cp_municipio"),
)
