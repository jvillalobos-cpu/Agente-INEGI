"""Fase 2: ETL de datos espaciales (shapefiles) y tabulares (Censo 2020) hacia PostGIS.

100% local: solo lee archivos de ./data/, no realiza llamadas de red.
Idempotente: usa upsert (ON CONFLICT) sobre las claves únicas de cada tabla.
"""
from pathlib import Path
from typing import Optional

import geopandas as gpd
import pandas as pd
from shapely.geometry import MultiPolygon, Polygon
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config import (
    AGEB_SHAPEFILE_GLOB,
    CENSO_CLAVE_COLUMNS,
    CENSO_CSV_GLOB,
    CENSO_DIR,
    CP_COLONIAS_CSV_GLOB,
    CP_COLONIAS_DIR,
    CP_COLONIAS_SHAPEFILE_GLOB,
    CLAVE_COLUMNS,
    DATABASE_URL,
    MARCO_GEOESTADISTICO_DIR,
    TARGET_SRID,
)
from logger_setup import get_logger

logger = get_logger("etl_pipeline")

# Mapeo (columna_real_del_CSV_INEGI, columna_destino). `None` como origen significa que
# el Censo 2020 no publica esa variable a nivel AGEB (solo existe en microdatos); queda en 0
# y se advierte en el log en vez de inventar un valor. Verificado contra
# conjunto_de_datos_ageb_urbana_02_cpv2020.csv (230 columnas, INEGI CPV2020).
CENSO_COLUMN_MAP: list[tuple[Optional[str], str]] = [
    ("VIVTOT", "vivtot"),
    ("TVIVPARHAB", "tvivparhab"),
    ("VIVPAR_DES", "vivpar_des"),
    ("VPH_PISOTI", "vph_pisoti"),
    ("VPH_C_ELEC", "vph_c_elec"),
    ("VPH_EXCSA", "vph_excsa"),
    ("VPH_DRENAJ", "vph_drenaj"),
    ("POBTOT", "pobtot"),
    ("POBFEM", "pobfem"),
    ("POBMAS", "pobmas"),
    ("POB0_14", "p_0a14"),
    (None, "p_15a29"),
    (None, "p_30a59"),
    ("P_60YMAS", "p_60ymas"),
    ("PCON_DISC", "pcon_disc"),
    ("P15YM_SE", "p15ym_se"),
    ("VPH_INTER", "vph_inter"),
    ("VPH_AUTOM", "vph_autom"),
    ("PDER_SS", "pder_ss"),
    ("PDER_IMSS", "pder_imss"),
    ("PDER_ISTE", "pder_iste"),
    ("PDER_SEGP", "pder_segpub"),
    ("PSINDER", "psinder"),
]

NUMERIC_CENSO_COLUMNS = [dest for _src, dest in CENSO_COLUMN_MAP]


def _to_multipolygon(geom):
    if geom is None:
        return None
    if isinstance(geom, Polygon):
        return MultiPolygon([geom])
    return geom


def _find_files(directory: Path, pattern: str) -> list[Path]:
    if not directory.exists():
        logger.warning("Directorio no encontrado: %s", directory)
        return []
    return sorted(directory.glob(pattern))


def _clean_confidencialidad(series: pd.Series) -> pd.Series:
    """INEGI marca valores confidenciales/no disponibles con '*' u otros textos. Los normaliza a 0."""
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace({"*": "0", "N/D": "0", "": "0", "nan": "0"})
    return pd.to_numeric(cleaned, errors="coerce").fillna(0)


def load_marco_geoestadistico(engine: Engine) -> None:
    """Carga los shapefiles de AGEBs/manzanas a la tabla inegi_geometrias."""
    shapefiles = _find_files(MARCO_GEOESTADISTICO_DIR, AGEB_SHAPEFILE_GLOB)
    if not shapefiles:
        logger.warning("No se encontraron shapefiles de AGEB en %s", MARCO_GEOESTADISTICO_DIR)
        return

    for shp_path in shapefiles:
        logger.info("Procesando shapefile geoestadístico: %s", shp_path.name)
        try:
            gdf = gpd.read_file(shp_path)
        except Exception:
            logger.exception("Error leyendo shapefile %s", shp_path)
            continue

        gdf.columns = [c.upper() for c in gdf.columns]

        # Soporta dos formatos usados por INEGI: un solo campo CVEGEO (13 caracteres: 2+3+4+4,
        # como en SCINCE) o columnas separadas CVE_ENT/CVE_MUN/CVE_LOC/CVE_AGEB.
        if "CVEGEO" in gdf.columns:
            cvegeo = gdf["CVEGEO"].astype(str).str.strip().str.zfill(13)
            gdf["CVE_ENT"] = cvegeo.str.slice(0, 2)
            gdf["CVE_MUN"] = cvegeo.str.slice(2, 5)
            gdf["CVE_LOC"] = cvegeo.str.slice(5, 9)
            gdf["CVE_AGEB"] = cvegeo.str.slice(9, 13)
        else:
            missing = [c for c in CLAVE_COLUMNS if c not in gdf.columns]
            if missing:
                logger.error(
                    "Shapefile %s no contiene ni CVEGEO ni las columnas de clave %s. Se omite.",
                    shp_path.name,
                    missing,
                )
                continue

        if gdf.crs is None:
            logger.warning(
                "Shapefile %s no define CRS; se asume EPSG:%s.", shp_path.name, TARGET_SRID
            )
            gdf = gdf.set_crs(epsg=TARGET_SRID)
        elif gdf.crs.to_epsg() != TARGET_SRID:
            logger.info(
                "Reproyectando %s de %s a EPSG:%s.", shp_path.name, gdf.crs, TARGET_SRID
            )
            gdf = gdf.to_crs(epsg=TARGET_SRID)

        gdf["geometry"] = gdf["geometry"].apply(_to_multipolygon)
        gdf = gdf[gdf["geometry"].notnull()]

        out = pd.DataFrame(
            {
                "cve_ent": gdf["CVE_ENT"].astype(str).str.zfill(2),
                "cve_mun": gdf["CVE_MUN"].astype(str).str.zfill(3),
                "cve_loc": gdf["CVE_LOC"].astype(str).str.zfill(4),
                "cve_ageb": gdf["CVE_AGEB"].astype(str).str.zfill(4),
                "nivel": "ageb",
                "geom": gdf["geometry"].apply(lambda g: g.wkt if g is not None else None),
            }
        )
        out["cve_geo"] = (
            out["cve_ent"] + out["cve_mun"] + out["cve_loc"] + out["cve_ageb"]
        )
        out = out.dropna(subset=["geom"])

        _upsert_geometrias(engine, out)


def _upsert_geometrias(engine: Engine, df: pd.DataFrame) -> None:
    if df.empty:
        return
    insert_sql = text(
        """
        INSERT INTO inegi_geometrias (cve_ent, cve_mun, cve_loc, cve_ageb, cve_geo, nivel, geom)
        VALUES (:cve_ent, :cve_mun, :cve_loc, :cve_ageb, :cve_geo, :nivel,
                ST_SetSRID(ST_GeomFromText(:geom), :srid))
        ON CONFLICT (cve_geo) DO UPDATE SET
            cve_ent = EXCLUDED.cve_ent,
            cve_mun = EXCLUDED.cve_mun,
            cve_loc = EXCLUDED.cve_loc,
            cve_ageb = EXCLUDED.cve_ageb,
            nivel = EXCLUDED.nivel,
            geom = EXCLUDED.geom;
        """
    )
    records = df.to_dict(orient="records")
    with engine.begin() as conn:
        for rec in records:
            rec["srid"] = TARGET_SRID
            conn.execute(insert_sql, rec)
    logger.info("Insertadas/actualizadas %d geometrías.", len(records))


def load_censo(engine: Engine) -> None:
    """Carga y limpia el CSV del Censo 2020, uniéndolo por clave geoestadística."""
    csv_files = _find_files(CENSO_DIR, CENSO_CSV_GLOB)
    if not csv_files:
        logger.warning("No se encontraron archivos CSV del censo en %s", CENSO_DIR)
        return

    for csv_path in csv_files:
        logger.info("Procesando CSV del censo: %s", csv_path.name)
        try:
            df = pd.read_csv(csv_path, dtype=str, low_memory=False, encoding="utf-8-sig")
        except Exception:
            logger.exception("Error leyendo CSV %s", csv_path)
            continue

        df.columns = [c.upper().strip() for c in df.columns]

        # Claves del CSV tabular de INEGI (distintas de las del shapefile, que usan prefijo CVE_).
        missing_keys = [c for c in CENSO_CLAVE_COLUMNS if c not in df.columns]
        if missing_keys:
            logger.error(
                "CSV %s no contiene las columnas de clave requeridas %s. Se omite.",
                csv_path.name,
                missing_keys,
            )
            continue

        if "MZA" in df.columns:
            # El CSV incluye filas por manzana individual además del resumen por AGEB (MZA=000).
            # Se usa solo el resumen para no duplicar población al agregar por AGEB.
            df = df[df["MZA"].astype(str).str.strip() == "000"]

        out = pd.DataFrame(
            {
                "cve_ent": df["ENTIDAD"].astype(str).str.zfill(2),
                "cve_mun": df["MUN"].astype(str).str.zfill(3),
                "cve_loc": df["LOC"].astype(str).str.zfill(4),
                "cve_ageb": df["AGEB"].astype(str).str.zfill(4),
            }
        )
        out["cve_geo"] = (
            out["cve_ent"] + out["cve_mun"] + out["cve_loc"] + out["cve_ageb"]
        )

        for src_col, dest_col in CENSO_COLUMN_MAP:
            if src_col is None:
                logger.warning(
                    "%s no se publica a nivel AGEB en el Censo 2020 (solo en microdatos); queda en 0.",
                    dest_col,
                )
                out[dest_col] = 0.0
            elif src_col in df.columns:
                out[dest_col] = _clean_confidencialidad(df[src_col])
            else:
                logger.warning("Columna %s no encontrada en %s; se llenará con 0.", src_col, csv_path.name)
                out[dest_col] = 0.0

        # Excluye filas de totales agregados (AGEB '0000' suele representar totales municipales).
        out = out[out["cve_ageb"] != "0000"]

        _upsert_censo(engine, out)


def _upsert_censo(engine: Engine, df: pd.DataFrame) -> None:
    if df.empty:
        return
    columns = ["cve_geo", "cve_ent", "cve_mun", "cve_loc", "cve_ageb"] + NUMERIC_CENSO_COLUMNS
    placeholders = ", ".join(f":{c}" for c in columns)
    update_clause = ", ".join(f"{c} = EXCLUDED.{c}" for c in columns if c != "cve_geo")
    insert_sql = text(
        f"""
        INSERT INTO inegi_censo ({', '.join(columns)})
        VALUES ({placeholders})
        ON CONFLICT (cve_geo) DO UPDATE SET {update_clause};
        """
    )
    records = df[columns].to_dict(orient="records")
    with engine.begin() as conn:
        for rec in records:
            conn.execute(insert_sql, rec)
    logger.info("Insertados/actualizados %d registros censales.", len(records))


def load_colonias_cp(engine: Engine) -> None:
    """Carga el catálogo de colonias/CP desde shapefile (preferido) o CSV con geometría WKT."""
    shapefiles = _find_files(CP_COLONIAS_DIR, CP_COLONIAS_SHAPEFILE_GLOB)
    if shapefiles:
        for shp_path in shapefiles:
            logger.info("Procesando shapefile de colonias/CP: %s", shp_path.name)
            try:
                gdf = gpd.read_file(shp_path)
            except Exception:
                logger.exception("Error leyendo shapefile %s", shp_path)
                continue
            _process_colonias_gdf(engine, gdf, shp_path.name)
        return

    csv_files = _find_files(CP_COLONIAS_DIR, CP_COLONIAS_CSV_GLOB)
    if not csv_files:
        logger.warning("No se encontró catálogo de colonias/CP en %s", CP_COLONIAS_DIR)
        return
    for csv_path in csv_files:
        logger.info("Procesando CSV de colonias/CP: %s", csv_path.name)
        try:
            df = pd.read_csv(csv_path)
        except Exception:
            logger.exception("Error leyendo CSV %s", csv_path)
            continue
        if "geometry" not in {c.lower() for c in df.columns}:
            logger.error("CSV %s no contiene columna 'geometry' (WKT). Se omite.", csv_path.name)
            continue
        geom_col = next(c for c in df.columns if c.lower() == "geometry")
        gdf = gpd.GeoDataFrame(
            df, geometry=gpd.GeoSeries.from_wkt(df[geom_col]), crs=f"EPSG:{TARGET_SRID}"
        )
        _process_colonias_gdf(engine, gdf, csv_path.name)


def _process_colonias_gdf(engine: Engine, gdf: gpd.GeoDataFrame, source_name: str) -> None:
    gdf.columns = [c.lower() if c != "geometry" else c for c in gdf.columns]

    col_colonia: Optional[str] = next(
        (c for c in gdf.columns if c in ("colonia", "nom_colonia", "settlement", "asent")), None
    )
    col_cp: Optional[str] = next((c for c in gdf.columns if c in ("cp", "d_cp", "codigo_postal")), None)
    col_mun: Optional[str] = next(
        (c for c in gdf.columns if c in ("municipio", "mun", "d_mnpio")), None
    )

    if col_colonia is None and col_cp is None:
        logger.error(
            "%s no contiene columnas identificables de colonia o CP. Se omite.", source_name
        )
        return

    if gdf.crs is None:
        gdf = gdf.set_crs(epsg=TARGET_SRID)
    elif gdf.crs.to_epsg() != TARGET_SRID:
        gdf = gdf.to_crs(epsg=TARGET_SRID)

    gdf["geometry"] = gdf["geometry"].apply(_to_multipolygon)
    gdf = gdf[gdf["geometry"].notnull()]

    out = pd.DataFrame(
        {
            "colonia": gdf[col_colonia].astype(str) if col_colonia else None,
            "cp": gdf[col_cp].astype(str) if col_cp else None,
            "municipio": gdf[col_mun].astype(str) if col_mun else None,
            "geom": gdf["geometry"].apply(lambda g: g.wkt if g is not None else None),
        }
    )
    out = out.dropna(subset=["geom"])

    insert_sql = text(
        """
        INSERT INTO colonias_cp (colonia, cp, municipio, geom)
        VALUES (:colonia, :cp, :municipio, ST_SetSRID(ST_GeomFromText(:geom), :srid))
        ON CONFLICT (colonia, cp, municipio) DO UPDATE SET
            geom = EXCLUDED.geom;
        """
    )
    records = out.to_dict(orient="records")
    with engine.begin() as conn:
        for rec in records:
            rec["srid"] = TARGET_SRID
            conn.execute(insert_sql, rec)
    logger.info("Insertadas/actualizadas %d colonias/CP desde %s.", len(records), source_name)


def refresh_interseccion_view(engine: Engine) -> None:
    """Refresca la vista materializada del traductor Colonia/CP -> AGEB (Fase 3)."""
    logger.info("Refrescando vista materializada de intersección espacial...")
    with engine.begin() as conn:
        conn.execute(text("REFRESH MATERIALIZED VIEW mv_colonia_ageb_interseccion;"))
    logger.info("Vista de intersección actualizada.")


def run_etl() -> None:
    engine = create_engine(DATABASE_URL)
    try:
        logger.info("Iniciando ETL (100%% local, sin llamadas externas)...")
        load_marco_geoestadistico(engine)
        load_censo(engine)
        load_colonias_cp(engine)
        try:
            refresh_interseccion_view(engine)
        except Exception:
            logger.warning(
                "No se pudo refrescar la vista de intersección; "
                "asegúrate de haber ejecutado sql/vista_interseccion.sql."
            )
        logger.info("ETL completado exitosamente.")
    except Exception:
        logger.exception("Error durante la ejecución del ETL.")
        raise
    finally:
        engine.dispose()


if __name__ == "__main__":
    run_etl()
