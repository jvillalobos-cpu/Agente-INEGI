"""Motor de consultas local (SQLite, sin PostgreSQL) + exportación a CSV."""
import csv
import json
import sqlite3
import unicodedata
from datetime import datetime
from pathlib import Path

from config import (
    FECHA_DATOS,
    FUENTE_DATOS,
    OUTPUT_DIR,
    SQLITE_DB_PATH,
    TOTAL_15A29_MUNICIPIO,
    TOTAL_30A59_MUNICIPIO,
)
from local_engine.db_sqlite import get_connection
from local_engine.etl_local import NUMERIC_CENSO_COLUMNS
from local_engine.geometry import haversine_km, multiring_centroid, point_in_multiring
from logger_setup import get_logger

logger = get_logger("query_engine_local")


def _sin_acentos(texto: str | None) -> str:
    """Normaliza a mayúsculas sin acentos (NFKD) para comparaciones tolerantes a tildes."""
    if texto is None:
        return ""
    descompuesto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in descompuesto if not unicodedata.combining(c)).upper()

VARIABLE_LABELS = {
    "vivtot": "Total de viviendas", "tvivparhab": "Viviendas particulares habitadas",
    "vivpar_des": "Viviendas particulares deshabitadas",
    "vph_pisoti": "Viviendas con piso diferente de tierra",
    "vph_c_elec": "Viviendas con energía eléctrica", "vph_excsa": "Viviendas con servicio sanitario",
    "vph_drenaj": "Viviendas con drenaje", "pobtot": "Población total",
    "pobfem": "Población femenina", "pobmas": "Población masculina",
    "p_0a14": "Población 0-14 años", "p_15a29": "Población 15-29 años",
    "p_30a59": "Población 30-59 años", "p_60ymas": "Población 60+ años",
    "pcon_disc": "Población con discapacidad", "p15ym_se": "Población sin escolaridad (15+)",
    "vph_inter": "Viviendas con internet", "vph_autom": "Viviendas con vehículo",
    "pder_ss": "Población con afiliación a servicios de salud", "pder_imss": "Cobertura IMSS",
    "pder_iste": "Cobertura ISSSTE", "pder_segpub": "Cobertura seguro público/privado",
    "psinder": "Población sin cobertura de salud",
}

CATEGORIAS = {
    "Vivienda": ["vivtot", "tvivparhab", "vivpar_des", "vph_pisoti", "vph_c_elec", "vph_excsa", "vph_drenaj"],
    "Poblacion": ["pobtot", "pobfem", "pobmas", "p_0a14", "p_15a29", "p_30a59", "p_60ymas", "pcon_disc"],
    "Educacion_Socioeconomico": ["p15ym_se", "vph_inter", "vph_autom"],
    "Salud": ["pder_ss", "pder_imss", "pder_iste", "pder_segpub", "psinder"],
}

# INEGI no publica estas variables a nivel AGEB en el Censo 2020 (el desglose de edad a ese
# nivel de detalle solo existe a partir de municipio hacia arriba); no es un dato faltante ni
# un error del ETL, es una limitación real de la fuente. Ver etl_local.CENSO_COLUMN_MAP.
VARIABLES_NO_DISPONIBLES_AGEB = {"p_15a29", "p_30a59"}


class ZonaNoEncontradaError(Exception):
    pass


def _lista_agebs(rows) -> list[dict]:
    """Extrae de un conjunto de filas censales la lista auditable de AGEBs incluidos
    (clave completa, clave corta y población total de cada uno)."""
    return [
        {"cve_geo": row["cve_geo"], "cve_ageb": row["cve_ageb"], "pobtot": row["pobtot"] or 0.0}
        for row in rows
    ]


def buscar_centros(tipo_busqueda: str, valor_busqueda: str) -> list[dict]:
    """Busca Colonia/CP por nombre y devuelve, por cada zona que coincide: su id
    (colonias_cp.id), el/los nombre(s) de colonia que agrupa, su CP y el centro
    (lat/lon) de su polígono — para usarlas luego en analizar_zonas().
    """
    if tipo_busqueda not in ("Colonia", "CP"):
        raise ValueError("tipo_busqueda debe ser 'Colonia' o 'CP'.")

    conn = get_connection(SQLITE_DB_PATH)
    conn.create_function("sin_acentos", 1, _sin_acentos)
    try:
        filtro_columna = "colonia" if tipo_busqueda == "Colonia" else "cp"
        query = f"""
            SELECT id, cp, colonia, rings_json FROM colonias_cp
            WHERE sin_acentos({filtro_columna}) LIKE sin_acentos(?);
        """
        rows = conn.execute(query, (f"%{valor_busqueda}%",)).fetchall()

        resultados = []
        for row in rows:
            rings = json.loads(row["rings_json"])
            cx, cy = multiring_centroid(rings)  # cx=lon, cy=lat
            resultados.append({
                "id": row["id"],
                "cp": row["cp"],
                "colonia": row["colonia"],
                "lat": cy,
                "lon": cx,
            })
        return resultados
    finally:
        conn.close()


def analizar_zonas(zonas: list[dict], radio_km: float | None = None) -> tuple[dict[str, float], int, list[dict]]:
    """Agrega el censo de las zonas (Colonia/CP, como las devuelve buscar_centros()) dadas.

    Sin radio_km: usa la asignación Colonia/CP -> AGEB ya calculada en el ETL (por nombre).
    Con radio_km: agrega los AGEBs cuyo centroide cae dentro de radio_km de CADA zona
    (unión sin duplicar), útil cuando el catálogo solo tiene geometría a nivel de código
    postal y puede agrupar varias colonias reales en un mismo polígono.
    """
    if not zonas:
        raise ZonaNoEncontradaError("No hay zonas seleccionadas.")

    conn = get_connection(SQLITE_DB_PATH)
    try:
        if radio_km:
            if radio_km <= 0:
                raise ValueError("radio_km debe ser mayor que 0.")
            query = """
                SELECT ic.*, g.centroid_x, g.centroid_y
                FROM inegi_geometrias g
                JOIN inegi_censo ic ON ic.cve_geo = g.cve_geo
            """
            rows = conn.execute(query).fetchall()
            incluidas: dict[str, object] = {}
            for zona in zonas:
                for row in rows:
                    if row["cve_geo"] in incluidas:
                        continue
                    if haversine_km(zona["lat"], zona["lon"], row["centroid_y"], row["centroid_x"]) <= radio_km:
                        incluidas[row["cve_geo"]] = row
            seleccionadas = list(incluidas.values())
        else:
            ids = [z["id"] for z in zonas]
            placeholders = ",".join("?" for _ in ids)
            query = f"""
                SELECT DISTINCT ic.*
                FROM colonia_ageb_asignacion a
                JOIN inegi_censo ic ON ic.cve_geo = a.cve_geo
                WHERE a.colonia_cp_id IN ({placeholders});
            """
            seleccionadas = conn.execute(query, ids).fetchall()

        if not seleccionadas:
            raise ZonaNoEncontradaError("No se encontraron AGEBs para las zonas seleccionadas.")

        totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
        for row in seleccionadas:
            for col in NUMERIC_CENSO_COLUMNS:
                totals[col] += row[col] or 0.0

        logger.info("Consulta exitosa: %d AGEBs agregados de %d zona(s).", len(seleccionadas), len(zonas))
        return totals, len(seleccionadas), _lista_agebs(seleccionadas)
    finally:
        conn.close()


def analizar_locacion(
    tipo_busqueda: str,
    valor_busqueda: str,
    radio_km: float | None = None,
    zona_ids: set[int] | None = None,
) -> tuple[dict[str, float], list[dict], list[dict], list[dict]]:
    """Punto de entrada principal de consulta. Devuelve (totals, agebs, zonas_todas, zonas_usadas).

    zonas_todas: todas las zonas (Colonia/CP) que coincidieron con la búsqueda por nombre
    (vacío si tipo_busqueda == 'AGEB', que no pasa por el catálogo de colonias).
    zonas_usadas: subconjunto de zonas_todas realmente agregado — todas por defecto, o solo
    las que el llamador filtró explícitamente vía zona_ids (para permitir al usuario
    incluir/excluir zonas ambiguas antes de sumar el censo).
    """
    if tipo_busqueda not in ("Colonia", "CP", "AGEB"):
        raise ValueError("tipo_busqueda debe ser 'Colonia', 'CP' o 'AGEB'.")

    logger.info("Consultando %s = '%s'...", tipo_busqueda, valor_busqueda)

    if tipo_busqueda == "AGEB":
        if radio_km:
            raise ValueError("El radio no aplica a búsquedas por AGEB (ya es la unidad geográfica mínima).")
        conn = get_connection(SQLITE_DB_PATH)
        try:
            query = "SELECT * FROM inegi_censo WHERE cve_ageb = ? OR cve_geo = ?;"
            valor_norm = valor_busqueda.strip()
            rows = conn.execute(query, (valor_norm.zfill(4), valor_norm)).fetchall()
            if not rows:
                raise ZonaNoEncontradaError(f"No se encontraron resultados para AGEB = '{valor_busqueda}'.")
            totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
            for row in rows:
                for col in NUMERIC_CENSO_COLUMNS:
                    totals[col] += row[col] or 0.0
            return totals, _lista_agebs(rows), [], []
        finally:
            conn.close()

    zonas_todas = buscar_centros(tipo_busqueda, valor_busqueda)
    if not zonas_todas:
        raise ZonaNoEncontradaError(f"No se encontraron resultados para {tipo_busqueda} = '{valor_busqueda}'.")

    if zona_ids is not None:
        zonas_usar = [z for z in zonas_todas if z["id"] in zona_ids]
        if not zonas_usar:
            raise ValueError("No hay ninguna zona seleccionada. Marca al menos una para continuar.")
    else:
        zonas_usar = zonas_todas

    totals, _n, agebs = analizar_zonas(zonas_usar, radio_km)
    return totals, agebs, zonas_todas, zonas_usar


def analizar_por_radio(lat: float, lon: float, radio_km: float) -> tuple[dict[str, float], int, list[dict]]:
    """Agrega el censo de todos los AGEBs cuyo centroide cae dentro de radio_km del punto (lat, lon)."""
    zona_generica = {"id": None, "cp": None, "colonia": None, "lat": lat, "lon": lon}
    return analizar_zonas([zona_generica], radio_km)


def identificar_punto(lat: float, lon: float) -> dict:
    """Dado un punto (lat, lon) escrito a mano, identifica en qué AGEB cae exactamente y
    qué Colonia/CP lo contiene (punto-en-polígono contra la geometría real de INEGI ya
    cargada). Así el usuario ve qué representa realmente la coordenada que escribió, en vez
    de confiar a ciegas en el número que tecleó."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        punto = (lon, lat)
        ageb = None
        for row in conn.execute(
            "SELECT cve_geo, cve_ageb, rings_json FROM inegi_geometrias WHERE rings_json IS NOT NULL;"
        ):
            rings = json.loads(row["rings_json"])
            if point_in_multiring(punto, rings):
                ageb = {"cve_geo": row["cve_geo"], "cve_ageb": row["cve_ageb"]}
                break

        zonas = []
        for row in conn.execute("SELECT id, cp, colonia, rings_json FROM colonias_cp;"):
            rings = json.loads(row["rings_json"])
            if point_in_multiring(punto, rings):
                zonas.append({"id": row["id"], "cp": row["cp"], "colonia": row["colonia"]})

        return {"ageb": ageb, "zonas": zonas}
    finally:
        conn.close()


def analizar_por_coordenada(
    lat: float, lon: float, radio_km: float | None = None
) -> tuple[dict[str, float], list[dict], dict]:
    """Punto de entrada para búsquedas por coordenada exacta (lat, lon).

    Con radio_km: agrega el censo de todos los AGEBs dentro de ese radio del punto (igual
    que analizar_por_radio). Sin radio_km: identifica el AGEB exacto que contiene el punto y
    devuelve solo ese (más preciso, pero falla si el punto cae fuera de cualquier AGEB — en
    ese caso hay que agregar un radio). Devuelve (totals, agebs, info_punto), donde
    info_punto trae la Colonia/CP y el AGEB donde cae la coordenada, para mostrarlo al usuario.
    """
    info = identificar_punto(lat, lon)

    if radio_km:
        zona_generica = {"id": None, "cp": None, "colonia": None, "lat": lat, "lon": lon}
        totals, _n, agebs = analizar_zonas([zona_generica], radio_km)
        return totals, agebs, info

    if not info["ageb"]:
        raise ZonaNoEncontradaError(
            "Esa coordenada no cae dentro de ningún AGEB conocido (puede estar fuera de la "
            "zona urbana cubierta por el Marco Geoestadístico). Agrega un radio (km) para "
            "agregar el área alrededor del punto en vez de un AGEB exacto."
        )

    conn = get_connection(SQLITE_DB_PATH)
    try:
        row = conn.execute("SELECT * FROM inegi_censo WHERE cve_geo = ?;", (info["ageb"]["cve_geo"],)).fetchone()
    finally:
        conn.close()

    if not row:
        raise ZonaNoEncontradaError(
            f"El AGEB {info['ageb']['cve_ageb']} que contiene esa coordenada no tiene datos "
            "censales cargados."
        )

    totals = {col: (row[col] or 0.0) for col in NUMERIC_CENSO_COLUMNS}
    return totals, _lista_agebs([row]), info


def rings_por_agebs(cve_geos: list[str]) -> dict[str, list]:
    """Devuelve {cve_geo: rings} para dibujar el polígono de cada AGEB en el mapa."""
    if not cve_geos:
        return {}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT cve_geo, rings_json FROM inegi_geometrias WHERE cve_geo IN ({placeholders});",
            cve_geos,
        ).fetchall()
        return {row["cve_geo"]: json.loads(row["rings_json"]) for row in rows if row["rings_json"]}
    finally:
        conn.close()


CVE_MUN_TIJUANA = "004"


def rings_municipio(cve_mun: str = CVE_MUN_TIJUANA) -> dict[str, list]:
    """Todos los polígonos de AGEB de un municipio (por defecto Tijuana), para usar como
    mapa base de contexto (así se ve toda la ciudad, no solo la zona consultada)."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT cve_geo, rings_json FROM inegi_geometrias WHERE cve_mun = ? AND rings_json IS NOT NULL;",
            (cve_mun,),
        ).fetchall()
        return {row["cve_geo"]: json.loads(row["rings_json"]) for row in rows}
    finally:
        conn.close()


ORDEN_CATEGORIAS_DENUE = [
    "Farmacias",
    "Hospitales",
    "Clínicas (consultorios médicos agrupados)",
    "Consultorios médicos (general y especializada)",
    "Consultorios dentales",
    "Laboratorios clínicos / de análisis",
    "Laboratorios de imagen (radiología/imagenología)",
    "Otros consultorios y servicios de salud",
    "Asistencia social (guarderías, asilos, orientación, etc.)",
    "Otros servicios de salud",
]


def contar_unidades_salud(cve_geos: list[str]) -> dict | None:
    """Cuenta unidades de salud (DENUE, INEGI — sector SCIAN 62) dentro de los AGEBs dados,
    desglosadas por categoría (consultorios médicos, dentales, laboratorios, hospitales,
    asistencia social) — el sector SCIAN 62 es "Salud Y ASISTENCIA SOCIAL", así que sin
    desglosar mezcla clínicas con guarderías/asilos/grupos de autoayuda, que infla el total
    de forma confusa. Devuelve None si la tabla denue_salud no existe (DENUE no cargado —
    es opcional, ver local_engine.etl_local.load_denue_salud)."""
    if not cve_geos:
        return {"unidades_salud": 0, "laboratorios_diagnostico": 0, "desglose": {}}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT categoria, COUNT(*) AS total, COALESCE(SUM(es_laboratorio), 0) AS labs
            FROM denue_salud WHERE cve_geo IN ({placeholders}) GROUP BY categoria;
            """,
            cve_geos,
        ).fetchall()
        desglose = {r["categoria"]: r["total"] for r in rows}
        total = sum(desglose.values())
        labs = sum(r["labs"] or 0 for r in rows)
        return {"unidades_salud": total, "laboratorios_diagnostico": labs, "desglose": desglose}
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


ETIQUETAS_ESEP = {
    "camas_censables": "Camas censables",
    "consultorios": "Consultorios",
    "quirofanos": "Quirófanos",
    "unidades_dentales": "Unidades dentales",
    "lab_analisis_clinicos": "Laboratorios de análisis clínicos",
    "lab_anatomia_patologica": "Laboratorios de anatomía patológica",
    "salas_radiologia": "Salas de radiología",
    "equipos_rayos_x": "Equipos de rayos X",
    "equipos_resonancia_magnetica": "Equipos de resonancia magnética",
    "equipos_tomografia": "Equipos de tomografía (TAC)",
    "equipos_mamografia": "Equipos de mamografía",
    "equipos_ultrasonido": "Equipos de ultrasonido",
}


def obtener_recursos_hospitalarios(cve_geos: list[str]) -> dict | None:
    """Suma el equipamiento real de hospitales privados (ESEP, INEGI — encuesta directa a
    establecimientos, no un directorio de negocios) dentro de los AGEBs dados: camas,
    quirófanos, unidades dentales y equipos de imagenología (rayos X, resonancia, tomografía,
    mamografía, ultrasonido) — esto reemplaza la necesidad de adivinar por nombre qué
    laboratorios son "de imagen"; aquí el dato viene de la encuesta oficial. Devuelve None si
    la tabla no existe (ESEP no cargado, opcional) o no hay hospitales en la zona."""
    if not cve_geos:
        return None
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        campos = ", ".join(f"COALESCE(SUM({c}), 0) AS {c}" for c in ETIQUETAS_ESEP)
        row = conn.execute(
            f"""
            SELECT COUNT(*) AS n_hospitales, {campos}
            FROM esep_recursos_salud WHERE cve_geo IN ({placeholders});
            """,
            cve_geos,
        ).fetchone()
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()

    if not row or row["n_hospitales"] == 0:
        return None
    return {"n_hospitales": row["n_hospitales"], **{c: row[c] for c in ETIQUETAS_ESEP}}


GRADOS_MARGINACION_ORDEN = ["Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"]


def obtener_marginacion(cve_geos: list[str]) -> dict | None:
    """Índice de Marginación Urbana por AGEB de CONAPO (dato OFICIAL de gobierno, no un
    proxy) para el conjunto de AGEBs dado. Promedia el índice normalizado (0-1, donde más
    alto = MENOS marginación/mejor nivel) ponderado por población, y reporta cuántos AGEBs
    caen en cada grado. Devuelve None si la tabla no existe (CONAPO no cargado — opcional)
    o si ninguno de los AGEBs tiene el dato."""
    if not cve_geos:
        return None
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT poblacion, indice_normalizado, grado_marginacion
            FROM marginacion_ageb WHERE cve_geo IN ({placeholders});
            """,
            cve_geos,
        ).fetchall()
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()

    filas = [r for r in rows if r["indice_normalizado"] is not None]
    if not filas:
        return None

    pob_total = sum(r["poblacion"] or 0 for r in filas) or len(filas)
    if pob_total > 0 and any(r["poblacion"] for r in filas):
        promedio = sum((r["indice_normalizado"] or 0) * (r["poblacion"] or 0) for r in filas) / pob_total
    else:
        promedio = sum(r["indice_normalizado"] or 0 for r in filas) / len(filas)

    conteo_grados: dict[str, int] = {}
    for r in filas:
        g = r["grado_marginacion"] or "Sin dato"
        conteo_grados[g] = conteo_grados.get(g, 0) + 1
    grado_predominante = max(conteo_grados, key=lambda g: conteo_grados[g])

    return {
        "indice_normalizado_pct": round(promedio * 100, 1),
        "grado_predominante": grado_predominante,
        "conteo_grados": conteo_grados,
        "n_agebs_con_dato": len(filas),
        "n_agebs_total": len(cve_geos),
    }


def geometria_para_mapa(agebs_incluidos: list[dict]) -> tuple[dict[str, list], set[str]]:
    """Reúne los polígonos a dibujar en el mapa: todos los AGEBs del municipio (como fondo
    de contexto, para ver la ciudad completa) y cuáles de ellos son los incluidos en la
    consulta. Devuelve (rings_por_ageb, cve_geo_incluidos)."""
    cve_incluidos = {a["cve_geo"] for a in agebs_incluidos}
    todos = rings_municipio()
    # Por si algún AGEB incluido no perteneciera al municipio base (caso raro/borde), se agrega igual.
    faltantes = cve_incluidos - todos.keys()
    if faltantes:
        todos.update(rings_por_agebs(list(faltantes)))
    return todos, cve_incluidos


def estimar_edades_15_59(totals: dict[str, float]) -> dict[str, float] | None:
    """Si config.TOTAL_15A29_MUNICIPIO/TOTAL_30A59_MUNICIPIO están configurados, prorratea
    el grupo "15-59 años" de la zona consultada usando esa proporción municipal real (dato
    oficial de INEGI a nivel municipio, no a nivel AGEB). Devuelve None si no hay proporción
    configurada, para no inventar cifras sin fuente. Es una ESTIMACIÓN, no un dato oficial
    a nivel AGEB — se debe presentar siempre marcada como tal.
    """
    if not TOTAL_15A29_MUNICIPIO or not TOTAL_30A59_MUNICIPIO:
        return None
    base_municipio = TOTAL_15A29_MUNICIPIO + TOTAL_30A59_MUNICIPIO
    if base_municipio <= 0:
        return None
    proporcion_15a29 = TOTAL_15A29_MUNICIPIO / base_municipio

    resto_15_59 = max(totals.get("pobtot", 0.0) - totals.get("p_0a14", 0.0) - totals.get("p_60ymas", 0.0), 0.0)
    est_15a29 = resto_15_59 * proporcion_15a29
    est_30a59 = resto_15_59 - est_15a29
    return {"p_15a29_est": est_15a29, "p_30a59_est": est_30a59}


def _indice_socioeconomico_bruto(totals: dict[str, float]) -> float | None:
    """Promedio (0-100) de seis tasas de la zona: piso firme, drenaje, electricidad,
    internet, automóvil y escolaridad. Es solo el número crudo — NO clasificar
    Alto/Medio/Bajo con umbrales absolutos sobre este valor: en zona urbana, drenaje y
    electricidad rondan 95-99% en prácticamente cualquier AGEB (cobertura casi universal),
    así que arrastran el promedio hacia arriba sin importar el nivel real de la zona. Ver
    estimar_nivel_socioeconomico() para la clasificación correcta (por percentil, no
    absoluta)."""
    vivtot = totals.get("vivtot", 0.0)
    pobtot = totals.get("pobtot", 0.0)
    if vivtot <= 0 or pobtot <= 0:
        return None

    tasa_piso_firme = 100 * (1 - totals.get("vph_pisoti", 0.0) / vivtot)
    tasa_drenaje = 100 * totals.get("vph_drenaj", 0.0) / vivtot
    tasa_electricidad = 100 * totals.get("vph_c_elec", 0.0) / vivtot
    tasa_internet = 100 * totals.get("vph_inter", 0.0) / vivtot
    tasa_automovil = 100 * totals.get("vph_autom", 0.0) / vivtot
    tasa_escolaridad = 100 * (1 - totals.get("p15ym_se", 0.0) / pobtot)

    componentes = [tasa_piso_firme, tasa_drenaje, tasa_electricidad, tasa_internet, tasa_automovil, tasa_escolaridad]
    componentes = [max(0.0, min(100.0, c)) for c in componentes]
    return sum(componentes) / len(componentes)


def _percentiles_nse_tijuana() -> tuple[float, float, float] | None:
    """Calcula (p25, p50, p75) del índice socioeconómico bruto sobre TODOS los AGEBs de
    Tijuana, para clasificar cada consulta por su posición relativa dentro de la ciudad —
    no por un corte absoluto. Se recalcula en cada llamada (683 AGEBs, es rápido); no se
    cachea porque los datos pueden cambiar si se vuelve a correr run-etl."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute("SELECT * FROM inegi_censo WHERE cve_mun = ?;", (CVE_MUN_TIJUANA,)).fetchall()
    finally:
        conn.close()

    valores = []
    for row in rows:
        fila = {col: row[col] for col in NUMERIC_CENSO_COLUMNS}
        v = _indice_socioeconomico_bruto(fila)
        if v is not None:
            valores.append(v)
    if not valores:
        return None
    valores.sort()
    n = len(valores)
    return valores[int(n * 0.25)], valores[int(n * 0.5)], valores[int(n * 0.75)]


def estimar_nivel_socioeconomico(totals: dict[str, float]) -> dict | None:
    """Índice compuesto LOCAL (0-100) de nivel socioeconómico, construido únicamente con
    variables del Censo 2020 que ya tenemos por AGEB: acceso a servicios de la vivienda
    (drenaje, electricidad), bienes/conectividad del hogar (internet, automóvil), condición
    de la vivienda (piso firme) y escolaridad.

    La etiqueta Alto/Medio/Bajo/Muy bajo se asigna por PERCENTIL relativo a la distribución
    real de todos los AGEBs de Tijuana (cuartiles), no por un umbral absoluto — un corte fijo
    (ej. ">=70 = Alto") clasificaba como "Alto" a más del 90% de la ciudad, porque servicios
    básicos como drenaje/electricidad son casi universales en zona urbana y no discriminan
    nada; con percentiles, "Alto" siempre significa "el 25% mejor posicionado de Tijuana en
    este índice", una comparación relativa objetiva en vez de un estándar absoluto inventado.

    Esto NO es la clasificación oficial de Nivel Socioeconómico (NSE) de AMAI ni un producto
    de INEGI/DataMéxico — es un proxy simple calculable 100% offline con los datos ya
    cargados. Se debe mostrar siempre marcado como estimación/proxy, no como NSE oficial.
    Devuelve None si la zona no tiene viviendas/población (no se puede calcular ninguna tasa).
    """
    indice = _indice_socioeconomico_bruto(totals)
    if indice is None:
        return None

    percentiles = _percentiles_nse_tijuana()
    if percentiles is None:
        return {"indice": round(indice, 1), "nivel": "Sin referencia", "p25": None, "p50": None, "p75": None}

    p25, p50, p75 = percentiles
    if indice >= p75:
        nivel = "Alto"
    elif indice >= p50:
        nivel = "Medio"
    elif indice >= p25:
        nivel = "Bajo"
    else:
        nivel = "Muy bajo"

    return {
        "indice": round(indice, 1),
        "nivel": nivel,
        "p25": round(p25, 1),
        "p50": round(p50, 1),
        "p75": round(p75, 1),
    }


def exportar_a_csv(
    totals: dict[str, float],
    tipo_busqueda: str,
    valor_busqueda: str,
    output_path: Path | None = None,
    agebs: list[dict] | None = None,
) -> Path:
    if output_path is None:
        safe_valor = "".join(c if c.isalnum() else "_" for c in valor_busqueda)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = OUTPUT_DIR / f"reporte_{tipo_busqueda}_{safe_valor}_{timestamp}.csv"

    with output_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["Reporte de Análisis de Locación — INEGI"])
        writer.writerow(["Tipo de búsqueda", tipo_busqueda])
        writer.writerow(["Valor buscado", valor_busqueda])
        writer.writerow(["Fuente", FUENTE_DATOS])
        writer.writerow(["Fecha de datos", FECHA_DATOS])
        writer.writerow(["Fecha de generación", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        writer.writerow([])

        for categoria, variables in CATEGORIAS.items():
            writer.writerow([categoria.replace("_", " / ")])
            writer.writerow(["Indicador", "Valor"])
            estimado = estimar_edades_15_59(totals) if categoria == "Poblacion" else None
            for var in variables:
                if var in VARIABLES_NO_DISPONIBLES_AGEB:
                    if estimado is not None:
                        valor_est = round(estimado[f"{var}_est"], 2)
                        writer.writerow([
                            VARIABLE_LABELS[var],
                            f"~{valor_est} (ESTIMADO, prorrateo municipal — no es dato oficial de INEGI a nivel AGEB)",
                        ])
                    else:
                        writer.writerow([VARIABLE_LABELS[var], "No publicado por INEGI a nivel AGEB"])
                else:
                    writer.writerow([VARIABLE_LABELS[var], round(totals.get(var, 0.0), 2)])
            if categoria == "Educacion_Socioeconomico":
                marg = obtener_marginacion([a["cve_geo"] for a in agebs]) if agebs else None
                if marg is not None:
                    desglose = ", ".join(f"{n} {g}" for g, n in marg["conteo_grados"].items())
                    writer.writerow([
                        "Marginación urbana (CONAPO, índice OFICIAL)",
                        f"{marg['grado_predominante']} — índice normalizado {marg['indice_normalizado_pct']}/100 "
                        f"(más alto = menos marginación) — AGEBs: {desglose}",
                    ])
                nse = estimar_nivel_socioeconomico(totals)
                if nse is not None:
                    ref = f" (percentiles Tijuana: p25={nse['p25']}, p50={nse['p50']}, p75={nse['p75']})" if nse["p25"] is not None else ""
                    writer.writerow([
                        "Nivel socioeconómico (índice estimado, no oficial)",
                        f"{nse['indice']}/100 ({nse['nivel']}, por percentil relativo a Tijuana){ref} — proxy local, "
                        "no es la clasificación oficial NSE de AMAI/INEGI",
                    ])
            elif categoria == "Salud":
                conteo_salud = contar_unidades_salud([a["cve_geo"] for a in agebs]) if agebs else None
                if conteo_salud is not None and conteo_salud["unidades_salud"] > 0:
                    writer.writerow(["Unidades de salud, total (DENUE, INEGI: sector SCIAN 62 + farmacias SCIAN 4641)", conteo_salud["unidades_salud"]])
                    for cat in ORDEN_CATEGORIAS_DENUE:
                        n = conteo_salud["desglose"].get(cat)
                        if n:
                            writer.writerow([f"  └ {cat}", n])
                rec = obtener_recursos_hospitalarios([a["cve_geo"] for a in agebs]) if agebs else None
                if rec is not None:
                    writer.writerow([
                        "Hospitales privados con equipamiento verificado (ESEP, INEGI, encuesta 2025)",
                        rec["n_hospitales"],
                    ])
                    for campo, etiqueta in ETIQUETAS_ESEP.items():
                        if rec[campo]:
                            writer.writerow([f"  └ {etiqueta}", rec[campo]])
            writer.writerow([])

        if agebs:
            writer.writerow([f"AGEBs incluidos en la consulta ({len(agebs)}) — para auditar contra INEGI"])
            writer.writerow(["Clave AGEB (cve_ageb)", "Clave completa (cve_geo)", "Población total (pobtot)"])
            for ageb in sorted(agebs, key=lambda a: a["cve_geo"]):
                writer.writerow([ageb["cve_ageb"], ageb["cve_geo"], round(ageb["pobtot"], 2)])
            writer.writerow([])

    logger.info("Reporte exportado a %s", output_path)
    return output_path
