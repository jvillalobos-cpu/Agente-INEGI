"""Lector de webmaps de ArcGIS Online (JSON de featureCollection embebida) en Python puro.

Formato usado por mapas interactivos tipo ArcGIS Web AppBuilder/Experience Builder,
donde la geometría y atributos vienen embebidos directamente en el JSON del webmap
(item.data en la API de ArcGIS Online), sin necesitar llamadas adicionales a un
FeatureServer. Las coordenadas suelen venir en Web Mercator (EPSG:3857).
"""
import json
from pathlib import Path
from typing import NamedTuple

from local_engine.projections import web_mercator_to_lonlat


class WebmapFeature(NamedTuple):
    attributes: dict
    rings: list[list[tuple[float, float]]]  # en lon/lat (ya reproyectadas)


def list_layers(path: Path) -> list[dict]:
    """Devuelve [{'index': i, 'title': ..., 'geometry_type': ..., 'n_features': ...}, ...]."""
    with path.open(encoding="utf-8-sig") as f:
        data = json.load(f)

    resumen = []
    for i, layer in enumerate(data.get("operationalLayers", [])):
        title = layer.get("title") or layer.get("id")
        fc_layers = layer.get("featureCollection", {}).get("layers", [])
        geom_type = None
        n_features = 0
        if fc_layers:
            fset = fc_layers[0].get("featureSet", {})
            geom_type = fset.get("geometryType")
            n_features = len(fset.get("features", []))
        resumen.append(
            {"index": i, "title": title, "geometry_type": geom_type, "n_features": n_features}
        )
    return resumen


def read_layer(path: Path, layer_index: int, reproject_web_mercator: bool = True) -> list[WebmapFeature]:
    """Lee las features (solo polígonos) de operationalLayers[layer_index]."""
    with path.open(encoding="utf-8-sig") as f:
        data = json.load(f)

    layer = data["operationalLayers"][layer_index]
    fc_layers = layer.get("featureCollection", {}).get("layers", [])
    if not fc_layers:
        return []

    fset = fc_layers[0].get("featureSet", {})
    if fset.get("geometryType") not in ("esriGeometryPolygon",):
        raise ValueError(
            f"La capa {layer_index} no es de tipo polígono (es {fset.get('geometryType')})."
        )

    features = []
    for feat in fset.get("features", []):
        geom = feat.get("geometry") or {}
        rings_raw = geom.get("rings", [])
        if reproject_web_mercator:
            rings = [[web_mercator_to_lonlat(x, y) for x, y in ring] for ring in rings_raw]
        else:
            rings = [[(x, y) for x, y in ring] for ring in rings_raw]
        features.append(WebmapFeature(attributes=feat.get("attributes") or {}, rings=rings))

    return features
