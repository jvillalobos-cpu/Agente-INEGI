"""ETL 100% Python estándar: shapefiles + CSV del censo -> SQLite.

Sin geopandas/pandas/PostGIS. Idempotente vía INSERT ... ON CONFLICT (upsert nativo SQLite).
"""
import csv
import json
import sqlite3
from pathlib import Path

from config import (
    AGEB_SHAPEFILE_GLOB,
    CENSO_CLAVE_COLUMNS,
    CENSO_CSV_GLOB,
    CENSO_DIR,
    CLAVE_COLUMNS,
    CP_COLONIAS_CSV_GLOB,
    CP_COLONIAS_DIR,
    CP_COLONIAS_SHAPEFILE_GLOB,
    CP_COLONIAS_WEBMAP_LAYER_INDEX,
    DENUE_DIR,
    ESEP_DIR,
    MARCO_GEOESTADISTICO_DIR,
    MARGINACION_DIR,
    SQLITE_DB_PATH,
)
from local_engine.dbf_reader import read_dbf
from local_engine.db_sqlite import get_connection, setup_database
from local_engine.esri_webmap_reader import list_layers as list_webmap_layers
from local_engine.esri_webmap_reader import read_layer as read_webmap_layer
from local_engine.geojson_reader import read_geojson
from local_engine.geometry import multiring_centroid, point_in_multiring
from local_engine.projections import lcc_from_prj_wkt
from local_engine.shapefile_reader import read_shp
from logger_setup import get_logger

logger = get_logger("etl_local")

# Mapeo (columna_real_del_CSV_INEGI, columna_destino). `None` como origen significa que
# el Censo 2020 no publica esa variable a nivel AGEB (solo existe en microdatos); queda en 0
# y se advierte en el log en vez de inventar un valor. Verificado contra
# conjunto_de_datos_ageb_urbana_02_cpv2020.csv (230 columnas, INEGI CPV2020).
CENSO_COLUMN_MAP: list[tuple[str | None, str]] = [
    ("VIVTOT", "vivtot"), ("TVIVPARHAB", "tvivparhab"), ("VIVPAR_DES", "vivpar_des"),
    ("VPH_PISOTI", "vph_pisoti"), ("VPH_C_ELEC", "vph_c_elec"), ("VPH_EXCSA", "vph_excsa"),
    ("VPH_DRENAJ", "vph_drenaj"), ("POBTOT", "pobtot"), ("POBFEM", "pobfem"), ("POBMAS", "pobmas"),
    ("POB0_14", "p_0a14"), (None, "p_15a29"), (None, "p_30a59"), ("P_60YMAS", "p_60ymas"),
    ("PCON_DISC", "pcon_disc"), ("P15YM_SE", "p15ym_se"), ("VPH_INTER", "vph_inter"),
    ("VPH_AUTOM", "vph_autom"), ("PDER_SS", "pder_ss"), ("PDER_IMSS", "pder_imss"),
    ("PDER_ISTE", "pder_iste"), ("PDER_SEGP", "pder_segpub"), ("PSINDER", "psinder"),
]
NUMERIC_CENSO_COLUMNS = [dest for _src, dest in CENSO_COLUMN_MAP]


def _clean_numero(valor: str) -> float:
    valor = (valor or "").strip()
    if valor in ("*", "N/D", "", "nan"):
        return 0.0
    try:
        return float(valor)
    except ValueError:
        return 0.0


def _extraer_clave_geografica(row: dict) -> tuple[str, str, str, str] | None:
    """Obtiene (cve_ent, cve_mun, cve_loc, cve_ageb) desde un registro de atributos de shapefile.

    Soporta dos formatos usados por INEGI según la fuente: un solo campo CVEGEO (13 caracteres:
    2+3+4+4) como en SCINCE, o columnas separadas CVE_ENT/CVE_MUN/CVE_LOC/CVE_AGEB.
    """
    if "CVEGEO" in row and row["CVEGEO"].strip():
        cvegeo = row["CVEGEO"].strip().zfill(13)
        if len(cvegeo) != 13:
            return None
        return cvegeo[0:2], cvegeo[2:5], cvegeo[5:9], cvegeo[9:13]
    if all(k in row for k in CLAVE_COLUMNS):
        return (
            row["CVE_ENT"].strip().zfill(2),
            row["CVE_MUN"].strip().zfill(3),
            row["CVE_LOC"].strip().zfill(4),
            row["CVE_AGEB"].strip().zfill(4),
        )
    return None


def _es_webmap_json(path: Path) -> bool:
    """Distingue un webmap de ArcGIS Online (item.data) de un GeoJSON normal."""
    try:
        with path.open(encoding="utf-8-sig") as f:
            head = f.read(4096)
        return '"operationalLayers"' in head
    except Exception:
        return False


def _find_files(directory: Path, pattern: str) -> list[Path]:
    if not directory.exists():
        logger.warning("Directorio no encontrado: %s", directory)
        return []
    return sorted(directory.glob(pattern))


def load_marco_geoestadistico(conn: sqlite3.Connection) -> None:
    shapefiles = _find_files(MARCO_GEOESTADISTICO_DIR, AGEB_SHAPEFILE_GLOB)
    if not shapefiles:
        logger.warning("No se encontraron shapefiles de AGEB en %s", MARCO_GEOESTADISTICO_DIR)
        return

    for shp_path in shapefiles:
        dbf_path = shp_path.with_suffix(".dbf")
        if not dbf_path.exists():
            logger.error("Falta el .dbf correspondiente a %s. Se omite.", shp_path.name)
            continue

        logger.info("Procesando shapefile geoestadístico: %s", shp_path.name)
        try:
            shapes = read_shp(shp_path)
            attrs = read_dbf(dbf_path)
        except Exception:
            logger.exception("Error leyendo %s / %s", shp_path.name, dbf_path.name)
            continue

        reproyector = None
        prj_path = shp_path.with_suffix(".prj")
        if prj_path.exists():
            prj_text = prj_path.read_text(encoding="utf-8", errors="replace")
            if "PROJCS" in prj_text:
                # Tiene un sistema proyectado (metros), no lon/lat directo. Se asume LCC 2SP
                # (la proyección estándar de la cartografía de INEGI); si no lo es, se registra
                # el error y se continúa sin reproyectar.
                try:
                    reproyector = lcc_from_prj_wkt(prj_text)
                    logger.info(
                        "%s: detectada proyección Lambert Cónica Conforme; se reproyectará a lon/lat.",
                        shp_path.name,
                    )
                except Exception:
                    logger.warning(
                        "%s tiene un sistema proyectado no reconocido (no es LCC 2SP); "
                        "las coordenadas quedarán sin reproyectar.",
                        shp_path.name,
                    )

        if len(shapes) != len(attrs):
            logger.error(
                "%s: número de shapes (%d) no coincide con registros .dbf (%d). Se omite.",
                shp_path.name, len(shapes), len(attrs),
            )
            continue

        attrs_upper = [{k.upper(): v for k, v in row.items()} for row in attrs]
        if attrs_upper and _extraer_clave_geografica(attrs_upper[0]) is None:
            logger.error(
                "%s no contiene ni CVEGEO ni columnas de clave %s. Se omite.",
                shp_path.name, CLAVE_COLUMNS,
            )
            continue

        rows = []
        for shape, row in zip(shapes, attrs_upper):
            if not shape.rings:
                continue
            clave = _extraer_clave_geografica(row)
            if clave is None:
                continue
            cve_ent, cve_mun, cve_loc, cve_ageb = clave
            cve_geo = cve_ent + cve_mun + cve_loc + cve_ageb
            rings = shape.rings
            if reproyector is not None:
                rings = [[reproyector.inverse(x, y) for x, y in ring] for ring in rings]
            cx, cy = multiring_centroid(rings)
            rows.append((cve_geo, cve_ent, cve_mun, cve_loc, cve_ageb, "ageb", cx, cy, json.dumps(rings)))

        conn.executemany(
            """
            INSERT INTO inegi_geometrias
                (cve_geo, cve_ent, cve_mun, cve_loc, cve_ageb, nivel, centroid_x, centroid_y, rings_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (cve_geo) DO UPDATE SET
                cve_ent = excluded.cve_ent, cve_mun = excluded.cve_mun,
                cve_loc = excluded.cve_loc, cve_ageb = excluded.cve_ageb,
                nivel = excluded.nivel, centroid_x = excluded.centroid_x,
                centroid_y = excluded.centroid_y, rings_json = excluded.rings_json;
            """,
            rows,
        )
        conn.commit()
        logger.info("Insertadas/actualizadas %d geometrías desde %s.", len(rows), shp_path.name)


def load_censo(conn: sqlite3.Connection) -> None:
    csv_files = _find_files(CENSO_DIR, CENSO_CSV_GLOB)
    if not csv_files:
        logger.warning("No se encontraron archivos CSV del censo en %s", CENSO_DIR)
        return

    for csv_path in csv_files:
        logger.info("Procesando CSV del censo: %s", csv_path.name)
        try:
            with csv_path.open(encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                rows_raw = [{k.upper().strip(): v for k, v in row.items()} for row in reader]
        except Exception:
            logger.exception("Error leyendo CSV %s", csv_path)
            continue

        if not rows_raw:
            continue
        # Claves del CSV tabular de INEGI (distintas de las del shapefile, que usan prefijo CVE_).
        missing_keys = [c for c in CENSO_CLAVE_COLUMNS if c not in rows_raw[0]]
        if missing_keys:
            logger.error("%s no contiene columnas de clave %s. Se omite.", csv_path.name, missing_keys)
            continue

        missing_vars = [src for src, _dest in CENSO_COLUMN_MAP if src and src not in rows_raw[0]]
        if missing_vars:
            logger.warning(
                "%s no contiene las columnas %s; se llenarán con 0.", csv_path.name, missing_vars
            )
        no_disponibles = [dest for src, dest in CENSO_COLUMN_MAP if src is None]
        if no_disponibles:
            logger.warning(
                "Variables no publicadas por INEGI a nivel AGEB (quedan en 0): %s", no_disponibles
            )

        rows = []
        for row in rows_raw:
            mza = row.get("MZA", "").strip()
            if mza and mza != "000":
                continue  # fila de manzana individual; se usa solo el resumen por AGEB (MZA=000)

            cve_ageb = row["AGEB"].strip().zfill(4)
            if cve_ageb in ("0000", ""):
                continue  # totales agregados de municipio/localidad
            cve_ent = row["ENTIDAD"].strip().zfill(2)
            cve_mun = row["MUN"].strip().zfill(3)
            cve_loc = row["LOC"].strip().zfill(4)
            cve_geo = cve_ent + cve_mun + cve_loc + cve_ageb

            values = [cve_geo, cve_ent, cve_mun, cve_loc, cve_ageb]
            for src_col, _dest_col in CENSO_COLUMN_MAP:
                values.append(_clean_numero(row.get(src_col, "0")) if src_col else 0.0)
            rows.append(tuple(values))

        columns = ["cve_geo", "cve_ent", "cve_mun", "cve_loc", "cve_ageb"] + NUMERIC_CENSO_COLUMNS
        placeholders = ", ".join("?" for _ in columns)
        update_clause = ", ".join(f"{c} = excluded.{c}" for c in columns if c != "cve_geo")
        conn.executemany(
            f"""
            INSERT INTO inegi_censo ({', '.join(columns)})
            VALUES ({placeholders})
            ON CONFLICT (cve_geo) DO UPDATE SET {update_clause};
            """,
            rows,
        )
        conn.commit()
        logger.info("Insertados/actualizados %d registros censales desde %s.", len(rows), csv_path.name)


def load_colonias_cp(conn: sqlite3.Connection) -> None:
    shapefiles = _find_files(CP_COLONIAS_DIR, CP_COLONIAS_SHAPEFILE_GLOB)
    if shapefiles:
        for shp_path in shapefiles:
            dbf_path = shp_path.with_suffix(".dbf")
            if not dbf_path.exists():
                logger.error("Falta el .dbf correspondiente a %s. Se omite.", shp_path.name)
                continue
            logger.info("Procesando shapefile de colonias/CP: %s", shp_path.name)
            try:
                shapes = read_shp(shp_path)
                attrs = read_dbf(dbf_path)
            except Exception:
                logger.exception("Error leyendo %s", shp_path.name)
                continue
            _insert_colonias(conn, shapes, attrs, shp_path.name)
        return

    json_files = _find_files(CP_COLONIAS_DIR, "*.geojson") + _find_files(CP_COLONIAS_DIR, "*.json")
    webmap_files = [p for p in json_files if _es_webmap_json(p)]
    geojson_files = [p for p in json_files if p not in webmap_files]

    if webmap_files:
        for wm_path in webmap_files:
            logger.info("Procesando webmap de ArcGIS: %s", wm_path.name)
            try:
                capas = list_webmap_layers(wm_path)
                logger.info(
                    "Capas disponibles en %s: %s", wm_path.name,
                    [(c["index"], c["title"], c["geometry_type"], c["n_features"]) for c in capas],
                )
                idx = CP_COLONIAS_WEBMAP_LAYER_INDEX
                features = read_webmap_layer(wm_path, idx)
            except Exception:
                logger.exception("Error leyendo webmap %s", wm_path.name)
                continue
            _insert_colonias_webmap(conn, features, wm_path.name)
        return

    if geojson_files:
        for gj_path in geojson_files:
            logger.info("Procesando GeoJSON de colonias/CP: %s", gj_path.name)
            try:
                features = read_geojson(gj_path)
            except Exception:
                logger.exception("Error leyendo GeoJSON %s", gj_path.name)
                continue
            _insert_colonias_geojson(conn, features, gj_path.name)
        return

    csv_files = _find_files(CP_COLONIAS_DIR, CP_COLONIAS_CSV_GLOB)
    if not csv_files:
        logger.warning("No se encontró catálogo de colonias/CP en %s", CP_COLONIAS_DIR)
    else:
        logger.error(
            "Se encontraron CSV en %s pero el modo local requiere shapefile (.shp/.dbf) o "
            "GeoJSON (.geojson) con geometría de polígono; el formato CSV con WKT no está "
            "soportado sin librerías.",
            CP_COLONIAS_DIR,
        )


def _insert_colonias_webmap(conn: sqlite3.Connection, features, source_name: str) -> None:
    """Inserta features de un webmap ArcGIS (ej. capa UTP de IMPLAN Tijuana) como colonias.

    UTP (Unidad Territorial de Planeación) es el proxy más cercano a "colonia" disponible
    en la cartografía de planeación urbana pública; no incluye código postal.
    """
    if not features:
        return

    sample_attrs = {k.lower(): k for k in features[0].attributes.keys()}
    col_colonia = next(
        (sample_attrs[k] for k in sample_attrs if k in ("utp", "colonia", "nom_colonia", "name")),
        None,
    )
    col_mun = next(
        (sample_attrs[k] for k in sample_attrs if k in ("delegacion", "municipio", "mun")), None
    )

    if col_colonia is None:
        logger.error(
            "%s no tiene un campo identificable de colonia/UTP. Se omite.", source_name
        )
        return

    rows = []
    for feature in features:
        if not feature.rings:
            continue
        colonia = str(feature.attributes.get(col_colonia, "")).strip()
        municipio = str(feature.attributes.get(col_mun, "")).strip() if col_mun else None
        rings_json = json.dumps(feature.rings)
        rows.append((colonia, None, municipio, rings_json))

    conn.executemany(
        """
        INSERT INTO colonias_cp (colonia, cp, municipio, rings_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT (colonia, cp, municipio) DO UPDATE SET rings_json = excluded.rings_json;
        """,
        rows,
    )
    conn.commit()
    logger.info("Insertadas/actualizadas %d colonias (UTP) desde %s.", len(rows), source_name)


def _insert_colonias_geojson(conn: sqlite3.Connection, features, source_name: str) -> None:
    if not features:
        return

    sample_props = {k.lower(): k for k in features[0].properties.keys()}
    col_colonia = next(
        (sample_props[k] for k in sample_props if k in ("colonia", "nom_colonia", "name", "asent")),
        None,
    )
    col_cp = next((sample_props[k] for k in sample_props if k in ("cp", "d_cp", "codigo_postal", "postal_code")), None)
    col_mun = next((sample_props[k] for k in sample_props if k in ("municipio", "mun", "d_mnpio")), None)

    if col_colonia is None and col_cp is None:
        logger.error(
            "%s no tiene propiedades identificables de colonia/CP (busqué 'name'/'colonia'/'cp'). Se omite.",
            source_name,
        )
        return

    rows = []
    for feature in features:
        if not feature.rings:
            continue
        colonia = str(feature.properties.get(col_colonia, "")).strip() if col_colonia else None
        cp = str(feature.properties.get(col_cp, "")).strip() if col_cp else None
        municipio = str(feature.properties.get(col_mun, "")).strip() if col_mun else None
        rings_json = json.dumps(feature.rings)
        rows.append((colonia, cp, municipio, rings_json))

    conn.executemany(
        """
        INSERT INTO colonias_cp (colonia, cp, municipio, rings_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT (colonia, cp, municipio) DO UPDATE SET rings_json = excluded.rings_json;
        """,
        rows,
    )
    conn.commit()
    logger.info("Insertadas/actualizadas %d colonias/CP desde %s.", len(rows), source_name)


def _insert_colonias(conn: sqlite3.Connection, shapes, attrs, source_name: str) -> None:
    if len(shapes) != len(attrs):
        logger.error(
            "%s: shapes (%d) != registros .dbf (%d). Se omite.", source_name, len(shapes), len(attrs)
        )
        return

    sample_keys = {k.lower() for k in attrs[0].keys()} if attrs else set()
    col_colonia = next((k for k in attrs[0] if k.lower() in ("colonia", "nom_colonia", "asent")), None) if attrs else None
    col_cp = next((k for k in attrs[0] if k.lower() in ("cp", "d_cp", "codigo_postal")), None) if attrs else None
    col_mun = next((k for k in attrs[0] if k.lower() in ("municipio", "mun", "d_mnpio")), None) if attrs else None

    if col_colonia is None and col_cp is None:
        logger.error("%s no tiene columnas identificables de colonia/CP. Se omite.", source_name)
        return

    rows = []
    for shape, row in zip(shapes, attrs):
        if not shape.rings:
            continue
        colonia = row.get(col_colonia, "").strip() if col_colonia else None
        cp = row.get(col_cp, "").strip() if col_cp else None
        municipio = row.get(col_mun, "").strip() if col_mun else None
        rings_json = json.dumps(shape.rings)
        rows.append((colonia, cp, municipio, rings_json))

    conn.executemany(
        """
        INSERT INTO colonias_cp (colonia, cp, municipio, rings_json)
        VALUES (?, ?, ?, ?)
        ON CONFLICT (colonia, cp, municipio) DO UPDATE SET rings_json = excluded.rings_json;
        """,
        rows,
    )
    conn.commit()
    logger.info("Insertadas/actualizadas %d colonias/CP desde %s.", len(rows), source_name)


def build_asignaciones(conn: sqlite3.Connection) -> None:
    """Fase 3 local: asigna cada AGEB a una colonia si el centroide del AGEB cae dentro
    del polígono de la colonia (ver docstring de geometry.py para el porqué)."""
    logger.info("Calculando asignación Colonia/CP -> AGEB por centroide...")
    conn.execute("DELETE FROM colonia_ageb_asignacion;")

    agebs = conn.execute(
        "SELECT cve_geo, centroid_x, centroid_y FROM inegi_geometrias;"
    ).fetchall()
    colonias = conn.execute("SELECT id, rings_json FROM colonias_cp;").fetchall()

    if agebs and colonias:
        ax, ay = agebs[0]["centroid_x"], agebs[0]["centroid_y"]
        primer_ring = json.loads(colonias[0]["rings_json"])[0]
        cx, cy = primer_ring[0]
        ageb_es_lonlat = abs(ax) <= 180 and abs(ay) <= 90
        colonia_es_lonlat = abs(cx) <= 180 and abs(cy) <= 90
        if ageb_es_lonlat != colonia_es_lonlat:
            logger.warning(
                "Los AGEBs y las colonias parecen estar en sistemas de coordenadas distintos "
                "(AGEB: %s,%s | colonia: %s,%s). Esto hará que ninguna asignación coincida. "
                "El modo local no reproyecta automáticamente: asegúrate de que ambos shapefiles/"
                "GeoJSON estén en el mismo CRS (idealmente WGS84 / EPSG:4326, lon/lat).",
                ax, ay, cx, cy,
            )

    asignaciones = []
    for colonia in colonias:
        rings = json.loads(colonia["rings_json"])
        for ageb in agebs:
            point = (ageb["centroid_x"], ageb["centroid_y"])
            if point_in_multiring(point, rings):
                asignaciones.append((colonia["id"], ageb["cve_geo"]))

    conn.executemany(
        "INSERT OR IGNORE INTO colonia_ageb_asignacion (colonia_cp_id, cve_geo) VALUES (?, ?);",
        asignaciones,
    )
    conn.commit()
    logger.info("Asignaciones calculadas: %d.", len(asignaciones))


CODIGOS_FARMACIA = {"464111", "464112"}

# SCIAN no separa laboratorios de imagen (radiología/imagenología) de laboratorios clínicos
# (análisis de sangre, etc.) — ambos caen en la misma clase 6215 "Laboratorios médicos y de
# diagnóstico". Para poder distinguirlos usamos el NOMBRE del establecimiento como pista
# (heurística, no una clasificación oficial): si contiene palabras típicas de imagenología.
_PALABRAS_IMAGEN = (
    "IMAGEN", "RADIOLOG", "RAYOS X", "RAYOS-X", "TOMOGRAF", "RESONANCIA",
    "ECOGRAF", "ULTRASONID", "MAMOGRAF", "NUCLEAR", "ESCANER", "ESCÁNER",
)


def _categoria_denue_salud(codigo_act: str, nom_estab: str = "") -> str:
    """Clasifica un establecimiento del DENUE en categorías finas de salud. El sector SCIAN
    62 ("Servicios de salud y de asistencia social") incluye de todo — no solo clínicas —
    así que sin desglosar, "unidades de salud" mezcla hospitales con guarderías, asilos o
    grupos de autoayuda. Las farmacias (SCIAN 4641, sector Comercio) se agregan aparte
    porque no caen en el sector 62 pero son clave para el análisis de salud de una zona."""
    if codigo_act in CODIGOS_FARMACIA:
        return "Farmacias"
    if codigo_act.startswith("622"):
        return "Hospitales"
    if codigo_act in ("621115", "621116"):
        return "Clínicas (consultorios médicos agrupados)"
    if codigo_act in ("621111", "621112", "621113"):
        return "Consultorios médicos (general y especializada)"
    if codigo_act.startswith("6212"):
        return "Consultorios dentales"
    if codigo_act.startswith("6215"):
        if any(palabra in (nom_estab or "").upper() for palabra in _PALABRAS_IMAGEN):
            return "Laboratorios de imagen (radiología/imagenología)"
        return "Laboratorios clínicos / de análisis"
    if codigo_act.startswith("621"):
        return "Otros consultorios y servicios de salud"
    if codigo_act.startswith("623") or codigo_act.startswith("624"):
        return "Asistencia social (guarderías, asilos, orientación, etc.)"
    return "Otros servicios de salud"


def load_denue_salud(conn: sqlite3.Connection) -> None:
    """Carga el sector Salud (SCIAN 62) + farmacias (SCIAN 4641, sector Comercio) del DENUE
    (INEGI), clasificados en categorías finas (farmacias, hospitales, clínicas, consultorios
    médicos/dentales, laboratorios clínicos/de imagen, asistencia social...). El DENUE ya
    trae cada establecimiento geocodificado a su AGEB (columnas cve_ent/cve_mun/cve_loc/ageb),
    así que se arma cve_geo directo con esas columnas — no hace falta punto-en-polígono.
    Es opcional: si no se encuentra el CSV, se omite sin error (el resto del sistema sigue
    funcionando)."""
    if not DENUE_DIR.is_dir():
        logger.info("No existe %s; se omite la carga de DENUE (unidades de salud).", DENUE_DIR)
        return

    candidatos = [p for p in DENUE_DIR.rglob("*.csv") if "diccionario" not in p.name.lower()]
    if not candidatos:
        logger.info("No se encontró ningún CSV de DENUE en %s; se omite.", DENUE_DIR)
        return
    csv_path = candidatos[0]

    rows = []
    with csv_path.open(encoding="latin-1", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            codigo = (row.get("codigo_act") or "").strip()
            if not (codigo.startswith("62") or codigo in CODIGOS_FARMACIA):
                continue
            cve_ent = (row.get("cve_ent") or "").strip()
            cve_mun = (row.get("cve_mun") or "").strip()
            cve_loc = (row.get("cve_loc") or "").strip()
            ageb = (row.get("ageb") or "").strip()
            if not (cve_ent and cve_mun and cve_loc and ageb):
                continue
            cve_geo = cve_ent + cve_mun + cve_loc + ageb
            categoria = _categoria_denue_salud(codigo, row.get("nom_estab", ""))
            es_lab = 1 if codigo.startswith("6215") else 0
            try:
                lat = float(row["latitud"]) if row.get("latitud") else None
                lon = float(row["longitud"]) if row.get("longitud") else None
            except ValueError:
                lat = lon = None
            rows.append((row["id"], cve_geo, codigo, row.get("nombre_act", ""), categoria, es_lab, lat, lon))

    if not rows:
        logger.warning("%s no contiene establecimientos del sector Salud (SCIAN 62). Se omite.", csv_path.name)
        return

    conn.executemany(
        """
        INSERT INTO denue_salud (id, cve_geo, codigo_act, nombre_act, categoria, es_laboratorio, lat, lon)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (id) DO UPDATE SET
            cve_geo = excluded.cve_geo, codigo_act = excluded.codigo_act,
            nombre_act = excluded.nombre_act, categoria = excluded.categoria,
            es_laboratorio = excluded.es_laboratorio, lat = excluded.lat, lon = excluded.lon;
        """,
        rows,
    )
    conn.commit()
    n_labs = sum(1 for r in rows if r[5] == 1)
    logger.info(
        "Insertados/actualizados %d establecimientos de salud desde %s (%d laboratorios de diagnóstico).",
        len(rows), csv_path.name, n_labs,
    )


def load_marginacion(conn: sqlite3.Connection) -> None:
    """Carga el Índice de Marginación Urbana por AGEB de CONAPO (organismo oficial de
    gobierno) — fuente pública gratuita, alternativa oficial a la clasificación privada NSE
    de AMAI. Opcional: si no se encuentra el CSV, se omite sin error."""
    if not MARGINACION_DIR.is_dir():
        logger.info("No existe %s; se omite la carga del índice de marginación CONAPO.", MARGINACION_DIR)
        return

    candidatos = list(MARGINACION_DIR.rglob("*.csv"))
    if not candidatos:
        logger.info("No se encontró ningún CSV de marginación en %s; se omite.", MARGINACION_DIR)
        return
    csv_path = candidatos[0]

    rows = []
    with csv_path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cve_geo = (row.get("cve_geo") or "").strip()
            if not cve_geo:
                continue

            def _num(clave):
                val = (row.get(clave) or "").strip()
                return float(val) if val else None

            rows.append((
                cve_geo,
                _num("poblacion"),
                _num("indice_marginacion"),
                (row.get("grado_marginacion") or "").strip() or None,
                _num("indice_normalizado"),
            ))

    if not rows:
        logger.warning("%s no contiene registros de marginación válidos. Se omite.", csv_path.name)
        return

    conn.executemany(
        """
        INSERT INTO marginacion_ageb (cve_geo, poblacion, indice_marginacion, grado_marginacion, indice_normalizado)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT (cve_geo) DO UPDATE SET
            poblacion = excluded.poblacion, indice_marginacion = excluded.indice_marginacion,
            grado_marginacion = excluded.grado_marginacion, indice_normalizado = excluded.indice_normalizado;
        """,
        rows,
    )
    conn.commit()
    logger.info("Insertados/actualizados %d AGEBs con índice de marginación CONAPO desde %s.", len(rows), csv_path.name)


ESEP_CAMPOS_NUMERICOS = [
    "personal_medico", "personal_no_medico", "consultorios", "camas_censables", "quirofanos",
    "unidades_dentales", "lab_analisis_clinicos", "lab_anatomia_patologica", "salas_radiologia",
    "equipos_rayos_x", "equipos_resonancia_magnetica", "equipos_tomografia", "equipos_mamografia",
    "equipos_ultrasonido",
]


def load_esep_recursos(conn: sqlite3.Connection) -> None:
    """Carga la ESEP (Estadística de Salud en Establecimientos Particulares, INEGI) —
    equipamiento real de hospitales privados (camas, quirófanos, equipos de rayos X,
    resonancia, tomografía, mamografía, ultrasonido, etc.), geocodificado a AGEB. A
    diferencia del DENUE (que solo cuenta negocios por giro), esto da capacidad real
    verificada por INEGI mediante encuesta directa a los establecimientos. Opcional: si no
    se encuentra el CSV, se omite sin error."""
    if not ESEP_DIR.is_dir():
        logger.info("No existe %s; se omite la carga de ESEP (recursos hospitalarios).", ESEP_DIR)
        return

    candidatos = list(ESEP_DIR.rglob("*.csv"))
    if not candidatos:
        logger.info("No se encontró ningún CSV de ESEP en %s; se omite.", ESEP_DIR)
        return
    csv_path = candidatos[0]

    rows = []
    with csv_path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cve_geo = (row.get("cve_geo") or "").strip()
            if not cve_geo:
                continue
            valores = []
            for campo in ESEP_CAMPOS_NUMERICOS:
                val = (row.get(campo) or "").strip()
                valores.append(int(val) if val else 0)
            rows.append((cve_geo, (row.get("tipo_establecimiento") or "").strip(), *valores))

    if not rows:
        logger.warning("%s no contiene registros de ESEP válidos. Se omite.", csv_path.name)
        return

    conn.execute("DELETE FROM esep_recursos_salud;")  # sin llave natural: recarga completa, no upsert
    conn.executemany(
        f"""
        INSERT INTO esep_recursos_salud (cve_geo, tipo_establecimiento, {", ".join(ESEP_CAMPOS_NUMERICOS)})
        VALUES ({", ".join("?" for _ in range(2 + len(ESEP_CAMPOS_NUMERICOS)))});
        """,
        rows,
    )
    conn.commit()
    logger.info("Insertados %d hospitales privados con recursos/equipamiento (ESEP, INEGI) desde %s.", len(rows), csv_path.name)



# Población total de Tijuana (municipio 004), Censo 2020, INEGI (cifra oficial publicada en
# texto, no estimada). Se usa solo como referencia para detectar una carga incompleta o
# corrupta del CSV censal (p. ej. filas truncadas, AGEBs faltantes, columna mal mapeada) —
# no se usa en ningún cálculo de consulta, solo en validar_carga_censo().
POBTOT_MUNICIPIO_OFICIAL = 1_922_523
# Tolerancia: el CSV censal de INEGI incluye una fila de totales por localidad/municipio
# además de las filas por AGEB: si build_asignaciones u otra etapa cambiara qué filas cuentan,
# o si el archivo viene incompleto, la suma se desvía mucho más de esto.
TOLERANCIA_VALIDACION_PCT = 0.02


def validar_carga_censo(conn: sqlite3.Connection) -> None:
    """Compara la suma de pobtot cargada (nivel AGEB, municipio 004) contra la cifra oficial
    de Tijuana del Censo 2020. Es la única red de seguridad contra una carga silenciosamente
    incompleta o corrupta (INEGI cambia el nombre de alguna columna, el CSV viene truncado,
    etc.) — sin esto, un ETL "exitoso" con datos mal cargados no se distingue de uno correcto
    hasta que alguien nota resultados raros en una consulta. No lanza excepción (el resto de
    la app puede seguir funcionando con lo que sí cargó), pero deja un WARNING inequívoco en
    el log si la desviación excede la tolerancia."""
    row = conn.execute(
        "SELECT COALESCE(SUM(pobtot), 0) AS total, COUNT(*) AS n FROM inegi_censo WHERE cve_mun = '004';"
    ).fetchone()
    total_cargado = row["total"] or 0.0
    n_agebs = row["n"] or 0

    if n_agebs == 0:
        logger.warning(
            "VALIDACIÓN ETL: no se cargó ningún AGEB del municipio 004 (Tijuana) en inegi_censo. "
            "Revisa que el CSV censal (RESAGEBURB) esté en data/censo/ antes de usar el agente."
        )
        return

    desviacion = abs(total_cargado - POBTOT_MUNICIPIO_OFICIAL) / POBTOT_MUNICIPIO_OFICIAL
    if desviacion > TOLERANCIA_VALIDACION_PCT:
        logger.warning(
            "VALIDACIÓN ETL: la población total cargada para Tijuana (%d AGEBs, pobtot=%.0f) "
            "se desvía %.1f%% de la cifra oficial del Censo 2020 (%d). Esto sugiere una carga "
            "incompleta o corrupta del CSV censal — verifica data/censo/ antes de confiar en "
            "los resultados de consultas.",
            n_agebs, total_cargado, desviacion * 100, POBTOT_MUNICIPIO_OFICIAL,
        )
    else:
        logger.info(
            "Validación ETL OK: población cargada para Tijuana (%d AGEBs, pobtot=%.0f) a %.1f%% "
            "de la cifra oficial (%d).",
            n_agebs, total_cargado, desviacion * 100, POBTOT_MUNICIPIO_OFICIAL,
        )


def run_etl_local() -> None:
    setup_database(SQLITE_DB_PATH)
    conn = get_connection(SQLITE_DB_PATH)
    try:
        logger.info("Iniciando ETL local (100%% Python estándar, sin librerías externas)...")
        load_marco_geoestadistico(conn)
        load_censo(conn)
        load_colonias_cp(conn)
        build_asignaciones(conn)
        load_denue_salud(conn)
        load_marginacion(conn)
        load_esep_recursos(conn)
        validar_carga_censo(conn)
        logger.info("ETL local completado exitosamente.")
    except Exception:
        logger.exception("Error durante el ETL local.")
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    run_etl_local()
