"""Lector mínimo de archivos .dbf (dBASE) en Python puro, sin librerías externas.

Los shapefiles siempre vienen acompañados de un .dbf con los atributos de cada shape,
en el mismo orden que los registros del .shp.
"""
import struct
from pathlib import Path


def read_dbf(path: Path) -> list[dict]:
    data = path.read_bytes()

    num_records = struct.unpack_from("<i", data, 4)[0]
    header_length = struct.unpack_from("<h", data, 8)[0]
    record_length = struct.unpack_from("<h", data, 10)[0]

    fields = []
    offset = 32
    while data[offset] != 0x0D:
        name_raw = data[offset : offset + 11]
        name = name_raw.split(b"\x00")[0].decode("latin-1").strip()
        field_type = chr(data[offset + 11])
        length = data[offset + 16]
        fields.append((name, field_type, length))
        offset += 32

    records = []
    cursor = header_length
    for _ in range(num_records):
        raw = data[cursor : cursor + record_length]
        cursor += record_length
        if not raw or raw[0:1] == b"*":
            continue  # registro marcado como eliminado

        row = {}
        pos = 1  # el primer byte es la bandera de borrado
        for name, field_type, length in fields:
            value_bytes = raw[pos : pos + length]
            pos += length
            text = value_bytes.decode("latin-1", errors="replace").strip()
            row[name] = text
        records.append(row)

    return records
