"""Mapa interactivo con tiles reales (calles, relieve) vía Leaflet.js, servido 100% local
(sin CDN, sin llamadas de red en tiempo de uso) — ver local_engine/setup_mapa.py para cómo se
descargan los assets (una vez, con internet) antes de poder usar este renderer.

Se usa en vez del mapa SVG propio (local_engine/svg_map.py) cuando los assets ya están
descargados; server.py decide cuál de los dos usar según existan o no en disco.
"""
import json
import uuid

from config import TILE_MAX_ZOOM_DESCARGADO


def render_mapa_leaflet(
    agebs_rings: dict[str, list],
    incluidos: set[str],
    zonas_todas: list[dict],
    zonas_activas_ids: set,
    radio_km: float | None = None,
    color_incluido: str = "#3f6fb0",
    color_excluido: str = "#8f97a3",
) -> str:
    """Devuelve (<div id="...">, <script>) como un solo string HTML: un mapa Leaflet con
    tiles OSM de fondo (calles, nombres, relieve real), los AGEBs de Tijuana como capa
    vectorial (resaltados los incluidos en la consulta) y un marcador clicable por cada zona
    coincidente (Colonia/CP), enlazado al mismo checkbox que ya usa el mapa SVG — para que el
    resto del formulario (incluir/excluir zona, recalcular) funcione igual sin cambios."""
    centros = [z for z in zonas_todas if z["id"] in zonas_activas_ids]

    features = []
    for cve_geo, rings in agebs_rings.items():
        features.append({
            "type": "Feature",
            "properties": {"cve_geo": cve_geo, "incluido": cve_geo in incluidos},
            "geometry": {"type": "Polygon", "coordinates": rings},
        })
    geojson = {"type": "FeatureCollection", "features": features}

    zonas_data = [
        {
            "id": z["id"],
            "lat": z["lat"],
            "lon": z["lon"],
            "titulo": f"CP {z['cp']} — {z['colonia']}",
            "activa": z["id"] in zonas_activas_ids,
        }
        for z in zonas_todas
    ]

    centro_lat_lon = None
    if centros:
        centro_lat_lon = [
            sum(c["lat"] for c in centros) / len(centros),
            sum(c["lon"] for c in centros) / len(centros),
        ]

    # Centro de respaldo (todo Tijuana) para cuando no hay zona/centro de búsqueda (p. ej.
    # consulta directa por AGEB) — necesario para poder llamar map.setView() ANTES de agregar
    # cualquier capa (ver MAPA_LEAFLET_SCRIPT: sin vista inicial, Leaflet truena al dibujar
    # los polígonos y toda la capa de AGEBs/marcadores/radio se queda sin mostrar).
    city_center = None
    todos_los_puntos = [pt for rings in agebs_rings.values() for ring in rings for pt in ring]
    if todos_los_puntos:
        lons = [p[0] for p in todos_los_puntos]
        lats = [p[1] for p in todos_los_puntos]
        city_center = [(min(lats) + max(lats)) / 2, (min(lons) + max(lons)) / 2]

    map_id = f"mapa-leaflet-{uuid.uuid4().hex[:8]}"
    config = {
        "geojson": geojson,
        "zonas": zonas_data,
        "radioKm": radio_km,
        "centro": centro_lat_lon,
        "cityCenter": city_center,
        "tileMaxZoom": TILE_MAX_ZOOM_DESCARGADO,
        "colorIncluido": color_incluido,
        "colorExcluido": color_excluido,
    }
    config_json = json.dumps(config, ensure_ascii=False)

    return (
        f'<div id="{map_id}" class="mapa-leaflet" data-config="{_html_attr_escape(config_json)}" '
        'style="width:100%;height:520px;border-radius:10px;border:1px solid var(--border);"></div>'
    )


def _html_attr_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


MAPA_LEAFLET_SCRIPT = """
<script>
(function () {
  function iniciarMapa(div) {
    if (typeof L === 'undefined') return; // leaflet.js no cargó (assets faltantes); no truena el resto de la página
    var cfg = JSON.parse(div.getAttribute('data-config'));
    var map = L.map(div, { scrollWheelZoom: false });
    // Leaflet necesita una vista (centro/zoom) ANTES de agregar capas vectoriales — si no,
    // internamente no puede calcular el recorte de los polígonos y truena en silencio (el
    // resto del script nunca corre: ni AGEBs resaltados, ni marcadores, ni círculo de radio).
    map.setView(cfg.centro || cfg.cityCenter || [32.5027, -117.0037], cfg.centro ? 14 : 11);
    L.tileLayer('/tiles/{z}/{x}/{y}.png', {
      // maxNativeZoom = zoom más alto realmente descargado (setup_mapa.py --zoom-max, 14 por
      // defecto); más allá de eso Leaflet AMPLÍA ese mismo tile en vez de pedir uno que no
      // existe (evita el fondo en blanco al acercarse mucho).
      maxNativeZoom: cfg.tileMaxZoom || 14, maxZoom: 19, minZoom: 3,
      attribution: '&copy; colaboradores de OpenStreetMap',
    }).addTo(map);

    var capaAgebs = L.geoJSON(cfg.geojson, {
      style: function (feature) {
        var incluido = feature.properties.incluido;
        return {
          color: incluido ? '#ffffff' : cfg.colorExcluido,
          weight: incluido ? 2 : 0.6,
          fillColor: incluido ? cfg.colorIncluido : cfg.colorExcluido,
          fillOpacity: incluido ? 0.55 : 0.12,
        };
      },
    }).addTo(map);

    if (cfg.radioKm && cfg.centro) {
      L.circle(cfg.centro, {
        radius: cfg.radioKm * 1000,
        color: cfg.colorIncluido, weight: 1.5, dashArray: '4 3',
        fillColor: cfg.colorIncluido, fillOpacity: 0.08,
      }).addTo(map);
    }

    cfg.zonas.forEach(function (z) {
      var marker = L.circleMarker([z.lat, z.lon], {
        radius: 7,
        color: '#fff', weight: 2,
        fillColor: z.activa ? '#c0392b' : '#8f97a3',
        fillOpacity: 1,
      }).addTo(map).bindTooltip(z.titulo);

      var checkbox = document.querySelector('input[name="zona"][value="' + z.id + '"]');
      if (!checkbox) return;
      marker.on('click', function () {
        checkbox.checked = !checkbox.checked;
        marker.setStyle({ fillColor: checkbox.checked ? '#c0392b' : '#8f97a3' });
        if (checkbox.form) {
          if (checkbox.form.requestSubmit) checkbox.form.requestSubmit();
          else checkbox.form.submit();
        }
      });
      checkbox.addEventListener('change', function () {
        marker.setStyle({ fillColor: checkbox.checked ? '#c0392b' : '#8f97a3' });
      });
    });

    var bounds = capaAgebs.getBounds();
    var incluidosLayer = L.geoJSON({
      type: 'FeatureCollection',
      features: cfg.geojson.features.filter(function (f) { return f.properties.incluido; }),
    });
    var boundsZoom = incluidosLayer.getBounds();
    if (boundsZoom.isValid()) {
      map.fitBounds(boundsZoom, { padding: [60, 60] });
    } else if (bounds.isValid()) {
      map.fitBounds(bounds);
    }

    var wrap = div.closest('.mapa-details');
    if (wrap) {
      var btnZona = wrap.querySelector('.mapa-centrar');
      if (btnZona) btnZona.addEventListener('click', function () {
        if (boundsZoom.isValid()) map.fitBounds(boundsZoom, { padding: [60, 60] });
      });
      var btnFull = wrap.querySelector('.mapa-completa');
      if (btnFull) btnFull.addEventListener('click', function () {
        if (bounds.isValid()) map.fitBounds(bounds);
      });
    }

    div.addEventListener('wheel', function (ev) {
      if (ev.ctrlKey || ev.metaKey) { map.scrollWheelZoom.enable(); }
    });
  }

  function iniciar() {
    document.querySelectorAll('.mapa-leaflet:not([data-activado])').forEach(function (div) {
      div.setAttribute('data-activado', '1');
      iniciarMapa(div);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
  document.addEventListener('toggle', function (ev) {
    if (ev.target.matches('.mapa-details')) iniciar();
  }, true);
})();
</script>
"""
