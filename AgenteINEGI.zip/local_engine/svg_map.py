"""Mapa SVG interactivo 100% local (sin tiles de internet, sin librerías externas).

Dibuja todos los AGEBs de Tijuana (contexto de ciudad completa, tomados del Marco
Geoestadístico ya cargado en SQLite), resalta los AGEBs incluidos en la consulta actual,
marca el/los centro(s) de búsqueda y, si se usó un radio, dibuja un círculo sombreado con
el radio real en kilómetros — todo proyectado a una escala uniforme en km para que el
círculo sea geométricamente correcto. El zoom/paneo se hace con JS plano (viewBox de SVG),
sin ninguna librería de mapas ni conexión a internet.
"""
import html
import math
import uuid

KM_POR_GRADO_LAT = 110.574


def _km_por_grado_lon(lat_ref_deg: float) -> float:
    return 111.320 * math.cos(math.radians(lat_ref_deg))


def render_mapa(
    agebs_rings: dict[str, list],
    incluidos: set[str],
    zonas_todas: list[dict],
    zonas_activas_ids: set,
    radio_km: float | None = None,
    size: int = 640,
    color_incluido: str = "#3f6fb0",
    color_excluido: str = "#c9cdd4",
) -> str:
    """Devuelve un <svg> interactivo (zoom con Ctrl/Cmd + rueda del mouse, paneo arrastrando)
    con todos los AGEBs de Tijuana como fondo de contexto y los incluidos en la consulta
    resaltados. El zoom inicial ya viene acercado a la zona consultada (con margen para ver
    alrededor); se puede alejar (scroll out) para ver la ciudad completa, y "Ver Tijuana
    completa" / "Centrar en zona" saltan directo a cada extremo.

    Cada zona (colonia/CP) coincidente se marca con un punto ACCIONABLE: clicear un punto
    activa/desactiva su checkbox correspondiente en la lista de zonas de arriba (una segunda
    forma de incluir/excluir zonas, además de los checkboxes), sin necesidad de recargar la
    página — solo hace falta pulsar "Recalcular con selección" después, igual que con los
    checkboxes."""
    centros = [z for z in zonas_todas if z["id"] in zonas_activas_ids]
    puntos_lon_lat_ciudad = []
    for rings in agebs_rings.values():
        for ring in rings:
            puntos_lon_lat_ciudad.extend(ring)

    if not puntos_lon_lat_ciudad:
        return '<p class="mapa-vacio">No hay geometría disponible para dibujar el mapa.</p>'

    lons = [p[0] for p in puntos_lon_lat_ciudad]
    lats = [p[1] for p in puntos_lon_lat_ciudad]
    lat0 = (min(lats) + max(lats)) / 2
    km_lon = _km_por_grado_lon(lat0)

    def a_km(lon: float, lat: float) -> tuple[float, float]:
        return (lon * km_lon, lat * KM_POR_GRADO_LAT)

    # El lienzo (size x size) se dimensiona sobre TODA la ciudad, así el zoom-out siempre
    # puede llegar a mostrar Tijuana completa sin recalcular escalas.
    puntos_km_ciudad = [a_km(lo, la) for lo, la in puntos_lon_lat_ciudad]
    xs_c = [p[0] for p in puntos_km_ciudad]
    ys_c = [p[1] for p in puntos_km_ciudad]
    min_x, max_x = min(xs_c), max(xs_c)
    min_y, max_y = min(ys_c), max(ys_c)
    rango_ciudad = max(max_x - min_x, max_y - min_y, 0.05)
    margen_ciudad = rango_ciudad * 0.04
    escala = (size - 2 * (size * 0.02)) / (rango_ciudad + 2 * margen_ciudad)
    pad = size * 0.02

    def proyectar(lon: float, lat: float) -> tuple[float, float]:
        x_km, y_km = a_km(lon, lat)
        x = pad + (x_km - min_x + margen_ciudad) * escala
        y = size - (pad + (y_km - min_y + margen_ciudad) * escala)  # lat mayor = arriba
        return x, y

    # Bounding box de la ZONA consultada (incluidos + centros + círculo de radio), en px del
    # mismo lienzo — define el viewBox inicial "acercado", con margen generoso alrededor.
    puntos_zona_px = []
    for cve_geo in incluidos:
        for ring in agebs_rings.get(cve_geo, []):
            puntos_zona_px.extend(proyectar(lo, la) for lo, la in ring)
    for c in centros:
        puntos_zona_px.append(proyectar(c["lon"], c["lat"]))
        if radio_km:
            cx_km, cy_km = a_km(c["lon"], c["lat"])
            r_px = radio_km * escala
            cx_px, cy_px = proyectar(c["lon"], c["lat"])
            puntos_zona_px.append((cx_px - r_px, cy_px - r_px))
            puntos_zona_px.append((cx_px + r_px, cy_px + r_px))

    if puntos_zona_px:
        zxs = [p[0] for p in puntos_zona_px]
        zys = [p[1] for p in puntos_zona_px]
        z_min_x, z_max_x = min(zxs), max(zxs)
        z_min_y, z_max_y = min(zys), max(zys)
        z_w = max(z_max_x - z_min_x, 1.0)
        z_h = max(z_max_y - z_min_y, 1.0)
        z_lado = max(z_w, z_h) * 1.9  # margen ~45% alrededor de la zona por cada lado
        z_lado = max(z_lado, size * 0.06)  # no acercar demasiado si la zona es diminuta
        z_lado = min(z_lado, size)  # no exceder el lienzo completo
        zcx, zcy = (z_min_x + z_max_x) / 2, (z_min_y + z_max_y) / 2
        zoom_view = (zcx - z_lado / 2, zcy - z_lado / 2, z_lado, z_lado)
    else:
        zoom_view = (0, 0, size, size)

    map_id = f"mapa-{uuid.uuid4().hex[:8]}"
    zoom_view_str = " ".join(f"{v:.1f}" for v in zoom_view)
    full_view_str = f"0 0 {size} {size}"

    parts = [
        f'<svg id="{map_id}" class="mapa-svg" width="100%" height="{size}" viewBox="{zoom_view_str}" '
        f'data-zoom-viewbox="{zoom_view_str}" data-full-viewbox="{full_view_str}" '
        f'xmlns="http://www.w3.org/2000/svg" shape-rendering="geometricPrecision" '
        'role="img" aria-label="Mapa de Tijuana con la zona consultada resaltada">'
    ]
    parts.append(f'<rect x="0" y="0" width="{size}" height="{size}" fill="var(--mapa-bg, #eef0f3)"/>')

    # Fondo de contexto: todos los AGEBs de Tijuana no incluidos en la consulta.
    # vector-effect NO se hereda de <g> a los hijos en SVG, así que se pone en cada
    # <polygon> — si no, el trazo escala con el zoom y se ve cada vez más grueso al acercar.
    parts.append(f'<g fill="{color_excluido}" fill-opacity="0.45" stroke="var(--mapa-bg, #eef0f3)" '
                  'stroke-width="0.7" stroke-linejoin="round">')
    for cve_geo, rings in agebs_rings.items():
        if cve_geo in incluidos:
            continue
        for ring in rings:
            puntos_svg = " ".join(f"{x:.1f},{y:.1f}" for x, y in (proyectar(lo, la) for lo, la in ring))
            parts.append(f'<polygon points="{puntos_svg}" vector-effect="non-scaling-stroke"/>')
    parts.append("</g>")

    # Círculo de radio (encima del fondo, debajo de los AGEBs resaltados).
    if radio_km:
        for c in centros:
            cx, cy = proyectar(c["lon"], c["lat"])
            r_px = radio_km * escala
            parts.append(
                f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r_px:.1f}" '
                'fill="#3f6fb022" stroke="#3f6fb0" stroke-width="1.1" stroke-dasharray="4 3" '
                'vector-effect="non-scaling-stroke"/>'
            )

    # AGEBs incluidos en la consulta, resaltados encima de todo lo anterior. Doble trazo:
    # un halo blanco fino por fuera (separa la zona del fondo con nitidez) y el borde de
    # color por dentro — técnica común en mapas para que los límites se lean limpios.
    parts.append(f'<g fill="none" stroke="var(--surface, #fff)" stroke-width="2.6" stroke-linejoin="round">')
    for cve_geo in incluidos:
        rings = agebs_rings.get(cve_geo)
        if not rings:
            continue
        for ring in rings:
            puntos_svg = " ".join(f"{x:.1f},{y:.1f}" for x, y in (proyectar(lo, la) for lo, la in ring))
            parts.append(f'<polygon points="{puntos_svg}" vector-effect="non-scaling-stroke"/>')
    parts.append("</g>")
    parts.append(f'<g fill="{color_incluido}" fill-opacity="0.68" stroke="{color_incluido}" '
                  'stroke-width="1.1" stroke-linejoin="round">')
    for cve_geo in incluidos:
        rings = agebs_rings.get(cve_geo)
        if not rings:
            continue
        for ring in rings:
            puntos_svg = " ".join(f"{x:.1f},{y:.1f}" for x, y in (proyectar(lo, la) for lo, la in ring))
            parts.append(f'<polygon points="{puntos_svg}" vector-effect="non-scaling-stroke"/>')
    parts.append("</g>")

    # Marcador de cada zona coincidente (Colonia/CP), SIEMPRE visible y accionable: clic para
    # activar/desactivar, enlazado al checkbox de la lista de zonas vía data-zona-id.
    # El radio se fija en unidades del zoom inicial (para que no truene sin JS), pero el
    # script lo vuelve a calcular en cada cambio de vista para que el punto mida SIEMPRE lo
    # mismo en pantalla (px reales), sin importar cuánto se acerque o aleje el mapa — si no,
    # al hacer zoom los puntos crecen junto con todo lo demás y terminan enormes/encimados.
    r_centro = max(zoom_view[2] * 0.014, size * 0.002)
    for z in zonas_todas:
        activa = z["id"] in zonas_activas_ids
        cx, cy = proyectar(z["lon"], z["lat"])
        titulo = html.escape(f"CP {z['cp']} — {z['colonia']}")
        relleno = "#c0392b" if activa else "var(--mapa-bg, #eef0f3)"
        trazo = "#fff" if activa else "#c0392b"
        parts.append(
            f'<g class="mapa-marker" data-zona-id="{z["id"]}" data-activa="{"1" if activa else "0"}" '
            f'data-cx="{cx:.2f}" data-cy="{cy:.2f}" '
            f'tabindex="0" role="button" aria-label="{titulo}" style="cursor:pointer;">'
            f'<circle class="mapa-marker-halo" cx="{cx:.1f}" cy="{cy:.1f}" r="{r_centro * 2.4:.2f}" fill="transparent"/>'
            f'<circle class="mapa-marker-dot" cx="{cx:.1f}" cy="{cy:.1f}" r="{r_centro:.2f}" '
            f'fill="{relleno}" stroke="{trazo}" stroke-width="{max(r_centro * 0.32, 0.7):.2f}"/>'
            f"<title>{titulo}</title>"
            "</g>"
        )

    parts.append("</svg>")
    return "".join(parts)


MAPA_SCRIPT = """
<script>
(function () {
  function parseVB(str) { return str.split(' ').map(Number); }

  function activar(svg) {
    var zoomVb = parseVB(svg.getAttribute('data-zoom-viewbox'));
    var fullVb = parseVB(svg.getAttribute('data-full-viewbox'));
    var zoom = { x: zoomVb[0], y: zoomVb[1], w: zoomVb[2], h: zoomVb[3] };
    var full = { x: fullVb[0], y: fullVb[1], w: fullVb[2], h: fullVb[3] };
    var view = { x: zoom.x, y: zoom.y, w: zoom.w, h: zoom.h };
    var arrastrando = false, seMovio = false, ultimoX = 0, ultimoY = 0;

    // Los marcadores de zona deben medir SIEMPRE lo mismo en pantalla (px reales), sin
    // importar el zoom del mapa — si su radio quedara fijo en unidades del mapa, al acercar
    // se ven cada vez más grandes hasta encimarse. Se recalculan en cada cambio de vista.
    var DOT_PX = 6.5, DOT_STROKE_PX = 1.8, HALO_PX = 15;
    function reescalarMarcadores() {
      var rect = svg.getBoundingClientRect();
      if (!rect.width) return;
      var unidadesPorPx = view.w / rect.width;
      svg.querySelectorAll('.mapa-marker').forEach(function (marker) {
        var dot = marker.querySelector('.mapa-marker-dot');
        var halo = marker.querySelector('.mapa-marker-halo');
        dot.setAttribute('r', (DOT_PX * unidadesPorPx).toFixed(2));
        dot.setAttribute('stroke-width', (DOT_STROKE_PX * unidadesPorPx).toFixed(2));
        halo.setAttribute('r', (HALO_PX * unidadesPorPx).toFixed(2));
      });
    }

    function aplicar() {
      svg.setAttribute('viewBox', view.x + ' ' + view.y + ' ' + view.w + ' ' + view.h);
      reescalarMarcadores();
    }
    function irA(destino) {
      view = { x: destino.x, y: destino.y, w: destino.w, h: destino.h };
      aplicar();
    }
    reescalarMarcadores();

    // Zoom solo con Ctrl/Cmd + rueda, para no robarle el scroll normal de la página cuando
    // el cursor simplemente pasa sobre el mapa.
    svg.addEventListener('wheel', function (ev) {
      if (!ev.ctrlKey && !ev.metaKey) return; // deja pasar el scroll normal de la página
      ev.preventDefault();
      var rect = svg.getBoundingClientRect();
      var mx = view.x + ((ev.clientX - rect.left) / rect.width) * view.w;
      var my = view.y + ((ev.clientY - rect.top) / rect.height) * view.h;
      var factor = ev.deltaY > 0 ? 1.15 : 1 / 1.15;
      var nuevoW = Math.min(Math.max(view.w * factor, full.w * 0.03), full.w);
      var nuevoH = nuevoW * (view.h / view.w);
      view.x = mx - (mx - view.x) * (nuevoW / view.w);
      view.y = my - (my - view.y) * (nuevoH / view.h);
      view.w = nuevoW; view.h = nuevoH;
      aplicar();
    }, { passive: false });

    svg.addEventListener('mousedown', function (ev) {
      arrastrando = true; seMovio = false; ultimoX = ev.clientX; ultimoY = ev.clientY;
      svg.style.cursor = 'grabbing';
      ev.preventDefault();
    });
    window.addEventListener('mousemove', function (ev) {
      if (!arrastrando) return;
      var rect = svg.getBoundingClientRect();
      var dx = (ev.clientX - ultimoX) * (view.w / rect.width);
      var dy = (ev.clientY - ultimoY) * (view.h / rect.height);
      if (Math.abs(ev.clientX - ultimoX) > 2 || Math.abs(ev.clientY - ultimoY) > 2) seMovio = true;
      view.x -= dx; view.y -= dy;
      ultimoX = ev.clientX; ultimoY = ev.clientY;
      aplicar();
    });
    window.addEventListener('mouseup', function () { arrastrando = false; svg.style.cursor = 'grab'; });
    svg.style.cursor = 'grab';
    window.addEventListener('resize', reescalarMarcadores);

    var wrap = svg.closest('.mapa-details');
    if (wrap) {
      var btnZona = wrap.querySelector('.mapa-centrar');
      if (btnZona) btnZona.addEventListener('click', function () { irA(zoom); });
      var btnFull = wrap.querySelector('.mapa-completa');
      if (btnFull) btnFull.addEventListener('click', function () { irA(full); });
    }

    // Marcadores de zona accionables: clic para activar/desactivar, enlazados al checkbox
    // correspondiente en la lista de zonas de arriba (segunda forma de seleccionar/descartar).
    svg.querySelectorAll('.mapa-marker').forEach(function (marker) {
      var id = marker.getAttribute('data-zona-id');
      var checkbox = document.querySelector('input[name="zona"][value="' + id + '"]');
      if (!checkbox) return;
      var dot = marker.querySelector('.mapa-marker-dot');

      function actualizar(activa) {
        dot.setAttribute('fill', activa ? '#c0392b' : 'var(--mapa-bg, #eef0f3)');
        dot.setAttribute('stroke', activa ? '#fff' : '#c0392b');
        marker.setAttribute('data-activa', activa ? '1' : '0');
      }

      marker.addEventListener('mousedown', function (ev) { ev.stopPropagation(); });
      marker.addEventListener('click', function () {
        checkbox.checked = !checkbox.checked;
        actualizar(checkbox.checked);
        // Clic en el mapa = acción inmediata: recalcula al toque, sin botón aparte.
        if (checkbox.form) {
          if (checkbox.form.requestSubmit) checkbox.form.requestSubmit();
          else checkbox.form.submit();
        }
      });
      marker.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); marker.dispatchEvent(new Event('click')); }
      });
      checkbox.addEventListener('change', function () { actualizar(checkbox.checked); });
    });
  }

  function iniciar() {
    document.querySelectorAll('svg.mapa-svg:not([data-activado])').forEach(function (svg) {
      svg.setAttribute('data-activado', '1');
      activar(svg);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
  document.addEventListener('toggle', function (ev) {
    if (ev.target.matches('.mapa-details')) iniciar();
  }, true);
})();
</script>
"""


def leyenda_mapa(n_incluidos: int, n_excluidos: int, radio_km: float | None, color_incluido: str = "#3f6fb0") -> str:
    items = [
        f'<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:{color_incluido};"></span>'
        f"AGEB incluido ({n_incluidos})</span>",
    ]
    if n_excluidos:
        items.append(
            '<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:#c7cbd1;"></span>'
            f"Resto de Tijuana ({n_excluidos} AGEBs)</span>"
        )
    items.append(
        '<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:#c0392b;"></span>'
        "Centro de búsqueda</span>"
    )
    if radio_km:
        items.append(
            '<span class="mapa-leg-item"><span class="mapa-leg-dot" '
            'style="background:transparent;border:1.5px dashed #3f6fb0;"></span>'
            f"Radio de {html.escape(str(radio_km))} km</span>"
        )
    return "".join(items)
