"""Lector mínimo de shapefiles (.shp) en Python puro, sin librerías externas.

Implementa el subconjunto del formato ESRI Shapefile necesario para este proyecto:
shape type 5 (Polygon). Referencia del formato: ESRI Shapefile Technical Description.
"""
import struct
from pathlib import Path
from typing import NamedTuple


class ShapeRecord(NamedTuple):
    rings: list[list[tuple[float, float]]]  # cada ring es una lista de puntos (x, y)


SHAPE_TYPE_POLYGON = 5
SHAPE_TYPE_POLYGON_Z = 15
SHAPE_TYPE_POLYGON_M = 25


def read_shp(path: Path) -> list[ShapeRecord]:
    """Lee un archivo .shp y devuelve la lista de shapes (solo Polygon/PolygonZ/PolygonM)."""
    data = path.read_bytes()

    file_shape_type = struct.unpack_from("<i", data, 32)[0]
    if file_shape_type not in (SHAPE_TYPE_POLYGON, SHAPE_TYPE_POLYGON_Z, SHAPE_TYPE_POLYGON_M):
        raise ValueError(
            f"Tipo de shape no soportado: {file_shape_type}. Solo se soporta Polygon (5/15/25)."
        )

    records: list[ShapeRecord] = []
    offset = 100  # fin del header principal

    while offset < len(data):
        # Encabezado de registro: record_number (int32 BE), content_length (int32 BE, en words de 16 bits)
        record_number, content_length_words = struct.unpack_from(">ii", data, offset)
        offset += 8
        content_length_bytes = content_length_words * 2
        record_end = offset + content_length_bytes

        shape_type = struct.unpack_from("<i", data, offset)[0]

        if shape_type == 0:
            # Registro nulo
            records.append(ShapeRecord(rings=[]))
            offset = record_end
            continue

        # box: 4 doubles (xmin, ymin, xmax, ymax)
        cursor = offset + 4 + 32
        num_parts, num_points = struct.unpack_from("<ii", data, cursor)
        cursor += 8

        parts = list(struct.unpack_from(f"<{num_parts}i", data, cursor))
        cursor += 4 * num_parts

        points_flat = struct.unpack_from(f"<{num_points * 2}d", data, cursor)
        points = [
            (points_flat[i * 2], points_flat[i * 2 + 1]) for i in range(num_points)
        ]

        rings: list[list[tuple[float, float]]] = []
        for i, start in enumerate(parts):
            end = parts[i + 1] if i + 1 < len(parts) else num_points
            rings.append(points[start:end])

        records.append(ShapeRecord(rings=rings))
        offset = record_end

    return records
