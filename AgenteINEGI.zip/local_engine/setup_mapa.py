"""Descarga (UNA sola vez, con internet real) los assets para el mapa de calidad: la
librería Leaflet.js/CSS (vendorizada localmente, sin CDN) y los tiles raster que cubren
Tijuana en el rango de zoom que se pida.

Después de correr esto, `main_local.py serve` sirve el mapa 100% desde disco — sin ninguna
llamada de red saliente en tiempo de uso. Si nunca corres este script, el servidor sigue
funcionando igual: cae automáticamente al mapa SVG propio (sin calles/relieve reales).

Uso:
    python main_local.py setup-mapa
    python main_local.py setup-mapa --zoom-min 11 --zoom-max 14

Si el proveedor bloquea la descarga a la mitad (normal en servidores gratuitos ante volumen),
solo vuelve a correr el mismo comando más tarde: retoma exactamente donde se quedó, sin
volver a descargar lo que ya tienes en disco.

Aviso importante sobre el proveedor de tiles: tile.openstreetmap.org (el servidor "oficial"
de OSM) tiene una política de uso aceptable muy estricta
(https://operations.osmfoundation.org/policies/tiles/) que NO permite este tipo de descarga
masiva para caché local, y en la práctica bloquea la IP devolviendo una imagen de
"Access blocked" en vez del tile real (con código 200, no un error — por eso hay que validar
el contenido, no solo si la petición respondió). Por eso este script usa por defecto los
tiles de CARTO (basemaps.cartocdn.com, estilo "Positron"), un proveedor gratuito sin API key
pensado para este tipo de uso de bajo volumen; ver política en
https://github.com/CartoDB/basemap-styles#basemap-styles. Aun así:
  - Limita el rango de zoom (por defecto 11-14; cada nivel extra multiplica los tiles x4).
  - Descarga con una pausa entre tiles y solo lo que falte (reintentable).
  - Valida que cada respuesta sea realmente un PNG de tamaño razonable antes de guardarla —
    si un proveedor bloquea la descarga, se detecta y se reporta en vez de guardar la imagen
    de bloqueo como si fuera un tile bueno.
Si necesitas volumen mayor o cobertura de más municipios, considera generar tus propios tiles
offline (p. ej. con TileMill/QGIS + MBTiles) en vez de depender de un servidor público.
"""
import math
import time
import urllib.error
import urllib.request

from config import SQLITE_DB_PATH, STATIC_DIR, TILES_DIR, TILE_MAX_ZOOM_DESCARGADO
from local_engine.db_sqlite import get_connection
from local_engine.query_engine_local import CVE_MUN_TIJUANA
from logger_setup import get_logger

logger = get_logger("setup_mapa")

USER_AGENT = "AgenteINEGI-local-dev/1.0 (uso personal/offline, ver README)"
TILE_URL_TEMPLATE = "https://basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png"
# Un tile real (256x256 PNG) casi nunca pesa menos de esto; las páginas de "bloqueado" que
# devuelven algunos servidores (código 200, contenido HTML/imagen de aviso) son mucho más
# chicas. No es una prueba perfecta, pero atrapa el caso real que ya se vio en producción.
TILE_MIN_BYTES = 500

LEAFLET_VERSION = "1.9.4"
LEAFLET_ASSETS = {
    "leaflet.js": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/leaflet.js",
    "leaflet.css": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/leaflet.css",
    "marker-icon.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-icon.png",
    "marker-icon-2x.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-icon-2x.png",
    "marker-shadow.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-shadow.png",
}


def _descargar(url: str, destino) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as resp:
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(resp.read())


class TileBloqueadoError(Exception):
    """El servidor respondió 200 pero el contenido no es un tile PNG real — típicamente una
    página/imagen de aviso porque el proveedor bloqueó la descarga por volumen. No basta con
    revisar si la petición HTTP "tuvo éxito": hay que mirar el contenido."""


def _descargar_tile(url: str, destino) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as resp:
        contenido = resp.read()
    if len(contenido) < TILE_MIN_BYTES or not contenido.startswith(b"\x89PNG\r\n\x1a\n"):
        raise TileBloqueadoError(
            f"Respuesta de {len(contenido)} bytes no parece un tile PNG válido "
            "(posible bloqueo del proveedor por volumen de descarga)."
        )
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_bytes(contenido)


def descargar_leaflet() -> None:
    logger.info("Descargando Leaflet.js/CSS (una vez, se guarda en %s)...", STATIC_DIR)
    for nombre, url in LEAFLET_ASSETS.items():
        destino = STATIC_DIR / nombre
        if destino.exists():
            continue
        try:
            _descargar(url, destino)
            logger.info("  %s OK", nombre)
        except (urllib.error.URLError, TimeoutError) as exc:
            logger.error("  %s FALLÓ (%s) — revisa tu conexión a internet y reintenta.", nombre, exc)
            raise
    logger.info("Leaflet listo en %s.", STATIC_DIR)


def _bbox_tijuana() -> tuple[float, float, float, float]:
    """(lon_min, lat_min, lon_max, lat_max) sobre todos los AGEBs de Tijuana ya cargados."""
    import json

    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT rings_json FROM inegi_geometrias WHERE cve_mun = ? AND rings_json IS NOT NULL;",
            (CVE_MUN_TIJUANA,),
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        raise RuntimeError(
            "No hay geometrías de Tijuana cargadas todavía — corre 'python main_local.py "
            "run-etl' antes de 'setup-mapa'."
        )

    lons, lats = [], []
    for row in rows:
        for ring in json.loads(row["rings_json"]):
            for lon, lat in ring:
                lons.append(lon)
                lats.append(lat)
    return min(lons), min(lats), max(lons), max(lats)


def _tile_xy(lon: float, lat: float, zoom: int) -> tuple[int, int]:
    """Convierte lon/lat a coordenadas de tile (esquema slippy-map estándar de OSM)."""
    lat_rad = math.radians(lat)
    n = 2**zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.log(math.tan(lat_rad) + 1 / math.cos(lat_rad)) / math.pi) / 2.0 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def descargar_tiles(zoom_min: int = 11, zoom_max: int = TILE_MAX_ZOOM_DESCARGADO, pausa_seg: float = 0.6) -> None:
    if zoom_max - zoom_min > 6:
        raise ValueError(
            "Rango de zoom demasiado amplio (más de 6 niveles) — reduce zoom_max o sube "
            "zoom_min para no descargar un volumen excesivo de tiles de un servidor público."
        )

    lon_min, lat_min, lon_max, lat_max = _bbox_tijuana()
    # Margen del 8% alrededor del bounding box real, para no dejar la ciudad pegada al borde
    # del mapa cuando el usuario haga zoom-out.
    margen_lon = (lon_max - lon_min) * 0.08
    margen_lat = (lat_max - lat_min) * 0.08
    lon_min, lon_max = lon_min - margen_lon, lon_max + margen_lon
    lat_min, lat_max = lat_min - margen_lat, lat_max + margen_lat

    total_a_descargar = 0
    planeados = []
    for zoom in range(zoom_min, zoom_max + 1):
        x_min, y_max = _tile_xy(lon_min, lat_min, zoom)
        x_max, y_min = _tile_xy(lon_max, lat_max, zoom)
        for x in range(x_min, x_max + 1):
            for y in range(y_min, y_max + 1):
                destino = TILES_DIR / str(zoom) / str(x) / f"{y}.png"
                planeados.append((zoom, x, y, destino))
    faltantes = [p for p in planeados if not p[3].exists()]
    total_a_descargar = len(faltantes)

    logger.info(
        "Tiles: %d ya en disco, %d por descargar (zoom %d-%d, bbox Tijuana con margen).",
        len(planeados) - total_a_descargar, total_a_descargar, zoom_min, zoom_max,
    )
    if not faltantes:
        logger.info("Nada por descargar — los tiles ya están completos en %s.", TILES_DIR)
        return

    ok, fallidos, bloqueos_seguidos = 0, 0, 0
    for i, (zoom, x, y, destino) in enumerate(faltantes, start=1):
        url = TILE_URL_TEMPLATE.format(z=zoom, x=x, y=y)
        try:
            _descargar_tile(url, destino)
            ok += 1
            bloqueos_seguidos = 0
        except TileBloqueadoError as exc:
            fallidos += 1
            bloqueos_seguidos += 1
            logger.warning("Tile z=%d x=%d y=%d: %s", zoom, x, y, exc)
            if bloqueos_seguidos >= 10:
                logger.error(
                    "El proveedor de tiles bloqueó %d descargas seguidas — probablemente "
                    "activó un límite por volumen/frecuencia. Deteniendo aquí en vez de "
                    "seguir insistiendo contra el bloqueo. Espera unos minutos u horas y "
                    "vuelve a correr 'python main_local.py setup-mapa' (retoma donde quedó, "
                    "no descarga de nuevo lo que ya tienes). Descargados hasta ahora: %d/%d.",
                    bloqueos_seguidos, ok, total_a_descargar,
                )
                return
        except (urllib.error.URLError, TimeoutError) as exc:
            fallidos += 1
            logger.warning("Tile z=%d x=%d y=%d falló (%s) — se reintentará si vuelves a correr setup-mapa.", zoom, x, y, exc)
        if i % 50 == 0 or i == total_a_descargar:
            logger.info("  %d/%d tiles procesados (%d OK, %d fallidos)...", i, total_a_descargar, ok, fallidos)
        time.sleep(pausa_seg)

    logger.info("Descarga de tiles completa: %d OK, %d fallidos de %d.", ok, fallidos, total_a_descargar)
    if fallidos:
        logger.warning("Vuelve a correr 'python main_local.py setup-mapa' para reintentar solo los tiles faltantes.")


def setup_mapa(zoom_min: int = 11, zoom_max: int = 15) -> None:
    descargar_leaflet()
    descargar_tiles(zoom_min=zoom_min, zoom_max=zoom_max)
