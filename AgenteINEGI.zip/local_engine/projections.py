"""Conversión de proyecciones a lon/lat (WGS84) en Python puro, sin pyproj/GDAL.

Implementa las dos proyecciones necesarias para este proyecto:
- Lambert Cónica Conforme 2SP (la que usa INEGI en su cartografía, ej. ageb_urb.prj).
- Web Mercator esférica (la que usan los mapas web tipo ArcGIS Online/Esri, EPSG:3857).

Fórmulas estándar de EPSG Guidance Note 7-2 (LCC 2SP) y de la especificación de Web
Mercator (siempre esférica, radio 6378137 m, sin importar el elipsoide de origen).
"""
import math
import re

GRS80_A = 6378137.0
GRS80_F = 1 / 298.257222101
WEB_MERCATOR_R = 6378137.0


def web_mercator_to_lonlat(x: float, y: float) -> tuple[float, float]:
    lon = math.degrees(x / WEB_MERCATOR_R)
    lat = math.degrees(2 * math.atan(math.exp(y / WEB_MERCATOR_R)) - math.pi / 2)
    return lon, lat


class LambertConformalConic2SP:
    """LCC 2SP inversa (E, N en metros -> lon/lat en grados)."""

    def __init__(
        self,
        central_meridian_deg: float,
        latitude_of_origin_deg: float,
        std_parallel_1_deg: float,
        std_parallel_2_deg: float,
        false_easting: float,
        false_northing: float,
        a: float = GRS80_A,
        f: float = GRS80_F,
    ):
        self.lambda0 = math.radians(central_meridian_deg)
        self.phi0 = math.radians(latitude_of_origin_deg)
        self.phi1 = math.radians(std_parallel_1_deg)
        self.phi2 = math.radians(std_parallel_2_deg)
        self.fe = false_easting
        self.fn = false_northing
        self.a = a
        self.e2 = 2 * f - f * f
        self.e = math.sqrt(self.e2)

        m1 = self._m(self.phi1)
        m2 = self._m(self.phi2)
        t0 = self._t(self.phi0)
        t1 = self._t(self.phi1)
        t2 = self._t(self.phi2)

        self.n = (math.log(m1) - math.log(m2)) / (math.log(t1) - math.log(t2))
        self.F = m1 / (self.n * t1 ** self.n)
        self.rho0 = self.a * self.F * t0 ** self.n

    def _m(self, phi: float) -> float:
        e = self.e
        return math.cos(phi) / math.sqrt(1 - self.e2 * math.sin(phi) ** 2)

    def _t(self, phi: float) -> float:
        e = self.e
        return math.tan(math.pi / 4 - phi / 2) / (
            (1 - e * math.sin(phi)) / (1 + e * math.sin(phi))
        ) ** (e / 2)

    def inverse(self, easting: float, northing: float) -> tuple[float, float]:
        dx = easting - self.fe
        dy = self.rho0 - (northing - self.fn)
        rho = math.copysign(math.sqrt(dx * dx + dy * dy), self.n)
        theta = math.atan2(dx, dy)

        t = (rho / (self.a * self.F)) ** (1 / self.n)
        lam = theta / self.n + self.lambda0

        phi = math.pi / 2 - 2 * math.atan(t)
        for _ in range(10):
            e = self.e
            phi_new = math.pi / 2 - 2 * math.atan(
                t * ((1 - e * math.sin(phi)) / (1 + e * math.sin(phi))) ** (e / 2)
            )
            if abs(phi_new - phi) < 1e-12:
                phi = phi_new
                break
            phi = phi_new

        return math.degrees(lam), math.degrees(phi)


_PRJ_PARAM_RE = re.compile(r'PARAMETER\["([^"]+)",\s*(-?[\d.]+)\]')


def lcc_from_prj_wkt(prj_text: str) -> LambertConformalConic2SP:
    """Construye la proyección LCC 2SP a partir del contenido de un archivo .prj de ESRI."""
    params = {name: float(value) for name, value in _PRJ_PARAM_RE.findall(prj_text)}
    required = {
        "Central_Meridian",
        "Latitude_Of_Origin",
        "Standard_Parallel_1",
        "Standard_Parallel_2",
        "False_Easting",
        "False_Northing",
    }
    missing = required - params.keys()
    if missing:
        raise ValueError(f".prj no es una LCC 2SP reconocible; faltan parámetros: {missing}")

    return LambertConformalConic2SP(
        central_meridian_deg=params["Central_Meridian"],
        latitude_of_origin_deg=params["Latitude_Of_Origin"],
        std_parallel_1_deg=params["Standard_Parallel_1"],
        std_parallel_2_deg=params["Standard_Parallel_2"],
        false_easting=params["False_Easting"],
        false_northing=params["False_Northing"],
    )
