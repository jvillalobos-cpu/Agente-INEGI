"""Modelado e inicialización de la base de datos local (SQLite, incluido en Python).

Sin PostgreSQL/PostGIS. Idempotente: usa CREATE TABLE IF NOT EXISTS y UPSERT nativo de SQLite.
"""
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS inegi_geometrias (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    nivel TEXT NOT NULL,
    centroid_x REAL NOT NULL,
    centroid_y REAL NOT NULL,
    rings_json TEXT
);

CREATE TABLE IF NOT EXISTS inegi_censo (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    vivtot REAL, tvivparhab REAL, vivpar_des REAL, vph_pisoti REAL,
    vph_c_elec REAL, vph_excsa REAL, vph_drenaj REAL,
    pobtot REAL, pobfem REAL, pobmas REAL, p_0a14 REAL, p_15a29 REAL,
    p_30a59 REAL, p_60ymas REAL, pcon_disc REAL,
    p15ym_se REAL, vph_inter REAL, vph_autom REAL,
    pder_ss REAL, pder_imss REAL, pder_iste REAL, pder_segpub REAL, psinder REAL
);

CREATE TABLE IF NOT EXISTS colonias_cp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    colonia TEXT,
    cp TEXT,
    municipio TEXT,
    rings_json TEXT NOT NULL,
    UNIQUE (colonia, cp, municipio)
);

CREATE TABLE IF NOT EXISTS colonia_ageb_asignacion (
    colonia_cp_id INTEGER NOT NULL REFERENCES colonias_cp(id),
    cve_geo TEXT NOT NULL REFERENCES inegi_geometrias(cve_geo),
    PRIMARY KEY (colonia_cp_id, cve_geo)
);

CREATE INDEX IF NOT EXISTS idx_colonias_cp_colonia ON colonias_cp (colonia);
CREATE INDEX IF NOT EXISTS idx_colonias_cp_cp ON colonias_cp (cp);

CREATE TABLE IF NOT EXISTS denue_salud (
    id TEXT PRIMARY KEY,
    cve_geo TEXT NOT NULL,
    codigo_act TEXT NOT NULL,
    nombre_act TEXT,
    categoria TEXT NOT NULL DEFAULT 'Otros servicios de salud',
    es_laboratorio INTEGER NOT NULL DEFAULT 0,
    lat REAL,
    lon REAL
);

CREATE INDEX IF NOT EXISTS idx_denue_salud_cve_geo ON denue_salud (cve_geo);

CREATE TABLE IF NOT EXISTS marginacion_ageb (
    cve_geo TEXT PRIMARY KEY,
    poblacion REAL,
    indice_marginacion REAL,
    grado_marginacion TEXT,
    indice_normalizado REAL
);

CREATE TABLE IF NOT EXISTS esep_recursos_salud (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cve_geo TEXT NOT NULL,
    tipo_establecimiento TEXT,
    personal_medico INTEGER, personal_no_medico INTEGER,
    consultorios INTEGER, camas_censables INTEGER, quirofanos INTEGER, unidades_dentales INTEGER,
    lab_analisis_clinicos INTEGER, lab_anatomia_patologica INTEGER, salas_radiologia INTEGER,
    equipos_rayos_x INTEGER, equipos_resonancia_magnetica INTEGER, equipos_tomografia INTEGER,
    equipos_mamografia INTEGER, equipos_ultrasonido INTEGER
);

CREATE INDEX IF NOT EXISTS idx_esep_recursos_cve_geo ON esep_recursos_salud (cve_geo);
"""


def get_connection(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn


def setup_database(db_path: Path) -> None:
    conn = get_connection(db_path)
    try:
        conn.executescript(SCHEMA)
        _migrar_columnas_faltantes(conn)
        conn.commit()
    finally:
        conn.close()


def _migrar_columnas_faltantes(conn: sqlite3.Connection) -> None:
    """Agrega columnas nuevas a bases de datos creadas con un esquema anterior
    (sqlite no soporta 'ADD COLUMN IF NOT EXISTS', así que se verifica a mano)."""
    columnas = {row["name"] for row in conn.execute("PRAGMA table_info(inegi_geometrias);")}
    if "rings_json" not in columnas:
        conn.execute("ALTER TABLE inegi_geometrias ADD COLUMN rings_json TEXT;")

    columnas_denue = {row["name"] for row in conn.execute("PRAGMA table_info(denue_salud);")}
    if columnas_denue and "categoria" not in columnas_denue:
        conn.execute("ALTER TABLE denue_salud ADD COLUMN categoria TEXT NOT NULL DEFAULT 'Otros servicios de salud';")
