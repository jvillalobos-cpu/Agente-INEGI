"""Lector de GeoJSON en Python puro (módulo json de la librería estándar).

Útil para el catálogo de colonias/CP cuando se obtiene de OpenStreetMap (ej. exportado
desde Overpass Turbo en el navegador, sin necesidad de instalar ninguna librería SIG).
"""
import json
from pathlib import Path
from typing import NamedTuple


class GeoJsonFeature(NamedTuple):
    properties: dict
    rings: list[list[tuple[float, float]]]  # cada ring es una lista de puntos (x, y)


def _rings_from_polygon_coords(coords) -> list[list[tuple[float, float]]]:
    # coords: lista de rings, cada ring es una lista de [x, y] (o [x, y, z])
    return [[(pt[0], pt[1]) for pt in ring] for ring in coords]


def read_geojson(path: Path) -> list[GeoJsonFeature]:
    with path.open(encoding="utf-8-sig") as f:
        data = json.load(f)

    features_raw = data.get("features", []) if data.get("type") == "FeatureCollection" else [data]

    features = []
    for feat in features_raw:
        geom = feat.get("geometry") or {}
        gtype = geom.get("type")
        coords = geom.get("coordinates")
        if not gtype or coords is None:
            continue

        if gtype == "Polygon":
            rings = _rings_from_polygon_coords(coords)
        elif gtype == "MultiPolygon":
            rings = []
            for polygon_coords in coords:
                rings.extend(_rings_from_polygon_coords(polygon_coords))
        else:
            continue  # Point/LineString no aplican para polígonos de colonias

        features.append(GeoJsonFeature(properties=feat.get("properties") or {}, rings=rings))

    return features
