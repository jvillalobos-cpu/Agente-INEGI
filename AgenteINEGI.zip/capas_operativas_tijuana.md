# Capas operativas del webmap IMPLAN Tijuana ("Carta Urbana")

Fuente: `data/cp_colonias/implan_webmap.json`, JSON de webmap de ArcGIS Online
(`item.data`) descargado del mapa interactivo "Carta Urbana" de IMPLAN Tijuana
(`implan.tijuana.gob.mx`), siguiendo el procedimiento descrito en el `README.md`
del proyecto (fetch vía DevTools). El archivo completo pesa ~4.8 MB y contiene
**7 capas operativas** (`operationalLayers`), cada una con su geometría embebida
en `featureCollection.layers[0].featureSet` (formato Esri JSON, coordenadas en
Web Mercator / EPSG:3857).

Listado obtenido con `local_engine.esri_webmap_reader.list_layers()`:

| # | Título | Tipo de geometría | # Features |
|---|---|---|---|
| 0 | `LIMITE_MUNICIPAL_DE_TIJUANA` | Polilínea (`esriGeometryPolyline`) | 1 |
| 1 | `USOS PROPUESTOS SIN DELEGACION` | Polígono (`esriGeometryPolygon`) | 191 |
| 2 | `USOS PROPUESTOS ZONA ESTE` | Polígono (`esriGeometryPolygon`) | 380 |
| 3 | `USOS PROPUESTOS ZONA OESTE` | Polígono (`esriGeometryPolygon`) | 271 |
| 4 | `SUBSECTORES INTEGRADOS` | Polígono (`esriGeometryPolygon`) | 166 |
| 5 | `DELEGACIONES` | Polígono (`esriGeometryPolygon`) | 14 |
| 6 | `ESQUEMA VIAL ACTUAL Y PROPUESTO` | Polilínea (`esriGeometryPolyline`) | 597 |

Nota: `local_engine.esri_webmap_reader.read_layer()` solo acepta capas de tipo
`esriGeometryPolygon` (levanta `ValueError` para polilíneas), por lo que las
capas 0 y 6 no son utilizables directamente por el ETL local; sirven solo como
referencia/contexto.

---

## Capa 0 — `LIMITE_MUNICIPAL_DE_TIJUANA`

- **Geometría:** polilínea, 1 sola feature (el perímetro municipal completo).
- **Uso:** referencia visual del límite del municipio; no aporta atributos de
  zonificación y no es consumible por `read_layer()` (no es polígono).

## Capas 1–3 — `USOS PROPUESTOS *` (uso de suelo propuesto)

Tres capas de polígonos que en conjunto cubren el municipio (sin delegación,
zona este, zona oeste) con el uso de suelo propuesto por el Plan de Desarrollo
Urbano. Comparten el mismo esquema de atributos, ejemplo (capa 1, feature 0):

```json
{
  "FID": 0,
  "USOS_FINAL": "ACTIVIDADES PRIMARIAS",
  "DELEGACION": "LA PRESA RURAL",
  "UTP": "GANDUL",
  "SUBSECTOR": "27.4",
  "SECTOR": "27",
  "DENSIDADHA": "HUM",
  "POLITICAS_": "CRECIMIENTO",
  "COMPATIBIL": "http://es.scribd.com/doc/94563391/MATRIZ-DE-COMPATIBILIDAD-DE-ACTIVIDADES-PRIMARIAS"
}
```

Campos:

| Campo | Descripción |
|---|---|
| `USOS_FINAL` | Uso de suelo propuesto (ej. "ACTIVIDADES PRIMARIAS") |
| `DELEGACION` | Delegación municipal a la que pertenece el polígono |
| `UTP` | Unidad Territorial de Planeación (proxy de "colonia") |
| `SUBSECTOR` / `SECTOR` | Clave de subsector/sector de planeación urbana |
| `DENSIDADHA` | Densidad habitacional/uso (clave corta, ej. "HUM") |
| `POLITICAS_` | Política de desarrollo urbano aplicable (ej. "CRECIMIENTO") |
| `COMPATIBIL` | Liga a la matriz de compatibilidad de usos de suelo (Scribd) |

## Capa 4 — `SUBSECTORES INTEGRADOS`

Capa de 166 polígonos, la configurada por defecto en `config.py`
(`CP_COLONIAS_WEBMAP_LAYER_INDEX`) como sustituto de un catálogo de colonias,
vía el campo `UTP`. Incluye series históricas y proyectadas de población por
subsector (2000–2030), ejemplo (feature 0):

```json
{
  "FID": 0,
  "OBJECTID": 1,
  "DELEGACION": "VALLE DE LAS PALMAS",
  "UTP": "SANTA ANITA",
  "SUBSECTOR": "29.2",
  "SECTOR": "29",
  "SUP__MODIF": 54037397.96,
  "HAS__MODIC": 5403.74,
  "OBSERVACIO": "",
  "DENSIDADHA": "",
  "DENSIDADPR": "HC",
  "POLITICAS_": "CONSERVACION",
  "POLIT_DESA": "CONSERVACION",
  "POL_CONURB": "NO",
  "POB2000": 54,
  "POB2005": 196,
  "POB2008": 425,
  "POB2010": 514,
  "POB2015": 828,
  "POB2020": 1333,
  "POB2025": 3317,
  "POB2030": 5343,
  "DENSIDAD_P": 0.08,
  "Shape_Leng": 39601.8995753,
  "Shape_Area": 54037397.8993
}
```

Campos relevantes:

| Campo | Descripción |
|---|---|
| `UTP` | Nombre de la Unidad Territorial de Planeación (equivalente a "colonia") |
| `DELEGACION` | Delegación municipal |
| `SECTOR` / `SUBSECTOR` | Claves de sector/subsector de planeación |
| `SUP__MODIF` / `HAS__MODIC` | Superficie del subsector en m² / hectáreas |
| `DENSIDADPR` | Densidad de población propuesta (clave corta) |
| `POLITICAS_` / `POLIT_DESA` | Política de desarrollo urbano |
| `POL_CONURB` | Indicador de política de conurbación (SI/NO) |
| `POB2000`…`POB2030` | Población histórica/proyectada por quinquenio |
| `DENSIDAD_P` | Densidad de población (hab/m²) |
| `Shape_Leng` / `Shape_Area` | Perímetro y área calculados por ArcGIS |

Nota: esta capa **no incluye código postal** (según lo documentado en el
`README.md`) — solo `UTP` (nombre de zona) y `DELEGACION`.

## Capa 5 — `DELEGACIONES`

Capa de 14 polígonos, uno por delegación municipal. Ejemplo (feature 0):

```json
{
  "FID": 0,
  "ENTITY": "Polyline",
  "DELEGACION": "LA MESA",
  "SUP_EN_M2": 30536797.75,
  "HECTAREAS": 3053.68,
  "PORCENTAJE": 0.025,
  "SUP_MUNICI": 1237849254.045,
  "SUP_CALCUL": 30536798.273,
  "SUP_CAL_HA": 3053.68,
  "DIFERENCIA": -0.523,
  "OBSERV": "La Division de Poligonales se deriva directamente del archivo 'Limites_Municipales_Completo_Sept_08.shp'",
  "FECHAC": 1223596800000,
  "EDITOR": "SIMIG-IMPLAN",
  "SUP_APROBA": 3050.711,
  "DIF_LEG_VS": -2.969,
  "FECHA_ANAL": 1319500800000,
  "SUP_MUN_HA": 123784.925405
}
```

Campos relevantes:

| Campo | Descripción |
|---|---|
| `DELEGACION` | Nombre de la delegación |
| `SUP_EN_M2` / `HECTAREAS` | Superficie de la delegación |
| `PORCENTAJE` | Proporción respecto a la superficie municipal total |
| `SUP_MUNICI` | Superficie total del municipio (m²), constante en todas las filas |
| `EDITOR` | Área responsable de la edición cartográfica (SIMIG-IMPLAN) |
| `FECHAC` / `FECHA_ANAL` | Fechas de creación/análisis (epoch ms) |

## Capa 6 — `ESQUEMA VIAL ACTUAL Y PROPUESTO`

- **Geometría:** polilínea, 597 features (red vial actual y propuesta).
- **Uso:** referencia de vialidades; no consumible por `read_layer()` al no ser
  polígono, y fuera del alcance del traductor Colonia/UTP → AGEB.

---

## Aplicabilidad en el ETL local

Para el flujo de "Alternativa: capa UTP" descrito en el `README.md`, la capa
relevante es la **4 (`SUBSECTORES INTEGRADOS`)**, ya configurada por defecto en
`CP_COLONIAS_WEBMAP_LAYER_INDEX`. Las capas 1–3 (`USOS PROPUESTOS *`) podrían
usarse como fuente alternativa de zonificación por `UTP`/`DELEGACION`, pero al
estar divididas en tres capas geográficas (sin delegación / zona este / zona
oeste) requerirían combinarse antes de usarse como catálogo único. Las capas 0,
5 y 6 no participan del traductor Colonia/UTP → AGEB (límite municipal,
delegaciones sin unidad "colonia", y red vial, respectivamente).
