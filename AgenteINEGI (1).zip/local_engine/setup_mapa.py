"""Descarga (UNA sola vez, con internet real) los assets para el mapa de calidad: la
librería Leaflet.js/CSS (vendorizada localmente, sin CDN) y los tiles raster que cubren
los 7 municipios de Baja California en el rango de zoom que se pida.

Después de correr esto, `main_local.py serve` sirve el mapa 100% desde disco — sin ninguna
llamada de red saliente en tiempo de uso. Si nunca corres este script, el servidor sigue
funcionando igual: cae automáticamente al mapa SVG propio (sin calles/relieve reales).

Uso:
    python main_local.py setup-mapa
    python main_local.py setup-mapa --zoom-min 11 --zoom-max 12

Si el proveedor bloquea la descarga a la mitad (normal en servidores gratuitos ante volumen),
solo vuelve a correr el mismo comando más tarde: retoma exactamente donde se quedó, sin
volver a descargar lo que ya tienes en disco.

Aviso importante sobre el proveedor de tiles — historial de proveedores gratuitos que
dejaron de servir para este uso externo de bajo volumen, cada uno reemplazado por el
siguiente cuando falló:
  1. tile.openstreetmap.org (el servidor "oficial" de OSM): política de uso aceptable muy
     estricta (https://operations.osmfoundation.org/policies/tiles/) que NO permite este tipo
     de descarga masiva para caché local — bloquea la IP devolviendo una imagen de
     "Access blocked" en vez del tile real (con código 200, no un error).
  2. basemaps.cartocdn.com (CARTO, estilo "Positron"): empezó a exigir API key incluso para
     uso gratuito de bajo volumen — el tile ya no se bloquea, sigue respondiendo 200 con un
     PNG válido, solo que con un sello "API KEY REQUIRED" quemado encima (por eso la
     validación de "¿es un PNG real?" no lo detecta: técnicamente lo es).
  3. maps.wikimedia.org: responde 403 explícito ("Map tiles are restricted to Wikimedia and
     affiliated sites only") — a diferencia de CARTO, sí es un error HTTP claro, así que al
     menos se detecta y reporta en vez de guardarse como tile bueno.
  4. tile.openstreetmap.fr (OpenStreetMap France, estilo "osmfr"): en teoría acepta uso
     externo de bajo volumen, pero se quedó cargando indefinidamente (timeout) para el
     usuario — típico de un firewall corporativo bloqueando el dominio en silencio (sin
     devolver ni error ni bloqueo explícito, solo tirando el paquete).
Por eso ahora se usan los tiles de Esri/ArcGIS Online (server.arcgisonline.com,
"World_Street_Map") — un dominio de un proveedor comercial grande, con más probabilidad de
ya estar permitido en firewalls corporativos (mucho software de mapas empresarial lo usa).
Nota de formato: a diferencia de los proveedores anteriores (esquema XYZ, {z}/{x}/{y}), el
API REST de ArcGIS usa el orden {z}/{y}/{x} — ver el .format() más abajo. Si este proveedor
también deja de funcionar en el futuro (son servicios gratuitos/de bajo costo y las
políticas cambian), el síntoma es el mismo: revisa el mensaje de error o la marca de agua en
el tile descargado, y cambia TILE_URL_TEMPLATE más abajo por otro proveedor. Aun así:
  - Limita el rango de zoom (por defecto 11-12; cada nivel extra multiplica los tiles x4).
  - Descarga con una pausa entre tiles y solo lo que falte (reintentable).
  - Valida que cada respuesta sea realmente un PNG de tamaño razonable antes de guardarla —
    si un proveedor bloquea la descarga, se detecta y se reporta en vez de guardar la imagen
    de bloqueo como si fuera un tile bueno.
Si necesitas volumen mayor o cobertura de más municipios, considera generar tus propios tiles
offline (p. ej. con TileMill/QGIS + MBTiles) en vez de depender de un servidor público.
"""
import math
import time
import urllib.error
import urllib.request

from config import SQLITE_DB_PATH, STATIC_DIR, TILES_DIR, TILE_MAX_ZOOM_DESCARGADO
from local_engine.db_sqlite import get_connection
from local_engine.query_engine_local import CVE_ENT_BC
from logger_setup import get_logger

logger = get_logger("setup_mapa")

USER_AGENT = "AgenteINEGI-local-dev/1.0 (uso personal/offline, ver README)"
TILE_URL_TEMPLATE = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}"
# OJO: un tile de mar/desierto vacío (muy común con el mapa cubriendo las 6 ciudades de BC,
# separadas por mucho territorio sin nada) es casi un solo color y el PNG lo comprime a menos
# de 150 bytes — un mínimo de tamaño alto (los 500 bytes que tenía antes) los marca como
# "bloqueados" por error, cuando en realidad son tiles legítimos. La única prueba confiable
# es el magic byte de PNG (los avisos de bloqueo de algunos proveedores vienen como HTML/otra
# imagen, nunca como PNG real); el tamaño mínimo solo descarta una respuesta vacía o cortada.
TILE_MIN_BYTES = 30

LEAFLET_VERSION = "1.9.4"
LEAFLET_ASSETS = {
    "leaflet.js": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/leaflet.js",
    "leaflet.css": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/leaflet.css",
    "marker-icon.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-icon.png",
    "marker-icon-2x.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-icon-2x.png",
    "marker-shadow.png": f"https://unpkg.com/leaflet@{LEAFLET_VERSION}/dist/images/marker-shadow.png",
}


def _descargar(url: str, destino) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as resp:
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(resp.read())


class TileBloqueadoError(Exception):
    """El servidor respondió 200 pero el contenido no es un tile de imagen real — típicamente
    una página/imagen de aviso porque el proveedor bloqueó la descarga por volumen. No basta
    con revisar si la petición HTTP "tuvo éxito": hay que mirar el contenido."""


# Firma de archivo (magic bytes) de los dos formatos que puede devolver un servicio de tiles
# raster — PNG (la mayoría de proveedores OSM) o JPEG (algunos servicios ArcGIS, ej.
# World_Street_Map) — se guarda igual como .png en disco/Leaflet no le importa el formato real
# dentro del archivo, solo la extensión de la URL que pide.
_FIRMAS_IMAGEN_VALIDAS = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff")


def _descargar_tile(url: str, destino) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as resp:
        contenido = resp.read()
    if not contenido.startswith(_FIRMAS_IMAGEN_VALIDAS):
        raise TileBloqueadoError(
            f"Respuesta de {len(contenido)} bytes NO es un PNG/JPEG real (probable página/imagen "
            "de aviso de bloqueo del proveedor por volumen de descarga)."
        )
    if len(contenido) < TILE_MIN_BYTES:
        raise TileBloqueadoError(
            f"PNG de solo {len(contenido)} bytes, sospechosamente pequeño incluso para un "
            "tile vacío — se descarta por seguridad."
        )
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_bytes(contenido)


def descargar_leaflet() -> None:
    logger.info("Descargando Leaflet.js/CSS (una vez, se guarda en %s)...", STATIC_DIR)
    for nombre, url in LEAFLET_ASSETS.items():
        destino = STATIC_DIR / nombre
        if destino.exists():
            continue
        try:
            _descargar(url, destino)
            logger.info("  %s OK", nombre)
        except (urllib.error.URLError, TimeoutError) as exc:
            logger.error("  %s FALLÓ (%s) — revisa tu conexión a internet y reintenta.", nombre, exc)
            raise
    logger.info("Leaflet listo en %s.", STATIC_DIR)


def _bboxes_por_municipio() -> dict[str, tuple[float, float, float, float]]:
    """{cve_mun: (lon_min, lat_min, lon_max, lat_max)} de cada municipio de Baja California ya
    cargado — UNO por ciudad, no un solo rectángulo que cubra todo el estado. Las ciudades de
    BC están separadas por mucho desierto/monte sin AGEBs (sin población, así que no hay
    nada que descargar ahí); si se usara un solo bounding box de esquina a esquina del estado
    completo, se descargarían miles de tiles de puro vacío entre ciudades. Por eso se
    descarga un rectángulo compacto alrededor de cada ciudad por separado."""
    import json

    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT cve_mun, rings_json FROM inegi_geometrias WHERE cve_ent = ? AND rings_json IS NOT NULL;",
            (CVE_ENT_BC,),
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        raise RuntimeError(
            "No hay geometrías de Baja California cargadas todavía — corre 'python "
            "main_local.py run-etl' antes de 'setup-mapa'."
        )

    puntos_por_mun: dict[str, list[tuple[float, float]]] = {}
    for row in rows:
        pts = puntos_por_mun.setdefault(row["cve_mun"], [])
        for ring in json.loads(row["rings_json"]):
            pts.extend(ring)

    return {
        mun: (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))
        for mun, pts in puntos_por_mun.items()
    }


def _tile_xy(lon: float, lat: float, zoom: int) -> tuple[int, int]:
    """Convierte lon/lat a coordenadas de tile (esquema slippy-map estándar de OSM)."""
    lat_rad = math.radians(lat)
    n = 2**zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.log(math.tan(lat_rad) + 1 / math.cos(lat_rad)) / math.pi) / 2.0 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def descargar_tiles(
    zoom_min: int = 11,
    zoom_max: int = TILE_MAX_ZOOM_DESCARGADO,
    pausa_seg: float = 1.0,
    reintentos_bloqueo: int = 3,
    espera_reintento_seg: float = 90.0,
) -> None:
    if zoom_max - zoom_min > 6:
        raise ValueError(
            "Rango de zoom demasiado amplio (más de 6 niveles) — reduce zoom_max o sube "
            "zoom_min para no descargar un volumen excesivo de tiles de un servidor público."
        )

    for intento in range(1, reintentos_bloqueo + 1):
        bloqueado = _descargar_tiles_intento(zoom_min, zoom_max, pausa_seg)
        if not bloqueado:
            return
        if intento < reintentos_bloqueo:
            logger.warning(
                "Bloqueado por el proveedor (intento %d/%d) — esperando %.0f segundos antes "
                "de reintentar automáticamente...",
                intento, reintentos_bloqueo, espera_reintento_seg,
            )
            time.sleep(espera_reintento_seg)
    logger.error(
        "Se agotaron los %d reintentos automáticos y el proveedor sigue bloqueando. Espera "
        "más tiempo (varios minutos u horas) y vuelve a correr 'python main_local.py "
        "setup-mapa' a mano — retoma donde quedó.",
        reintentos_bloqueo,
    )


def _descargar_tiles_intento(zoom_min: int, zoom_max: int, pausa_seg: float) -> bool:
    """Descarga los tiles faltantes en el rango dado, para el bounding box compacto de CADA
    municipio de BC por separado (ver _bboxes_por_municipio). Devuelve True si se detuvo por
    bloqueo del proveedor (para que el llamador decida si reintentar), False si terminó
    normal."""
    bboxes = _bboxes_por_municipio()

    planeados: set[tuple[int, int, int]] = set()
    for lon_min, lat_min, lon_max, lat_max in bboxes.values():
        # Margen del 8% alrededor del bounding box real de cada ciudad, para no dejarla
        # pegada al borde del mapa cuando el usuario haga zoom-out.
        margen_lon = (lon_max - lon_min) * 0.08
        margen_lat = (lat_max - lat_min) * 0.08
        lon_min, lon_max = lon_min - margen_lon, lon_max + margen_lon
        lat_min, lat_max = lat_min - margen_lat, lat_max + margen_lat
        for zoom in range(zoom_min, zoom_max + 1):
            x_min, y_max = _tile_xy(lon_min, lat_min, zoom)
            x_max, y_min = _tile_xy(lon_max, lat_max, zoom)
            for x in range(x_min, x_max + 1):
                for y in range(y_min, y_max + 1):
                    planeados.add((zoom, x, y))

    faltantes = [
        (zoom, x, y, TILES_DIR / str(zoom) / str(x) / f"{y}.png")
        for zoom, x, y in sorted(planeados)
        if not (TILES_DIR / str(zoom) / str(x) / f"{y}.png").exists()
    ]
    total_a_descargar = len(faltantes)

    eta_min = total_a_descargar * pausa_seg / 60
    logger.info(
        "Tiles: %d ya en disco, %d por descargar (zoom %d-%d, %d municipios de BC) — "
        "~%.0f min sin contar reintentos. No se congela: si no ves una línea nueva en un "
        "rato, sigue trabajando (cada tile tarda ~%.1fs); solo avisa cada 50.",
        len(planeados) - total_a_descargar, total_a_descargar, zoom_min, zoom_max, len(bboxes),
        eta_min, pausa_seg,
    )
    if not faltantes:
        logger.info("Nada por descargar — los tiles ya están completos en %s.", TILES_DIR)
        return False

    ok, fallidos, bloqueos_seguidos = 0, 0, 0
    for i, (zoom, x, y, destino) in enumerate(faltantes, start=1):
        url = TILE_URL_TEMPLATE.format(z=zoom, x=x, y=y)
        try:
            _descargar_tile(url, destino)
            ok += 1
            bloqueos_seguidos = 0
        except TileBloqueadoError as exc:
            fallidos += 1
            bloqueos_seguidos += 1
            logger.warning("Tile z=%d x=%d y=%d: %s", zoom, x, y, exc)
            if bloqueos_seguidos >= 10:
                logger.warning(
                    "El proveedor de tiles bloqueó %d descargas seguidas (probable límite "
                    "por volumen/frecuencia). Descargados en este intento: %d/%d.",
                    bloqueos_seguidos, ok, total_a_descargar,
                )
                return True
        except (urllib.error.URLError, TimeoutError) as exc:
            fallidos += 1
            logger.warning("Tile z=%d x=%d y=%d falló (%s) — se reintentará si vuelves a correr setup-mapa.", zoom, x, y, exc)
        if i % 20 == 0 or i == total_a_descargar:
            logger.info("  %d/%d tiles procesados (%d OK, %d fallidos)...", i, total_a_descargar, ok, fallidos)
        time.sleep(pausa_seg)

    logger.info("Descarga de tiles completa: %d OK, %d fallidos de %d.", ok, fallidos, total_a_descargar)
    if fallidos:
        logger.warning("Vuelve a correr 'python main_local.py setup-mapa' para reintentar solo los tiles faltantes.")
    return False


def setup_mapa(zoom_min: int = 11, zoom_max: int = TILE_MAX_ZOOM_DESCARGADO) -> None:
    descargar_leaflet()
    descargar_tiles(zoom_min=zoom_min, zoom_max=zoom_max)
