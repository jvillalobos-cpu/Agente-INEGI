"""Encuesta Intercensal 2025 (EIC 2025), INEGI — cifras oficiales publicadas en texto (no
microdato descargable), momento de referencia 15 de octubre de 2025.

A diferencia del Censo 2020 (inegi_censo, microdato completo a nivel AGEB), la EIC 2025 solo
publica resultados a nivel nacional/estatal/municipal — INEGI nunca libera microdatos de la
intercensal a nivel AGEB/colonia. Por eso estas cifras se muestran como panel de CONTEXTO
general (población, edad, salud, economía) junto al análisis por zona, en vez de usarse para
recalcular población por AGEB — mezclar ambas vintages/granularidades a esa escala produciría
números inventados, no un dato real de INEGI.

Fuente: INEGI, Encuesta Intercensal 2025, resultados Baja California.
"""

# {cve_mun: (nombre, población 2025, % del total estatal, edad mediana 2025)}
EIC2025_POBLACION_MUNICIPIOS = {
    "004": ("Tijuana", 1_999_816, 50.26, 31),
    "002": ("Mexicali", 1_080_999, 27.17, 32),
    "001": ("Ensenada", 480_527, 12.08, 33),
    "006": ("San Quintín", 125_323, 3.15, 26),
    "005": ("Playas de Rosarito", 160_253, 4.01, 33),
    "003": ("Tecate", 111_640, 2.81, 32),
    "007": ("San Felipe", 20_520, 0.52, 34),
}

EIC2025_ESTATAL = {
    "poblacion_total": 4_009_678,
    "poblacion_viviendas_particulares": 3_978_593,
    "poblacion_2020_viviendas_particulares": 3_769_020,
    "tasa_crecimiento_anual_2025": 1.1,
    "pct_mujeres": 50.5,
    "pct_hombres": 49.5,
    "edad_mediana_2025": 31,
    "edad_mediana_2020": 30,
    "grupos_edad": {
        "0 a 14 años": 20.3,
        "15 a 29 años": 23.4,
        "30 a 59 años": 41.9,
        "60 años y más": 14.5,
    },
    "razon_dependencia_total": 39.1,
    "razon_dependencia_infantil": 28.3,
    "razon_dependencia_vejez": 10.8,
    "pct_afiliacion_salud": 76.3,
    "pct_no_afiliado_salud": 23.4,
    "afiliacion_por_institucion": {
        "IMSS": 68.7,
        "Centros de Salud Públicos / IMSS-Bienestar": 12.1,
        "Institución privada / seguro privado": 8.8,
        "ISSSTE": 4.8,
        "ISSSTE Estatal (ISSSTECALI)": 3.5,
        "PEMEX / Defensa / Marina": 0.8,
    },
    "atencion_medica_efectiva": {
        "IMSS": 44.3,
        "Consultorio, clínica u hospital privado": 15.6,
        "Consultorio adyacente a farmacia (CAF)": 15.5,
        "Centro de Salud / Hospital de Salud / IMSS-Bienestar": 9.4,
        "ISSSTE": 3.1,
        "ISSSTE Estatal": 2.5,
        "Otra institución / no se atiende": 9.6,
    },
    "tasa_participacion_economica": 58.8,
    "tasa_participacion_hombres": 72.1,
    "tasa_participacion_mujeres": 45.8,
    "sector_economico": {
        "Primario (agricultura, ganadería, pesca)": 4.6,
        "Secundario — Manufactura y minería": 28.0,
        "Secundario — Construcción": 7.7,
        "Terciario — Comercio": 18.5,
        "Terciario — Servicios y gobierno": 39.9,
    },
    "grado_promedio_escolaridad": 10.6,
    "pct_analfabetismo": 1.3,
}
