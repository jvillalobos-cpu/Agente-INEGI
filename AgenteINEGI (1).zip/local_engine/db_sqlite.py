"""Modelado e inicialización de la base de datos local (SQLite, incluido en Python).

Sin PostgreSQL/PostGIS. Idempotente: usa CREATE TABLE IF NOT EXISTS y UPSERT nativo de SQLite.
"""
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS inegi_geometrias (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    nivel TEXT NOT NULL,
    centroid_x REAL NOT NULL,
    centroid_y REAL NOT NULL,
    rings_json TEXT
);

CREATE TABLE IF NOT EXISTS inegi_censo (
    cve_geo TEXT PRIMARY KEY,
    cve_ent TEXT NOT NULL,
    cve_mun TEXT NOT NULL,
    cve_loc TEXT NOT NULL,
    cve_ageb TEXT NOT NULL,
    vivtot REAL, tvivparhab REAL, vivpar_des REAL, vph_pisoti REAL,
    vph_c_elec REAL, vph_excsa REAL, vph_drenaj REAL,
    pobtot REAL, pobfem REAL, pobmas REAL, p_0a14 REAL, p_15a29 REAL,
    p_30a59 REAL, p_60ymas REAL, pcon_disc REAL,
    p15ym_se REAL, vph_inter REAL, vph_autom REAL,
    pder_ss REAL, pder_imss REAL, pder_iste REAL, pder_segpub REAL, psinder REAL
);

CREATE TABLE IF NOT EXISTS colonias_cp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    colonia TEXT,
    cp TEXT,
    municipio TEXT,
    rings_json TEXT NOT NULL,
    UNIQUE (colonia, cp, municipio)
);

CREATE TABLE IF NOT EXISTS colonia_ageb_asignacion (
    colonia_cp_id INTEGER NOT NULL REFERENCES colonias_cp(id),
    cve_geo TEXT NOT NULL REFERENCES inegi_geometrias(cve_geo),
    PRIMARY KEY (colonia_cp_id, cve_geo)
);

CREATE INDEX IF NOT EXISTS idx_colonias_cp_colonia ON colonias_cp (colonia);
CREATE INDEX IF NOT EXISTS idx_colonias_cp_cp ON colonias_cp (cp);

CREATE TABLE IF NOT EXISTS denue_salud (
    id TEXT PRIMARY KEY,
    cve_geo TEXT NOT NULL,
    codigo_act TEXT NOT NULL,
    nombre_act TEXT,
    nombre_estab TEXT,
    direccion TEXT,
    categoria TEXT NOT NULL DEFAULT 'Otros servicios de salud',
    es_laboratorio INTEGER NOT NULL DEFAULT 0,
    lat REAL,
    lon REAL
);

CREATE INDEX IF NOT EXISTS idx_denue_salud_cve_geo ON denue_salud (cve_geo);

CREATE TABLE IF NOT EXISTS denue_comercios (
    id TEXT PRIMARY KEY,
    cve_geo TEXT NOT NULL,
    codigo_act TEXT NOT NULL,
    marca TEXT NOT NULL,
    nombre_estab TEXT,
    direccion TEXT,
    lat REAL,
    lon REAL
);

CREATE INDEX IF NOT EXISTS idx_denue_comercios_cve_geo ON denue_comercios (cve_geo);

CREATE TABLE IF NOT EXISTS marginacion_ageb (
    cve_geo TEXT PRIMARY KEY,
    poblacion REAL,
    indice_marginacion REAL,
    grado_marginacion TEXT,
    indice_normalizado REAL
);

CREATE TABLE IF NOT EXISTS esep_recursos_salud (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cve_geo TEXT NOT NULL,
    tipo_establecimiento TEXT,
    personal_medico INTEGER, personal_no_medico INTEGER,
    consultorios INTEGER, camas_censables INTEGER, quirofanos INTEGER, unidades_dentales INTEGER,
    lab_analisis_clinicos INTEGER, lab_anatomia_patologica INTEGER, salas_radiologia INTEGER,
    equipos_rayos_x INTEGER, equipos_resonancia_magnetica INTEGER, equipos_tomografia INTEGER,
    equipos_mamografia INTEGER, equipos_ultrasonido INTEGER
);

CREATE INDEX IF NOT EXISTS idx_esep_recursos_cve_geo ON esep_recursos_salud (cve_geo);

-- Inventario de hospitales privados de Tijuana con capacidad cardiovascular (nivel II/III,
-- quirófanos, camas) — curado a mano por el usuario, no viene geocodificado a AGEB (sin
-- direcciones/coordenadas confiables por hospital), así que se muestra como catálogo general
-- de la ciudad en vez de filtrarse por zona exacta como denue_salud/esep_recursos_salud.
CREATE TABLE IF NOT EXISTS hospitales_cardio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital TEXT NOT NULL,
    nivel TEXT NOT NULL,
    especialidades TEXT,
    quirofanos_min INTEGER,
    quirofanos_max INTEGER,
    camas_min INTEGER,
    camas_max INTEGER,
    notas TEXT
);

-- Laboratorios de análisis clínicos de Tijuana, curados a mano por el usuario (barrido de
-- Google Maps, no es un directorio oficial de INEGI) — universo de competidores real para el
-- modelaje de "% de mercado" a nivel ciudad (server.py:render_mercado_laboratorios), con
-- coordenadas exactas por sucursal (a diferencia del DENUE, que para esta industria mezcla
-- patología/imagen y no siempre da nombre de cadena limpio).
CREATE TABLE IF NOT EXISTS laboratorios_mercado (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    cadena TEXT NOT NULL,
    tipo TEXT,
    colonia TEXT,
    direccion TEXT,
    telefono TEXT,
    lat REAL,
    lon REAL,
    calificacion REAL,
    num_resenas INTEGER,
    place_id TEXT
);

-- Empresas/maquiladoras con nómina alta (101+ empleados) en Tijuana — combina dos fuentes
-- posibles: DENUE (INEGI, filtrado por rango de personal ocupado) y directorios de
-- maquiladoras (INDEX Tijuana, DIMBC, etc.), cada fila con su "fuente" para poder distinguir
-- cuál es cuál. Ver local_engine/etl_local.py:load_empresas_nomina.
CREATE TABLE IF NOT EXISTS empresas_nomina (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    razon_social TEXT,
    sector TEXT,
    rango_personal TEXT,
    direccion TEXT,
    colonia TEXT,
    telefono TEXT,
    lat REAL,
    lon REAL,
    fuente TEXT
);

-- Gasolineras de Baja California (Tijuana, Rosarito, Tecate y el resto del estado) — padrón de
-- estaciones de servicio con coordenadas reales, marca comercial y permisionario (fuente: CNE,
-- antes CRE, padrón público de permisos de expendio al público de petrolíferos). municipio se
-- resuelve localmente por punto-en-polígono contra el Marco Geoestadístico ya cargado (igual
-- que identificar_punto), no depende de que la fuente lo traiga.
CREATE TABLE IF NOT EXISTS gasolineras (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    marca TEXT,
    permisionario TEXT,
    numero_permiso TEXT,
    direccion TEXT,
    colonia TEXT,
    municipio TEXT,
    lat REAL,
    lon REAL,
    precio_regular REAL,
    precio_premium REAL,
    precio_diesel REAL,
    fuente TEXT
);

CREATE INDEX IF NOT EXISTS idx_gasolineras_municipio ON gasolineras (municipio);

-- Análisis/lugares guardados por el usuario: se guarda la query string TAL CUAL (no se vuelve
-- a modelar cada campo por separado) porque tanto la búsqueda normal ("/") como la de zonas
-- combinadas ("/comparar") ya codifican todo su estado ahí — guardar el string es robusto a
-- que esos parámetros cambien más adelante, sin tener que migrar esta tabla cada vez.
-- resumen_poblacion/resumen_valor: snapshot en TEXTO (no se recalculan al reabrir) de la
-- población y del resultado de "Valor de la zona" al momento de guardar — pedido explícito
-- del usuario para /comparar, donde "Valor de la zona" depende de inputs manuales (pacientes
-- actuales, frecuencias marcadas) que no viven en la query string, así que sin este snapshot
-- la lista de guardados no diría nada útil de un vistazo.
CREATE TABLE IF NOT EXISTS analisis_guardados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    destino TEXT NOT NULL,
    query_string TEXT NOT NULL,
    resumen_poblacion TEXT,
    resumen_valor TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
"""


def get_connection(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn


def setup_database(db_path: Path) -> None:
    conn = get_connection(db_path)
    try:
        conn.executescript(SCHEMA)
        _migrar_columnas_faltantes(conn)
        conn.commit()
    finally:
        conn.close()


def _migrar_columnas_faltantes(conn: sqlite3.Connection) -> None:
    """Agrega columnas nuevas a bases de datos creadas con un esquema anterior
    (sqlite no soporta 'ADD COLUMN IF NOT EXISTS', así que se verifica a mano)."""
    columnas = {row["name"] for row in conn.execute("PRAGMA table_info(inegi_geometrias);")}
    if "rings_json" not in columnas:
        conn.execute("ALTER TABLE inegi_geometrias ADD COLUMN rings_json TEXT;")

    columnas_denue = {row["name"] for row in conn.execute("PRAGMA table_info(denue_salud);")}
    if columnas_denue and "categoria" not in columnas_denue:
        conn.execute("ALTER TABLE denue_salud ADD COLUMN categoria TEXT NOT NULL DEFAULT 'Otros servicios de salud';")

    columnas_hosp_cardio = {row["name"] for row in conn.execute("PRAGMA table_info(hospitales_cardio);")}
    if columnas_hosp_cardio and "quirofanos_min" not in columnas_hosp_cardio:
        # La tabla se creó en una sesión anterior con columnas quirofanos/camas de texto libre
        # (antes de tener el Excel con rangos numéricos) — se recrea vacía con el esquema
        # nuevo en vez de migrar datos, porque load_hospitales_cardio() siempre hace un
        # DELETE + recarga completa desde el CSV en cada run-etl (sin llave natural que
        # preservar).
        conn.execute("DROP TABLE hospitales_cardio;")
        conn.execute(
            """
            CREATE TABLE hospitales_cardio (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hospital TEXT NOT NULL,
                nivel TEXT NOT NULL,
                especialidades TEXT,
                quirofanos_min INTEGER,
                quirofanos_max INTEGER,
                camas_min INTEGER,
                camas_max INTEGER,
                notas TEXT,
                lat REAL,
                lon REAL
            );
            """
        )
    elif columnas_hosp_cardio and "lat" not in columnas_hosp_cardio:
        conn.execute("ALTER TABLE hospitales_cardio ADD COLUMN lat REAL;")
        conn.execute("ALTER TABLE hospitales_cardio ADD COLUMN lon REAL;")

    columnas_guardados = {row["name"] for row in conn.execute("PRAGMA table_info(analisis_guardados);")}
    if columnas_guardados and "resumen_poblacion" not in columnas_guardados:
        conn.execute("ALTER TABLE analisis_guardados ADD COLUMN resumen_poblacion TEXT;")
    if columnas_guardados and "resumen_valor" not in columnas_guardados:
        conn.execute("ALTER TABLE analisis_guardados ADD COLUMN resumen_valor TEXT;")
