"""Operaciones geométricas en Python puro (sin shapely/PostGIS).

Simplificación deliberada frente a la versión PostGIS del proyecto: en vez de calcular
la fracción de área de intersección entre AGEB y colonia (ST_Intersection), se asigna
un AGEB a una colonia cuando el CENTROIDE del AGEB cae dentro del polígono de la colonia.
Esta es la alternativa explícitamente permitida para el "traductor" Colonia -> AGEB
cuando no se dispone de una librería de recorte de polígonos robusta para geometrías
cóncavas arbitrarias.
"""
import math

Point = tuple[float, float]
Ring = list[Point]

EARTH_RADIUS_KM = 6371.0088


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distancia en línea recta (great-circle) entre dos puntos lon/lat, en kilómetros."""
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


KM_POR_GRADO_LAT = 110.574


def _km_por_grado_lon(lat_ref_deg: float) -> float:
    return 111.320 * math.cos(math.radians(lat_ref_deg))


def area_km2_multiring(rings: list[Ring]) -> float:
    """Área real (km²) de un shape multi-anillo — proyecta lon/lat a km localmente (mismo
    método que local_engine/svg_map.py, válido para áreas del tamaño de un AGEB/colonia,
    donde la curvatura de la Tierra no importa) y suma el área con signo de cada anillo
    (los huecos, con orientación opuesta al anillo exterior, restan). Usado para estimar un
    "radio equivalente" de una zona irregular — ver estimar_radio_equivalente_km()."""
    todos_los_puntos = [pt for ring in rings for pt in ring]
    if not todos_los_puntos:
        return 0.0
    lat_ref = sum(p[1] for p in todos_los_puntos) / len(todos_los_puntos)
    km_lon = _km_por_grado_lon(lat_ref)

    area_total = 0.0
    for ring in rings:
        ring_km = [(lon * km_lon, lat * KM_POR_GRADO_LAT) for lon, lat in ring]
        area_total += ring_area_signed(ring_km)
    return abs(area_total)


def ring_area_signed(ring: Ring) -> float:
    """Área con signo (shoelace). Positiva = sentido antihorario."""
    area = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return area / 2.0


def ring_centroid(ring: Ring) -> Point:
    """Centroide de un polígono simple (ring) vía fórmula del área con signo."""
    area = ring_area_signed(ring)
    n = len(ring)
    if abs(area) < 1e-12:
        # Polígono degenerado: usa promedio simple de vértices.
        xs = [p[0] for p in ring]
        ys = [p[1] for p in ring]
        return (sum(xs) / n, sum(ys) / n)

    cx = 0.0
    cy = 0.0
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        cross = x1 * y2 - x2 * y1
        cx += (x1 + x2) * cross
        cy += (y1 + y2) * cross
    cx /= 6 * area
    cy /= 6 * area
    return (cx, cy)


def multiring_centroid(rings: list[Ring]) -> Point:
    """Centroide aproximado de un shape multi-anillo, ponderado por área de cada ring.

    Los rings que representan huecos (orientación opuesta al ring exterior) restan peso.
    """
    if not rings:
        raise ValueError("No hay anillos para calcular centroide.")
    if len(rings) == 1:
        return ring_centroid(rings[0])

    total_area = 0.0
    cx_sum = 0.0
    cy_sum = 0.0
    for ring in rings:
        if len(ring) < 3:
            continue
        area = ring_area_signed(ring)
        cx, cy = ring_centroid(ring)
        cx_sum += cx * area
        cy_sum += cy * area
        total_area += area

    if abs(total_area) < 1e-12:
        ring = rings[0]
        return ring_centroid(ring)

    return (cx_sum / total_area, cy_sum / total_area)


def point_in_ring(point: Point, ring: Ring) -> bool:
    """Ray casting: ¿el punto está dentro del polígono simple (ring)?"""
    x, y = point
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        intersects = ((yi > y) != (yj > y)) and (
            x < (xj - xi) * (y - yi) / (yj - yi + 1e-15) + xi
        )
        if intersects:
            inside = not inside
        j = i
    return inside


def point_in_multiring(point: Point, rings: list[Ring]) -> bool:
    """Punto dentro del shape considerando huecos: dentro de un ring exterior y fuera de huecos."""
    if not rings:
        return False
    if len(rings) == 1:
        return point_in_ring(point, rings[0])

    # Heurística: ring con mayor |área| es el exterior; el resto se tratan como huecos.
    rings_sorted = sorted(rings, key=lambda r: abs(ring_area_signed(r)), reverse=True)
    outer, *holes = rings_sorted
    if not point_in_ring(point, outer):
        return False
    for hole in holes:
        if point_in_ring(point, hole):
            return False
    return True


def bbox(rings: list[Ring]) -> tuple[float, float, float, float]:
    xs = [p[0] for ring in rings for p in ring]
    ys = [p[1] for ring in rings for p in ring]
    return (min(xs), min(ys), max(xs), max(ys))
