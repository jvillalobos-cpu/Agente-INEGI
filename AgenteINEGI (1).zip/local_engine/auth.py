"""Candado de acceso simple para el servidor local — UN solo password compartido para abrir la
app (protege contra que cualquiera en la misma red/oficina la abra sin más), no es un sistema de
cuentas/usuarios ni login real (nada de OAuth): no requiere internet ni servicios externos, en
línea con el resto de Agente INEGI (100% local, sin conexión).

Las sesiones viven solo en memoria del proceso (ver _SESIONES_ACTIVAS): al reiniciar el
servidor, todos vuelven a necesitar la contraseña — suficiente para este gate de un solo
password compartido, no hace falta persistirlas en disco.
"""
import hmac
import secrets

from config import AUTH_PASSWORD

COOKIE_NAME = "agente_inegi_sesion"

_SESIONES_ACTIVAS: set[str] = set()


def password_correcta(intentada: str) -> bool:
    """Comparación en tiempo constante (hmac.compare_digest) para no filtrar por timing cuánto
    de la contraseña acertó un intento, aunque el riesgo real aquí es bajo (uso en red local)."""
    return hmac.compare_digest(intentada, AUTH_PASSWORD)


def crear_sesion() -> str:
    token = secrets.token_hex(32)
    _SESIONES_ACTIVAS.add(token)
    return token


def cerrar_sesion(token: str | None) -> None:
    if token:
        _SESIONES_ACTIVAS.discard(token)


def _token_de_cookie(cookie_header: str | None) -> str | None:
    if not cookie_header:
        return None
    for parte in cookie_header.split(";"):
        if "=" not in parte:
            continue
        nombre, _, valor = parte.strip().partition("=")
        if nombre == COOKIE_NAME:
            return valor
    return None


def sesion_valida(cookie_header: str | None) -> bool:
    token = _token_de_cookie(cookie_header)
    return token is not None and token in _SESIONES_ACTIVAS


def token_de_cookie(cookie_header: str | None) -> str | None:
    """Expuesto para /logout (necesita el token exacto a invalidar, no solo saber si es válido)."""
    return _token_de_cookie(cookie_header)
