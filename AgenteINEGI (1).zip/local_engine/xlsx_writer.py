"""Generador mínimo de archivos .xlsx (Office Open XML) usando solo la librería estándar de
Python (zipfile + xml), sin depender de openpyxl ni ninguna librería externa — mismo espíritu
100% local del resto del agente.

No es un generador de XLSX de propósito general: cubre justo lo que necesita
local_engine/query_engine_local.escribir_reporte_xlsx() (varias hojas, celdas de texto/número,
tres estilos de fila —título de sección, encabezado de tabla, normal—, ancho de columna fijo
por hoja y primera fila congelada). Usa <is> (inline string) en vez de sharedStrings.xml para
mantener el formato más simple, a costa de un archivo un poco más grande — irrelevante para
reportes de este tamaño (cientos de filas, no cientos de miles).
"""
import io
import zipfile
from dataclasses import dataclass, field
from xml.sax.saxutils import escape as _xml_escape

# --- Estilos: cada uno es un índice a <xf> en styles.xml, en el mismo orden que STYLES_XF. ---
ESTILO_NORMAL = 0
ESTILO_TITULO_SECCION = 1  # fondo de color, texto blanco en negrita — encabezado de cada categoría
ESTILO_ENCABEZADO_TABLA = 2  # fondo gris claro, negrita — fila de encabezados de columna
ESTILO_NORMAL_NEGRITA = 3


@dataclass
class Celda:
    valor: str | float | int | None
    estilo: int = ESTILO_NORMAL


@dataclass
class Hoja:
    nombre: str
    filas: list[list[Celda]] = field(default_factory=list)
    anchos_columnas: list[float] = field(default_factory=list)  # en "caracteres", como Excel
    congelar_primera_fila: bool = False


def _col_letra(idx0: int) -> str:
    """0 -> A, 1 -> B, ..., 26 -> AA, ..."""
    letras = ""
    n = idx0 + 1
    while n > 0:
        n, resto = divmod(n - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
{sheet_overrides}
</Types>"""

_RELS_ROOT = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

_WORKBOOK_RELS_TEMPLATE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
{sheet_rels}
</Relationships>"""

_STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4">
<font><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="10"/><color rgb="FF1C1F24"/><name val="Calibri"/></font>
<font><b/><sz val="10"/><name val="Calibri"/></font>
</fonts>
<fills count="4">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF2F5496"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEAF0FB"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="4">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def _sheet_xml(hoja: Hoja) -> str:
    partes = ["<sheetData>"]
    for i, fila in enumerate(hoja.filas, start=1):
        celdas_xml = []
        for j, celda in enumerate(fila):
            ref = f"{_col_letra(j)}{i}"
            if celda.valor is None or celda.valor == "":
                continue
            if isinstance(celda.valor, (int, float)) and not isinstance(celda.valor, bool):
                celdas_xml.append(f'<c r="{ref}" s="{celda.estilo}"><v>{celda.valor}</v></c>')
            else:
                texto = _xml_escape(str(celda.valor))
                celdas_xml.append(f'<c r="{ref}" s="{celda.estilo}" t="inlineStr"><is><t xml:space="preserve">{texto}</t></is></c>')
        partes.append(f'<row r="{i}">{"".join(celdas_xml)}</row>')
    partes.append("</sheetData>")

    cols_xml = ""
    if hoja.anchos_columnas:
        cols = "".join(
            f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>'
            for i, w in enumerate(hoja.anchos_columnas)
        )
        cols_xml = f"<cols>{cols}</cols>"

    vista = ""
    if hoja.congelar_primera_fila:
        vista = (
            '<sheetViews><sheetView workbookViewId="0">'
            '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            "</sheetView></sheetViews>"
        )

    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"{vista}{cols_xml}{''.join(partes)}"
        "</worksheet>"
    )


def escribir_xlsx(hojas: list[Hoja]) -> bytes:
    """Arma el .xlsx completo en memoria y devuelve los bytes listos para escribir a disco o
    mandar por HTTP — no toca el sistema de archivos salvo por el zip en memoria."""
    if not hojas:
        raise ValueError("Se necesita al menos una hoja.")

    sheet_overrides = "\n".join(
        f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for i in range(1, len(hojas) + 1)
    )
    sheet_rels = "\n".join(
        f'<Relationship Id="rIdSheet{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>'
        for i in range(1, len(hojas) + 1)
    )
    sheets_workbook = "\n".join(
        f'<sheet name="{_xml_escape(h.nombre)[:31]}" sheetId="{i}" r:id="rIdSheet{i}"/>'
        for i, h in enumerate(hojas, start=1)
    )
    workbook_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"<sheets>{sheets_workbook}</sheets>"
        "</workbook>"
    )

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", _CONTENT_TYPES.format(sheet_overrides=sheet_overrides))
        zf.writestr("_rels/.rels", _RELS_ROOT)
        zf.writestr("xl/workbook.xml", workbook_xml)
        zf.writestr("xl/_rels/workbook.xml.rels", _WORKBOOK_RELS_TEMPLATE.format(sheet_rels=sheet_rels))
        zf.writestr("xl/styles.xml", _STYLES_XML)
        for i, hoja in enumerate(hojas, start=1):
            zf.writestr(f"xl/worksheets/sheet{i}.xml", _sheet_xml(hoja))
    return buf.getvalue()
