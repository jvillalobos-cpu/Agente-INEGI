"""Servidor web local (http.server, incluido en Python) con formulario HTML dinámico.

Se ejecuta 100% en localhost, sin ninguna llamada de red saliente ni dependencia externa.
"""
import html
import json
import math
import re
import urllib.parse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer

from local_engine.query_engine_local import (
    CATEGORIAS,
    VARIABLE_LABELS,
    VARIABLES_NO_DISPONIBLES_AGEB,
    ZonaNoEncontradaError,
    analizar_locacion,
    analizar_por_coordenada,
    estimar_edades_15_59,
    ORDEN_CATEGORIAS_DENUE,
    ETIQUETAS_ESEP,
    contar_unidades_salud,
    establecimientos_por_categoria,
    contar_comercios_referencia,
    establecimientos_por_marca,
    centroides_por_agebs,
    estimar_nivel_socioeconomico,
    obtener_marginacion,
    obtener_recursos_hospitalarios,
    listar_hospitales_cardio,
    geometria_para_mapa,
    analizar_municipio,
    MUNICIPIOS_BC,
    rings_municipio,
    nse_por_ageb,
    capa_por_ageb,
    CAPAS_MAPA,
    totales_por_agebs,
    colonias_para_agebs,
    generar_reporte_xlsx,
    estimar_radio_equivalente_km,
    guardar_analisis,
    listar_analisis_guardados,
    eliminar_analisis_guardado,
    RETORNO_FRECUENCIAS,
    hospitales_cardio_cercanos,
    analizar_mercado_laboratorios,
    analizar_empresas_nomina,
    empresas_en_zona,
    laboratorios_cercanos,
    RADIO_LABORATORIOS_CERCANOS_KM,
)
from local_engine.svg_map import MAPA_SCRIPT, render_mapa
from local_engine.geometry import haversine_km
from local_engine.intercensal_2025 import EIC2025_ESTATAL, EIC2025_POBLACION_MUNICIPIOS
from local_engine.leaflet_map import MAPA_LEAFLET_SCRIPT, render_mapa_leaflet
from local_engine.auth import (
    COOKIE_NAME,
    password_correcta,
    crear_sesion,
    cerrar_sesion,
    sesion_valida,
    token_de_cookie,
)
from config import STATIC_DIR, TILES_DIR, TILE_MAX_ZOOM_DESCARGADO
from logger_setup import get_logger

logger = get_logger("server")

CATEGORIA_LABELS = {
    "Vivienda": "Vivienda",
    "Poblacion": "Población",
    "Educacion_Socioeconomico": "Educación / Socioeconómico",
    "Salud": "Salud",
}

# Paleta minimalista, un tono por categoría (accesible en fondo claro y oscuro).
CATEGORIA_COLOR = {
    "Vivienda": "#2f6f4f",
    "Poblacion": "#2f5496",
    "Educacion_Socioeconomico": "#9a6b1a",
    "Salud": "#9a3b52",
}

DONUT_PALETTE = ["#2f5496", "#c0392b", "#2f6f4f", "#9a6b1a", "#6b6f76"]
DONUT_GRIS = "#c7cbd1"

SHARED_STYLE_BLOCK = """

  :root {{
    --bg: #f7f8fa;
    --surface: #ffffff;
    --border: #e3e6ea;
    --text: #1c1f24;
    --text-muted: #6b7280;
    --accent: #2f5496;
    --accent-soft: #eaf0fb;
    --error: #b3261e;
    --radius: 10px;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    max-width: 960px; margin: 0 auto; padding: 2.5rem 1.5rem 4rem;
    color: var(--text); background: var(--bg); line-height: 1.5;
  }}
  h1 {{ font-size: 1.5rem; font-weight: 600; margin: 0 0 0.25rem; letter-spacing: -0.01em; }}
  h2 {{ font-size: 1.15rem; font-weight: 600; margin: 0; }}
  .subtitle {{ color: var(--text-muted); font-size: 0.9rem; margin: 0 0 1.75rem; }}
  .subtitle a {{ color: var(--accent); font-weight: 600; text-decoration: none; }}
  .subtitle a:hover {{ text-decoration: underline; }}
  form.search {{
    display: flex; gap: 0.6rem; margin-bottom: 0.6rem; flex-wrap: wrap;
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 0.9rem; align-items: center;
  }}
  select, input[type=text] {{
    padding: 0.5rem 0.65rem; font-size: 0.95rem; border: 1px solid var(--border);
    border-radius: 6px; background: var(--surface); color: var(--text);
  }}
  input[type=text] {{ flex: 1; min-width: 160px; }}
  input[name=radio] {{ flex: 0 0 130px; min-width: 0; }}
  button {{
    padding: 0.55rem 1.1rem; font-size: 0.95rem; font-weight: 600; cursor: pointer;
    background: var(--accent); color: #fff; border: none; border-radius: 6px;
  }}
  button:hover {{ opacity: 0.92; }}
  button.secondary {{ background: var(--accent-soft); color: var(--accent); }}
  .hint {{ color: var(--text-muted); font-size: 0.82rem; margin: 0.6rem 0 2rem; }}
  .error {{
    color: var(--error); background: #fdecea; border: 1px solid #f5c6c2;
    border-radius: var(--radius); padding: 0.8rem 1rem; font-size: 0.92rem;
  }}
  .result-header {{ display: flex; align-items: baseline; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem; }}
  .result-header .badge {{
    font-size: 0.78rem; font-weight: 600; color: var(--accent); background: var(--accent-soft);
    padding: 0.25rem 0.6rem; border-radius: 999px; white-space: nowrap;
  }}
  .zonas-box {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 0.9rem 1rem; margin: 0.75rem 0 1.5rem;
  }}
  .zonas-box p {{ color: var(--text-muted); font-size: 0.85rem; margin: 0 0 0.7rem; }}
  .zonas-list {{ display: flex; flex-direction: column; gap: 0.45rem; max-height: 220px; overflow-y: auto; margin-bottom: 0.8rem; }}
  .zona-item {{ display: flex; align-items: flex-start; gap: 0.5rem; font-size: 0.84rem; }}
  .zona-item input {{ margin-top: 0.2rem; }}
  .zona-item .zona-cp {{ color: var(--text-muted); font-weight: 600; white-space: nowrap; }}
  .zonas-actions {{ display: flex; gap: 0.5rem; }}
  .zonas-actions button {{ font-size: 0.8rem; padding: 0.4rem 0.8rem; }}
  .nse-filtro-box {{
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 0.8rem 1rem; margin: 0.75rem 0 1.2rem;
  }}
  .nse-filtro-hint {{ color: var(--text-muted); font-size: 0.82rem; margin: 0 0 0.6rem; }}
  .nse-filtro-list {{ display: flex; flex-wrap: wrap; gap: 0.9rem; margin-bottom: 0.7rem; }}
  .nse-filtro-item {{ display: inline-flex; align-items: center; gap: 0.35rem; font-size: 0.85rem; cursor: pointer; }}
  .nse-filtro-actions button {{ font-size: 0.8rem; padding: 0.35rem 0.75rem; }}
  .radio-equivalente {{ color: var(--text-muted); font-size: 0.82rem; margin: 0.4rem 0 0.8rem; }}
  .export-bar {{ margin: 0.5rem 0 0.2rem; }}
  .secondary-link {{
    display: inline-block; font-size: 0.82rem; font-weight: 600; color: var(--accent);
    background: var(--accent-soft); padding: 0.35rem 0.75rem; border-radius: 6px;
    text-decoration: none;
  }}
  .secondary-link:hover {{ opacity: 0.85; }}
  .combinar-nav {{ margin: 0.5rem 0 1rem; display: flex; flex-wrap: wrap; gap: 0.6rem; }}
  .combinar-nav .secondary-link {{ font-size: 0.85rem; padding: 0.5rem 1rem; white-space: nowrap; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }}
  .card {{
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 1.1rem 1.2rem 1.25rem; position: relative;
  }}
  .card-head {{
    display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;
    margin: 0 0 0.9rem; padding-bottom: 0.6rem; border-bottom: 1px solid var(--border); position: relative;
  }}
  .card-head h3 {{ font-size: 0.95rem; font-weight: 600; margin: 0; display: flex; align-items: center; gap: 0.5rem; }}
  .card-head .dot {{ width: 0.6rem; height: 0.6rem; border-radius: 50%; display: inline-block; flex: none; }}
  .chart-toggle summary {{
    list-style: none; cursor: pointer; font-size: 0.75rem; font-weight: 600; color: var(--accent);
    background: var(--accent-soft); padding: 0.3rem 0.65rem; border-radius: 999px; white-space: nowrap;
  }}
  .chart-toggle summary::-webkit-details-marker {{ display: none; }}
  .ver-mas {{ margin-top: 0.5rem; }}
  .ver-mas[open] summary {{ margin-bottom: 0.5rem; }}
  .ver-mas .nse-note {{ margin: 0 0 0.4rem; }}
  .ver-mas .nse-note:last-child {{ margin-bottom: 0; }}
  .chart-panel {{
    position: absolute; top: calc(100% + 0.4rem); right: 0; z-index: 5; width: 270px;
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 1rem; box-shadow: 0 10px 28px rgba(0,0,0,0.16);
  }}
  .chart-panel .donut-row {{ display: flex; align-items: center; gap: 0.9rem; margin-bottom: 0.6rem; }}
  .chart-panel .donut-title {{ font-size: 0.78rem; font-weight: 600; color: var(--text-muted); margin: 0 0 0.5rem; }}
  .chart-panel .legend {{ font-size: 0.78rem; display: flex; flex-direction: column; gap: 0.3rem; }}
  .chart-panel .legend-item {{ display: flex; align-items: center; gap: 0.4rem; }}
  .chart-panel .legend-dot {{ width: 0.55rem; height: 0.55rem; border-radius: 50%; flex: none; }}
  .chart-panel .legend-val {{ margin-left: auto; font-weight: 600; }}
  .chart-panel .chart-note {{ font-size: 0.72rem; color: var(--text-muted); margin: 0.6rem 0 0; border-top: 1px solid var(--border); padding-top: 0.5rem; }}
  .bar-row-inline {{ margin-bottom: 0.65rem; }}
  .bar-row-inline .bar-top {{ display: flex; justify-content: space-between; align-items: baseline; gap: 0.5rem; margin-bottom: 0.3rem; }}
  .bar-row-inline .bar-label {{ font-size: 0.82rem; color: var(--text-muted); }}
  .bar-row-inline .bar-value {{ font-size: 0.82rem; font-weight: 600; white-space: nowrap; }}
  .bar-track {{ display: block; background: #eef0f3; border-radius: 999px; height: 7px; overflow: hidden; }}
  .bar-fill {{ display: block; height: 100%; border-radius: 999px; }}
  .bar-row-inline.na .bar-value {{ color: var(--text-muted); font-weight: 500; font-style: italic; }}
  .bar-row-inline.na .bar-track {{ background: repeating-linear-gradient(45deg, #eef0f3, #eef0f3 4px, #e2e4e8 4px, #e2e4e8 8px); }}
  .denue-cat-row {{ cursor: pointer; border-radius: 8px; padding: 0.3rem 0.4rem; margin: 0 -0.4rem 0.65rem; transition: background 0.1s; }}
  .denue-cat-row:hover, .denue-cat-row:focus-visible {{ background: var(--accent-soft); outline: none; }}

  /* Modal a pantalla completa (fixed overlay) — sin librerías, JS mínimo en DENUE_MODAL_SCRIPT
     solo agrega/quita el atributo hidden y bloquea el scroll del fondo mientras está abierto. */
  .denue-modal {{ position: fixed; inset: 0; z-index: 50; display: flex; align-items: center; justify-content: center; padding: 2rem; }}
  .denue-modal[hidden] {{ display: none; }}
  .denue-modal-backdrop {{ position: absolute; inset: 0; background: rgba(20, 22, 26, 0.55); }}
  .denue-modal-panel {{
    position: relative; background: var(--surface); border-radius: 14px; width: min(760px, 100%);
    max-height: min(720px, 90vh); display: flex; flex-direction: column;
    box-shadow: 0 24px 60px rgba(0,0,0,0.35); overflow: hidden;
  }}
  .denue-modal-header {{
    display: flex; align-items: center; justify-content: space-between; gap: 1rem;
    padding: 1rem 1.25rem; border-bottom: 1px solid var(--border);
  }}
  .denue-modal-header h3 {{ margin: 0; font-size: 1.05rem; }}
  .denue-modal-count {{ color: var(--text-muted); font-weight: 500; }}
  .denue-modal-close-btn {{
    background: none; border: none; font-size: 1.1rem; cursor: pointer; color: var(--text-muted);
    padding: 0.3rem 0.5rem; border-radius: 6px; line-height: 1;
  }}
  .denue-modal-close-btn:hover {{ background: var(--accent-soft); color: var(--text); }}
  .denue-modal-search-wrap {{ padding: 0.75rem 1.25rem 0; }}
  .denue-modal-search {{
    width: 100%; box-sizing: border-box; padding: 0.5rem 0.75rem; font-size: 0.85rem;
    border: 1px solid var(--border); border-radius: 8px; background: var(--bg); color: var(--text);
  }}
  .denue-modal-search:focus {{ outline: 2px solid var(--accent-soft); border-color: var(--accent); }}
  .denue-modal-resultados {{ margin: 0.4rem 0 0; font-size: 0.75rem; color: var(--text-muted); }}
  .denue-modal-empty {{ display: none; padding: 1rem 0.6rem; color: var(--text-muted); font-size: 0.85rem; }}
  .denue-modal-body {{ overflow-y: auto; padding: 0.5rem 1.25rem 1.25rem; }}
  .denue-modal-tabla {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
  .denue-modal-tabla th {{
    position: sticky; top: 0; background: var(--surface); text-align: left; font-size: 0.72rem;
    text-transform: uppercase; letter-spacing: 0.03em; color: var(--text-muted); padding: 0.5rem 0.6rem;
    border-bottom: 1px solid var(--border);
  }}
  .denue-modal-tabla td {{ padding: 0.55rem 0.6rem; border-bottom: 1px solid var(--border); vertical-align: top; }}
  .denue-modal-tabla tr:last-child td {{ border-bottom: none; }}
  .denue-modal-tabla tbody tr.denue-fila-par {{ background: var(--accent-soft); }}
  .denue-modal-nombre {{ font-weight: 600; white-space: nowrap; }}
  .denue-modal-dir {{ color: var(--text-muted); }}
  .nse-box {{ margin-top: 0.9rem; padding-top: 0.9rem; border-top: 1px dashed var(--border); }}
  .nse-top {{ display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; margin-bottom: 0.3rem; }}
  .nse-badge {{ font-size: 0.72rem; font-weight: 700; padding: 0.15rem 0.55rem; border-radius: 999px; white-space: nowrap; }}
  .nse-note {{ font-size: 0.72rem; color: var(--text-muted); margin: 0.5rem 0 0; }}
  .retorno-inputs {{ display: flex; flex-wrap: wrap; gap: 0.8rem; margin-bottom: 0.8rem; }}
  .retorno-inputs label {{ display: flex; flex-direction: column; gap: 0.25rem; font-size: 0.75rem; color: var(--text-muted); }}
  .retorno-inputs input {{ width: 6rem; padding: 0.4rem 0.5rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); font-size: 0.9rem; }}
  .retorno-inputs select {{ padding: 0.4rem 0.5rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); font-size: 0.85rem; }}
  .retorno-resultado {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.7rem; }}
  .retorno-resultado > div {{ display: flex; flex-direction: column; gap: 0.15rem; }}
  .retorno-num {{ font-size: 1.3rem; font-weight: 700; color: var(--accent); }}
  .retorno-formulas p {{ margin: 0.3rem 0; font-size: 0.82rem; }}
  .retorno-formulas code {{ background: var(--accent-soft); padding: 0.15rem 0.4rem; border-radius: 4px; }}
  .retorno-card {{ grid-column: 1 / -1; }}
  .retorno-card .retorno-resultado {{ grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); }}
  .retorno-visuales {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-top: 1rem; align-items: start; }}
  .retorno-pie-row {{ display: flex; align-items: center; justify-content: center; gap: 1.2rem; flex-wrap: wrap; }}
  .retorno-pie-wrap {{ display: flex; flex-direction: column; align-items: center; gap: 0.4rem; }}
  .retorno-pie-holder {{ position: relative; width: 190px; height: 190px; }}
  .retorno-pie-centro {{ position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; pointer-events: none; }}
  .retorno-pie-centro-num {{ font-size: 1.6rem; font-weight: 800; color: var(--text); }}
  .retorno-pie-centro-label {{ font-size: 0.72rem; color: var(--text-muted); }}
  .retorno-pie-legend {{ display: flex; flex-direction: column; align-items: center; gap: 0.5rem; min-width: 200px; }}
  .retorno-pie-legend .legend-item {{ width: 100%; max-width: 260px; }}
  .retorno-pie-legend .legend-item {{ display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; }}
  .retorno-pie-legend .legend-dot {{ width: 0.6rem; height: 0.6rem; border-radius: 50%; flex: none; }}
  .retorno-pie-legend .legend-val {{ margin-left: auto; font-weight: 600; }}
  .retorno-inputs select:disabled {{ opacity: 0.6; }}
  .retorno-inputs input:disabled {{ opacity: 0.6; }}
  .retorno-freq-list {{ display: flex; flex-wrap: wrap; gap: 0.5rem 1.2rem; margin: 0.7rem 0 1rem; padding: 0.7rem 0.9rem; background: var(--bg); border-radius: 8px; border: 1px dashed var(--border); }}
  .retorno-freq-item {{ display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; cursor: pointer; white-space: nowrap; }}
  .retorno-freq-pct {{ color: var(--text-muted); font-size: 0.78rem; }}
  .retorno-pie {{ filter: drop-shadow(0 3px 10px rgba(0,0,0,0.2)); width: 190px; height: 190px; }}
  .retorno-pie svg circle {{ transition: stroke-dasharray 0.6s cubic-bezier(0.34, 1.56, 0.64, 1), stroke-dashoffset 0.6s cubic-bezier(0.34, 1.56, 0.64, 1); }}
  @keyframes retorno-pie-pop {{ 0% {{ transform: scale(0.7) rotate(-90deg); opacity: 0; }} 100% {{ transform: scale(1) rotate(-90deg); opacity: 1; }} }}
  .retorno-pie-animar svg {{ animation: retorno-pie-pop 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); transform-origin: center; }}
  .retorno-barras-wrap {{ display: flex; flex-direction: column; gap: 0.5rem; }}
  .retorno-barra-item {{ display: flex; flex-direction: column; gap: 0.2rem; }}
  .retorno-barra-cabeza {{ display: flex; justify-content: space-between; font-size: 0.82rem; }}
  .retorno-barra-cabeza b {{ font-weight: 700; }}
  .retorno-barra-track {{ height: 10px; border-radius: 999px; background: var(--accent-soft); overflow: hidden; }}
  .retorno-barra-fill {{ height: 100%; border-radius: 999px; width: 0%; transition: width 0.7s cubic-bezier(0.34, 1.56, 0.64, 1); }}
  .nse-gauge-wrap {{ display: flex; justify-content: center; margin: 0.2rem 0; }}
  .denue-stats {{ display: flex; gap: 1.5rem; }}
  .denue-stat {{ display: flex; flex-direction: column; gap: 0.15rem; }}
  .denue-num {{ font-size: 1.35rem; font-weight: 700; color: var(--text); }}
  details.audit {{
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 0.8rem 1rem; margin-top: 0.5rem; margin-bottom: 1rem;
  }}
  summary {{ cursor: pointer; font-size: 0.88rem; font-weight: 600; color: var(--accent); }}
  .mapa-toolbar {{ display: flex; align-items: center; justify-content: space-between; gap: 0.6rem; margin-top: 0.8rem; flex-wrap: wrap; }}
  .mapa-hint {{ font-size: 0.78rem; color: var(--text-muted); }}
  .mapa-toolbar-btns {{ display: flex; gap: 0.5rem; }}
  .mapa-centrar, .mapa-completa {{ font-size: 0.78rem; padding: 0.35rem 0.75rem; }}
  .mapa-wrap {{ display: flex; justify-content: center; margin-top: 0.6rem; }}
  .mapa-wrap svg {{ max-width: 100%; height: auto; display: block; border: 1px solid var(--border); border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); touch-action: none; user-select: none; --mapa-bg: #eef2f5; }}
  .mapa-marker:focus {{ outline: none; }}
  .mapa-marker:hover .mapa-marker-halo, .mapa-marker:focus .mapa-marker-halo {{ fill: rgba(63,111,176,0.22); }}
  .mapa-leyenda {{ display: flex; flex-wrap: wrap; gap: 0.9rem; justify-content: center; margin-top: 0.7rem; font-size: 0.8rem; color: var(--text-muted); }}
  .mapa-leg-item {{ display: inline-flex; align-items: center; gap: 0.35rem; }}
  .mapa-leg-titulo {{ font-weight: 600; color: var(--text); }}
  .mapa-leg-dot {{ width: 0.65rem; height: 0.65rem; border-radius: 50%; display: inline-block; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 0.75rem; font-size: 0.85rem; }}
  th, td {{ border: 1px solid var(--border); padding: 0.45rem 0.6rem; text-align: left; }}
  th {{ background: var(--bg); font-weight: 600; }}
  footer {{ margin-top: 2.5rem; color: var(--text-muted); font-size: 0.78rem; text-align: center; }}

  .guardados-box {{ margin-top: 0.7rem; font-size: 0.85rem; }}
  .guardados-box summary {{ cursor: pointer; color: var(--accent); font-weight: 600; }}
  .guardados-list {{ list-style: none; margin: 0.6rem 0; padding: 0; display: flex; flex-direction: column; gap: 0.35rem; }}
  .guardados-item {{ padding: 0.4rem 0.6rem; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; }}
  .guardados-item-linea {{ display: flex; align-items: center; gap: 0.6rem; }}
  .guardados-item a {{ color: var(--text); text-decoration: none; font-weight: 500; }}
  .guardados-item a:hover {{ color: var(--accent); }}
  .guardados-fecha {{ margin-left: auto; color: var(--text-muted); font-size: 0.75rem; }}
  .guardados-resumen {{ display: flex; gap: 0.9rem; margin-top: 0.3rem; flex-wrap: wrap; }}
  .guardados-resumen-item {{ font-size: 0.78rem; color: var(--text-muted); }}
  .guardados-del {{ color: var(--error) !important; font-weight: 700 !important; padding: 0 0.2rem; }}
  .guardar-form {{ display: flex; gap: 0.5rem; margin-top: 0.5rem; flex-wrap: wrap; }}
  .guardar-form input[type="text"] {{ flex: 1; min-width: 180px; padding: 0.4rem 0.6rem; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); color: var(--text); }}
  .guardar-form button {{ font-size: 0.82rem; padding: 0.4rem 0.8rem; }}

  @media (prefers-color-scheme: dark) {{
    :root {{
      --bg: #16181d; --surface: #1f2229; --border: #2c303a; --text: #e7e9ec;
      --text-muted: #9aa1ac; --accent: #6f97e6; --accent-soft: #232c40; --error: #f28b82;
    }}
    .bar-track {{ background: #2a2e37; }}
    .bar-row-inline.na .bar-track {{ background: repeating-linear-gradient(45deg, #2a2e37, #2a2e37 4px, #232630 4px, #232630 8px); }}
    .error {{ background: #3a2222; border-color: #5c3230; }}
    .mapa-wrap svg {{ --mapa-bg: #262a33; }}
  }}
"""
# Versión con llaves sin escapar, para reusar el mismo CSS en páginas que se arman con
# .replace() en vez de .format() (ver COMPARAR_PAGE_TEMPLATE) — con .format() las llaves de
# CSS necesitan escaparse ({{ }}), pero .replace() no las toca, así que aquí se revierte.
SHARED_STYLE_BLOCK_RAW = SHARED_STYLE_BLOCK.replace("{{", "{").replace("}}", "}")


PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI - Baja California</title>
<style>
""" + SHARED_STYLE_BLOCK + """</style>
</style>
</head>
<body>
<h1>Agente INEGI — Consulta de Zona</h1>
<p class="subtitle">Baja California · Censo 2020 · 100% local, sin conexión a internet</p>
<div class="combinar-nav"><a class="secondary-link" href="{comparar_href}">🔗 Combinar con otras zonas de flujo →</a><a class="secondary-link" href="/hospitales">🏥 Hospitales de Tijuana →</a><a class="secondary-link" href="/mercado-laboratorios">🧪 Mercado de Laboratorios →</a><a class="secondary-link" href="/mercado-empresas">🏭 Mercado de Empresas →</a><a class="secondary-link" href="/logout">🔒 Cerrar sesión</a></div>
<form class="search" method="get" action="/">
  {municipio_selector}
  {capa_selector}
  <input type="text" name="valor" placeholder="Colonia, código postal, clave AGEB o coordenadas (lat,lon)" value="{valor_escaped}">
  <input type="text" name="radio" placeholder="Radio km (opcional)" value="{radio_escaped}">
  <button type="submit">Buscar</button>
</form>
{guardados_html}
<p class="hint">Detecta automáticamente qué escribiste: nombre de colonia, código postal (5 dígitos), clave AGEB (4 caracteres, ej. 0435) o coordenadas "lat,lon" (ej. 32.5048,-116.9350). El radio (km) es opcional: si lo llenas, se agrega el censo de todos los AGEBs dentro de ese radio alrededor del centro de la zona (o del punto), en vez de solo la asignación por nombre / el AGEB exacto. Si eliges un municipio Y escribes algo, busca solo dentro de ese municipio; si eliges un municipio y dejas el campo vacío, muestra el resumen completo de esa ciudad.</p>
{resultado}
<footer>Fuente: INEGI — Marco Geoestadístico y Censo de Población y Vivienda 2020.</footer>
</body>
</html>
"""


def _donut_svg(segments: list[tuple[str, float, str]], size: int = 100, stroke: int = 14) -> str:
    """Dona SVG (stroke-dasharray sobre un círculo) — sin JS ni librerías externas."""
    total = sum(v for _, v, _ in segments)
    r = (size - stroke) / 2
    c = 2 * math.pi * r
    cx = cy = size / 2
    parts = [
        f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" '
        f'style="transform:rotate(-90deg);flex:none;">'
        f'<circle cx="{cx}" cy="{cy}" r="{r:.2f}" fill="none" stroke="#88888022" stroke-width="{stroke}"/>'
    ]
    if total > 0:
        offset = 0.0
        for _label, value, color in segments:
            frac = value / total
            dash = frac * c
            if dash > 0:
                parts.append(
                    f'<circle cx="{cx}" cy="{cy}" r="{r:.2f}" fill="none" stroke="{color}" '
                    f'stroke-width="{stroke}" stroke-dasharray="{dash:.2f} {max(c - dash, 0):.2f}" '
                    f'stroke-dashoffset="{-offset:.2f}"/>'
                )
            offset += dash
    parts.append("</svg>")
    return "".join(parts)


def _chart_panel(titulo: str, segments: list[tuple[str, float, str]], nota: str = "") -> str:
    total = sum(v for _, v, _ in segments)
    legend = []
    for label, value, color in segments:
        pct = round((value / total) * 100, 1) if total else 0.0
        legend.append(
            '<div class="legend-item">'
            f'<span class="legend-dot" style="background:{color};"></span>'
            f'<span>{html.escape(label)}</span>'
            f'<span class="legend-val">{pct}%</span>'
            "</div>"
        )
    nota_html = f'<p class="chart-note">{html.escape(nota)}</p>' if nota else ""
    return (
        f'<p class="donut-title">{html.escape(titulo)}</p>'
        '<div class="donut-row">'
        f"{_donut_svg(segments)}"
        f'<div class="legend">{"".join(legend)}</div>'
        "</div>"
        f"{nota_html}"
    )


def _grafico_categoria(categoria: str, totals: dict[str, float]) -> str:
    g = lambda v: max(totals.get(v, 0.0), 0.0)  # noqa: E731

    if categoria == "Vivienda":
        vivtot = g("vivtot")
        habitadas, deshabitadas = g("tvivparhab"), g("vivpar_des")
        otras = max(vivtot - habitadas - deshabitadas, 0.0)
        segments = [("Habitadas", habitadas, DONUT_PALETTE[0]), ("Deshabitadas", deshabitadas, DONUT_PALETTE[1])]
        if otras > 0:
            segments.append(("Otras / sin especificar", otras, DONUT_GRIS))
        return _chart_panel("Ocupación del total de viviendas", segments)

    if categoria == "Poblacion":
        sexo = [("Mujeres", g("pobfem"), DONUT_PALETTE[0]), ("Hombres", g("pobmas"), DONUT_PALETTE[1])]
        pobtot = g("pobtot")
        p_0a14, p_60mas = g("p_0a14"), g("p_60ymas")
        resto = max(pobtot - p_0a14 - p_60mas, 0.0)
        estimado = estimar_edades_15_59(totals)
        if estimado is not None:
            edad = [
                ("0-14 años", p_0a14, DONUT_PALETTE[2]),
                ("15-29 años (estimado)", estimado["p_15a29_est"], "#5b8fd1"),
                ("30-59 años (estimado)", estimado["p_30a59_est"], "#c98f3a"),
                ("60+ años", p_60mas, DONUT_PALETTE[3]),
            ]
            nota_edad = (
                "15-29 y 30-59 son un ESTIMADO (prorrateo del grupo 15-59 real de esta zona "
                "usando la proporción municipal configurada) — no es dato oficial de INEGI a nivel AGEB."
            )
        else:
            edad = [
                ("0-14 años", p_0a14, DONUT_PALETTE[2]),
                ("60+ años", p_60mas, DONUT_PALETTE[3]),
                ("15-59 años (no publicado)", resto, DONUT_GRIS),
            ]
            nota_edad = "INEGI no publica el desglose 15-29 / 30-59 a nivel AGEB; solo existe agregado en '15-59'."
        return (
            _chart_panel("Población por sexo", sexo)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Población por edad", edad, nota=nota_edad)
        )

    if categoria == "Educacion_Socioeconomico":
        vivtot = g("vivtot") or 1.0
        pobtot = g("pobtot") or 1.0
        segments = [
            ("Con internet", g("vph_inter"), DONUT_PALETTE[0]),
            ("Sin internet", max(vivtot - g("vph_inter"), 0.0), DONUT_GRIS),
        ]
        segments2 = [
            ("Con vehículo", g("vph_autom"), DONUT_PALETTE[1]),
            ("Sin vehículo", max(vivtot - g("vph_autom"), 0.0), DONUT_GRIS),
        ]
        segments3 = [
            ("Sin escolaridad (15+)", g("p15ym_se"), DONUT_PALETTE[3]),
            ("Resto de la población", max(pobtot - g("p15ym_se"), 0.0), DONUT_GRIS),
        ]
        return (
            _chart_panel("Viviendas con internet", segments)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Viviendas con vehículo", segments2)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Población sin escolaridad (15+)", segments3)
        )

    if categoria == "Salud":
        pobtot = g("pobtot")
        cobertura = [
            ("Con cobertura de salud", g("pder_ss"), DONUT_PALETTE[0]),
            ("Sin cobertura", g("psinder"), DONUT_PALETTE[1]),
        ]
        pder_ss = g("pder_ss") or 1.0
        imss, iste, segpub = g("pder_imss"), g("pder_iste"), g("pder_segpub")
        otro = max(pder_ss - imss - iste - segpub, 0.0)
        tipo = [
            ("IMSS", imss, DONUT_PALETTE[0]),
            ("ISSSTE", iste, DONUT_PALETTE[1]),
            ("Seguro público/privado", segpub, DONUT_PALETTE[2]),
        ]
        if otro > 0:
            tipo.append(("Otro / no especificado", otro, DONUT_GRIS))
        return (
            _chart_panel("Cobertura de salud", cobertura)
            + "<hr style='border:none;border-top:1px solid var(--border);margin:0.7rem 0;'>"
            + _chart_panel("Tipo de cobertura (de la población con cobertura)", tipo)
        )

    return ""


def _bar_chart(variables: list[str], totals: dict[str, float], color: str) -> str:
    """Mini gráfico de barras horizontales en HTML/CSS puro, escalado al valor máximo
    del propio segmento. Las variables no publicadas por INEGI a nivel AGEB se marcan
    aparte (barra rayada, sin valor) en vez de mostrar un 0 engañoso."""
    disponibles = [v for v in variables if v not in VARIABLES_NO_DISPONIBLES_AGEB]
    valores = {v: max(totals.get(v, 0.0), 0.0) for v in disponibles}
    maximo = max(valores.values(), default=0.0) or 1.0
    estimado = estimar_edades_15_59(totals) if any(v in VARIABLES_NO_DISPONIBLES_AGEB for v in variables) else None

    filas = []
    for var in variables:
        etiqueta = html.escape(VARIABLE_LABELS[var])
        if var in VARIABLES_NO_DISPONIBLES_AGEB:
            if estimado is not None:
                val_est = estimado[f"{var}_est"]
                filas.append(
                    '<div class="bar-row-inline na">'
                    '<div class="bar-top">'
                    f'<span class="bar-label">{etiqueta}</span>'
                    f'<span class="bar-value">≈ {val_est:,.0f} (estimado)</span>'
                    "</div>"
                    '<span class="bar-track"><span class="bar-fill" style="width:100%;"></span></span>'
                    "</div>"
                )
            else:
                filas.append(
                    '<div class="bar-row-inline na">'
                    '<div class="bar-top">'
                    f'<span class="bar-label">{etiqueta}</span>'
                    '<span class="bar-value">No publicado por INEGI a nivel AGEB</span>'
                    "</div>"
                    '<span class="bar-track"><span class="bar-fill" style="width:100%;"></span></span>'
                    "</div>"
                )
            continue
        val = valores[var]
        pct = round((val / maximo) * 100, 1)
        valor_fmt = f"{val:,.0f}"
        filas.append(
            '<div class="bar-row-inline">'
            '<div class="bar-top">'
            f'<span class="bar-label">{etiqueta}</span>'
            f'<span class="bar-value" style="color:{color};">{valor_fmt}</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct}%;background:{color};"></span></span>'
            "</div>"
        )
    return "".join(filas)


# Rampa verde -> amarillo -> naranja -> rojo (matices claramente distintos, no solo más
# oscuro/más claro del mismo tono) — con solo variar la luminosidad (como antes: dos verdes y
# dos rojos) los niveles intermedios se confunden a simple vista en el mapa, sobre todo en
# polígonos chicos o con transparencia.
NSE_COLOR = {"Alto": "#1a7a4c", "Medio": "#f2c94c", "Bajo": "#e67e22", "Muy bajo": "#c0392b", "Sin referencia": "#6b7280"}


def leyenda_mapa_nse(
    n_incluidos: int, n_excluidos: int, radio_km: float | None, color_radio: str,
    capa_etiqueta: str = "NSE", paleta: dict[str, str] | None = None,
) -> str:
    """Leyenda para el mapa de calor por AGEB (ver server.py, donde se arma colores_por_ageb)
    — un swatch por nivel de la capa activa (NSE por defecto, o marginación/densidad/
    carencias según el selector), en vez de uno solo "zona consultada", porque ahora la zona
    puede traer varios colores distintos a la vez."""
    paleta = paleta or NSE_COLOR
    # El nombre de la capa va UNA vez como título, no repetido en cada swatch — con nombres
    # largos ("Marginación urbana (CONAPO, oficial)") repetirlo 5 veces se ve saturado y no
    # deja distinguir a simple vista qué swatch es cuál.
    items = [f'<span class="mapa-leg-titulo">{html.escape(capa_etiqueta)}:</span>']
    for nivel in paleta:
        if nivel == "Sin referencia":
            continue
        items.append(
            f'<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:{paleta[nivel]};"></span>'
            f"{html.escape(nivel)}</span>"
        )
    items.append(f'<span class="mapa-leg-item">({n_incluidos} AGEBs consultados)</span>')
    if n_excluidos:
        items.append(
            '<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:#c7cbd1;"></span>'
            f"Resto de Baja California ({n_excluidos} AGEBs)</span>"
        )
    items.append(
        '<span class="mapa-leg-item"><span class="mapa-leg-dot" style="background:#c0392b;"></span>'
        "Centro de búsqueda</span>"
    )
    if radio_km:
        items.append(
            '<span class="mapa-leg-item"><span class="mapa-leg-dot" '
            f'style="background:transparent;border:1.5px dashed {color_radio};"></span>'
            f"Radio de {html.escape(str(radio_km))} km</span>"
        )
    return "".join(items)


def _nse_gauge_svg(indice: float, p25: float | None, p50: float | None, p75: float | None, color: str) -> str:
    """Medidor semicircular (0-100): la aguja marca el índice de la zona y tres franjas de
    color de fondo marcan en qué cuartil cae respecto a Baja California (Muy bajo/Bajo/Medio
    /Alto) — más fácil de leer de un vistazo que la barra lineal sola."""
    cx, cy, r = 90, 85, 74

    def punto(valor: float) -> tuple[float, float]:
        # 0 -> 180° (izquierda), 100 -> 0° (derecha), semicírculo superior.
        ang = math.pi * (1 - valor / 100)
        return cx + r * math.cos(ang), cy - r * math.sin(ang)

    def arco(v0: float, v1: float, color_franja: str) -> str:
        x0, y0 = punto(v0)
        x1, y1 = punto(v1)
        return f'<path d="M {x0:.1f} {y0:.1f} A {r} {r} 0 0 1 {x1:.1f} {y1:.1f}" fill="none" stroke="{color_franja}" stroke-width="14"/>'

    cortes = [0.0, p25 or 25.0, p50 or 50.0, p75 or 75.0, 100.0]
    colores_franja = [NSE_COLOR["Muy bajo"], NSE_COLOR["Bajo"], NSE_COLOR["Medio"], NSE_COLOR["Alto"]]
    franjas = "".join(arco(cortes[i], cortes[i + 1], colores_franja[i]) for i in range(4))

    ang_aguja = math.pi * (1 - max(0.0, min(100.0, indice)) / 100)
    ax, ay = cx + (r - 10) * math.cos(ang_aguja), cy - (r - 10) * math.sin(ang_aguja)
    aguja = (
        f'<line x1="{cx}" y1="{cy}" x2="{ax:.1f}" y2="{ay:.1f}" stroke="{color}" stroke-width="3" '
        'stroke-linecap="round"/>'
        f'<circle cx="{cx}" cy="{cy}" r="5" fill="{color}"/>'
    )
    etiqueta = f"{indice:.0f}"
    # "Píldora" blanca detrás del número, separada del semicírculo (que termina en cy=85):
    # sin esto, el texto se encima con el arco/la aguja, que llegan justo hasta esa altura.
    ancho_pildora = max(38, 15 + 13 * len(etiqueta))
    pildora_y, pildora_h = 92, 26
    return (
        f'<svg viewBox="0 0 180 {pildora_y + pildora_h + 4}" width="180" height="{pildora_y + pildora_h + 4}" '
        f'role="img" aria-label="Medidor de nivel socioeconómico: {indice:.0f} de 100">{franjas}{aguja}'
        f'<rect x="{cx - ancho_pildora / 2:.1f}" y="{pildora_y}" width="{ancho_pildora}" height="{pildora_h}" '
        f'rx="{pildora_h / 2}" fill="var(--surface, #fff)" stroke="var(--border, #e2e5ea)"/>'
        f'<text x="{cx}" y="{pildora_y + pildora_h - 7}" text-anchor="middle" font-size="20" '
        f'font-weight="700" fill="{color}">{etiqueta}</text>'
        "</svg>"
    )


def _nse_html(totals: dict[str, float]) -> str:
    """Sección "Nivel socioeconómico". Usa el mismo índice/cálculo que _poder_adquisitivo_html
    (no hay una fuente distinta de ingreso real por AGEB — ver estimar_nivel_socioeconomico),
    pero se muestran como DOS secciones separadas del reporte a propósito, no fusionadas."""
    return _indice_socioeconomico_html(
        totals,
        titulo="Nivel socioeconómico (índice estimado, no oficial)",
        nota_extra="No es la clasificación oficial de NSE de AMAI/INEGI ni un dato de DataMéxico.",
    )


def _poder_adquisitivo_html(totals: dict[str, float]) -> str:
    """Sección "Poder adquisitivo estimado" — ver _nse_html: mismo cálculo, sección aparte."""
    return _indice_socioeconomico_html(
        totals,
        titulo="Poder adquisitivo estimado (proxy, no oficial)",
        nota_extra=(
            "INEGI no publica ingreso/poder adquisitivo real a nivel AGEB o colonia (el Censo no "
            "pregunta ingresos, solo existe agregado en la ENIGH a nivel estatal) — este índice es "
            "el proxy más cercano calculable 100% offline con los datos ya cargados, NO un dato real "
            "de ingreso en pesos."
        ),
    )


def _indice_socioeconomico_html(totals: dict[str, float], titulo: str, nota_extra: str) -> str:
    nse = estimar_nivel_socioeconomico(totals)
    if nse is None:
        return ""
    color = NSE_COLOR.get(nse["nivel"], "#6b7280")
    referencia = (
        f' Comparado contra Baja California completa: p25={nse["p25"]}, p50={nse["p50"]}, p75={nse["p75"]}.'
        if nse["p25"] is not None else ""
    )
    gauge = _nse_gauge_svg(nse["indice"], nse["p25"], nse["p50"], nse["p75"], color)
    return (
        '<div class="nse-box">'
        '<div class="nse-top">'
        f'<span class="bar-label">{html.escape(titulo)}</span>'
        f'<span class="nse-badge" style="background:{color}22;color:{color};">{html.escape(nse["nivel"])}</span>'
        "</div>"
        f'<div class="nse-gauge-wrap">{gauge}</div>'
        f'<span class="bar-track"><span class="bar-fill" style="width:{nse["indice"]}%;background:{color};"></span></span>'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        f'<p class="nse-note">Índice compuesto (0-100) propio ({nse["indice"]}), calculado localmente a partir de '
        "piso firme, drenaje, electricidad, internet, automóvil y escolaridad. La etiqueta (Alto/Medio/Bajo/Muy "
        "bajo) es POR PERCENTIL relativo a los AGEBs de Baja California (cuartiles), no un umbral absoluto — así "
        '"Alto" siempre significa "el 25% mejor posicionado del estado en este índice", nunca un estándar fijo '
        f"inventado.{{ref}} {html.escape(nota_extra)}</p>"
        "</details>"
        "</div>"
    ).replace("{ref}", referencia)


# Misma rampa de 4 tonos que NSE_COLOR + un quinto escalón (Muy alto) claramente más oscuro
# que "Alto" pero del mismo tono rojo — para que a simple vista se lea como "todavía peor",
# no como un color distinto sin relación.
MARGINACION_COLOR = {
    "Muy bajo": "#1a7a4c", "Bajo": "#8bc34a", "Medio": "#f2c94c",
    "Alto": "#e67e22", "Muy alto": "#8b1a1a",
}


def _marginacion_html(agebs: list[dict]) -> str:
    marg = obtener_marginacion([a["cve_geo"] for a in agebs])
    if marg is None:
        return ""
    color = MARGINACION_COLOR.get(marg["grado_predominante"], "#6b7280")
    desglose = ", ".join(
        f"{n} {html.escape(g)}" for g, n in sorted(marg["conteo_grados"].items(), key=lambda kv: -kv[1])
    )
    cobertura = ""
    if marg["n_agebs_con_dato"] < marg["n_agebs_total"]:
        cobertura = f' ({marg["n_agebs_con_dato"]} de {marg["n_agebs_total"]} AGEBs con dato disponible)'
    return (
        '<div class="nse-box">'
        '<div class="nse-top">'
        '<span class="bar-label">Marginación urbana (CONAPO, índice OFICIAL)</span>'
        f'<span class="nse-badge" style="background:{color}22;color:{color};">{html.escape(marg["grado_predominante"])}</span>'
        "</div>"
        f'<span class="bar-track"><span class="bar-fill" style="width:{marg["indice_normalizado_pct"]}%;background:{color};"></span></span>'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        f'<p class="nse-note">Grado de marginación urbana predominante: {desglose}{cobertura}. Barra = índice '
        "normalizado promedio ponderado por población (más alto = MENOS marginación / mejor nivel). Fuente: "
        "Índice de Marginación Urbana por AGEB 2020, CONAPO (Consejo Nacional de Población) — dato oficial de "
        "gobierno, no un proxy.</p>"
        "</details>"
        "</div>"
    )


DENUE_CATEGORIA_COLOR = {
    "Farmacias": "#2f6f4f",
    "Hospitales": "#7a2c3f",
    "Clínicas (consultorios médicos agrupados)": "#9a3b52",
    "Consultorios médicos (general y especializada)": "#b0546b",
    "Consultorios dentales": "#c66f83",
    "Laboratorios clínicos / de análisis": "#6f5a9a",
    "Laboratorios de imagen (radiología/imagenología)": "#8a76b5",
    "Otros consultorios y servicios de salud": "#c98f3a",
    "Asistencia social (guarderías, asilos, orientación, etc.)": "#8a8f98",
    "Otros servicios de salud": "#8a8f98",
}


def _denue_html(agebs: list[dict]) -> str:
    conteo = contar_unidades_salud([a["cve_geo"] for a in agebs])
    if conteo is None or conteo["unidades_salud"] == 0:
        return ""

    cve_geos = [a["cve_geo"] for a in agebs]
    desglose = conteo["desglose"]
    maximo = max(desglose.values(), default=0) or 1
    filas = []
    modales = []
    for idx, cat in enumerate(ORDEN_CATEGORIAS_DENUE):
        n = desglose.get(cat)
        if not n:
            continue
        color = DENUE_CATEGORIA_COLOR.get(cat, "#8a8f98")
        pct = round((n / maximo) * 100, 1)
        modal_id = f"denue-modal-{idx}"
        # Fila clicable que ABRE UN MODAL a pantalla completa (no un cajón chiquito inline) —
        # con cientos de establecimientos en categorías grandes (farmacias, laboratorios), un
        # panel de 220px se siente incompleto aunque tenga scroll con todo el listado.
        filas.append(
            f'<div class="bar-row-inline denue-cat-row" data-modal-target="{modal_id}" tabindex="0" role="button" '
            f'aria-label="Ver listado de {html.escape(cat)}">'
            '<div class="bar-top">'
            f'<span class="bar-label">{html.escape(cat)} ▸</span>'
            f'<span class="bar-value" style="color:{color};">{n:,}</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct}%;background:{color};"></span></span>'
            "</div>"
        )
        modales.append(_denue_modal_html(modal_id, cat, n, cve_geos))

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{conteo["unidades_salud"]:,}</span>'
        '<span class="bar-label">Unidades de salud (total: sector SCIAN 62 + farmacias)</span>'
        "</div>"
        "</div>"
        f'<div style="margin-top:0.7rem;">{"".join(filas)}</div>'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note">Establecimientos activos del DENUE (INEGI), geocodificados por INEGI directamente a '
        "su AGEB. Farmacias = SCIAN 4641 (sector Comercio); el resto = sector Servicios de Salud y Asistencia "
        "Social (SCIAN 62, por eso incluye guarderías/asilos/orientación además de clínicas). El corte entre "
        '"Laboratorios clínicos" y "de imagen" es una aproximación por palabras clave en el nombre del '
        "establecimiento (SCIAN no los distingue en una sola clase) — puede haber errores de clasificación "
        "puntuales. Clic en una categoría para ver el listado completo.</p>"
        "</details>"
        "</div>"
        f'{"".join(modales)}'
    )


COMERCIOS_COLOR = {
    "Calimax": "#2f6f4f",
    "CaliExpress": "#4f8f6f",
    "Comex": "#b0546b",
    "Truper": "#6f5a9a",
    "Aprecio": "#3a7ca8",
    "Coppel": "#c9973a",
    "Elektra": "#c9433a",
    "Mercados El Florido": "#7a9a3a",
}


def _retorno_html(totals: dict[str, float]) -> str:
    """"Valor de la zona": a partir de la población de la zona analizada (censo) y de la tabla
    de frecuencias de regreso propia del negocio del usuario (no son datos del censo) — suma
    las órdenes anuales estimadas de TODAS las frecuencias marcadas en el checklist (por
    default las 5), y por separado calcula representación de mercado / mercado sin atender a
    partir de los "pacientes actuales" que el usuario capture. Siempre a 1 año (12 meses) y
    sobre días hábiles reales (lunes a sábado, 6/7) — no son configurables porque el usuario
    pidió fijarlos así para que el cálculo sea consistente entre consultas.

    Todo el cálculo corre en el navegador (JS, ver RETORNO_CLIENTES_SCRIPT) — se recalcula al
    instante mientras el usuario marca/desmarca frecuencias o cambia pacientes actuales."""
    poblacion_total = totals.get("pobtot") or 0
    if not poblacion_total:
        return ""
    # INEGI no publica el corte exacto en 20 años a nivel AGEB (solo 0-14, 15-29, 30-59, 60+,
    # y los dos de en medio ya vienen estimados por prorrateo estatal — ver
    # VARIABLES_NO_DISPONIBLES_AGEB) — "15+" (población total menos 0-14) es la aproximación
    # más cercana disponible al mercado real 20-60+ que pidió el usuario.
    poblacion_15mas = poblacion_total - (totals.get("p_0a14") or 0)

    checklist = []
    formulas = []
    for id_, etiqueta, tasa, mult, directo, color in RETORNO_FRECUENCIAS:
        if directo:
            data_attrs = f'data-directo="{tasa}"'
            formulas.append(f"<p><code>{etiqueta} = 30.50% × 50% (población que se enferma) × 30% (penalización) = {tasa}%</code></p>")
        else:
            acumulado = tasa * mult
            data_attrs = f'data-tasa="{tasa}" data-mult="{mult}"'
            formulas.append(f"<p><code>{etiqueta} = {tasa}% × {mult} = {acumulado:.2f}%</code></p>")
        checklist.append(
            f'<label class="retorno-freq-item"><input type="checkbox" class="retorno-freq" {data_attrs} '
            f'data-label="{html.escape(etiqueta)}" data-color="{color}" checked> '
            f"{html.escape(etiqueta)} <span class=\"retorno-freq-pct\">"
            f'({tasa}%{"" if directo else f" × {mult}"})</span></label>'
        )

    return (
        '<div class="nse-box retorno-box" data-poblacion-total="' + f"{poblacion_total:.4f}"
        + '" data-poblacion-15mas="' + f"{poblacion_15mas:.4f}" + '">'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note" style="margin:0 0 0.6rem;">A partir de la población de la zona analizada (censo) '
        "y tu propia tabla de frecuencias de regreso (no son datos del censo) — desmarca las que no apliquen "
        "a tu negocio. Cálculo siempre a 1 año, sobre días hábiles reales (lunes a sábado).</p>"
        "</details>"
        '<div class="retorno-inputs">'
        '<label>Población base<select class="retorno-base-poblacion">'
        '<option value="total" selected>Población total</option>'
        '<option value="15mas">15+ años (aprox. mercado 20-60+)</option>'
        "</select></label>"
        '<label>Pacientes actuales tuyos en la zona<input type="text" class="retorno-pacientes" value="0"></label>'
        "</div>"
        '<div class="retorno-freq-list">' + "".join(checklist) + "</div>"
        '<div class="retorno-resultado">'
        f'<div><span class="retorno-num retorno-poblacion">{poblacion_total:,.0f}</span><span class="bar-label">Población base (zona analizada)</span></div>'
        '<div><span class="retorno-num retorno-tasa-acumulada">—</span><span class="bar-label">Tasa acumulada (suma de frecuencias marcadas)</span></div>'
        '<div><span class="retorno-num retorno-clientes">—</span><span class="bar-label">Órdenes estimadas al año</span></div>'
        '<div><span class="retorno-num retorno-ordenes-dia">—</span><span class="bar-label">Órdenes por día hábil (año de 313 días hábiles)</span></div>'
        "</div>"
        '<div class="retorno-visuales">'
        '<div class="retorno-pie-row">'
        '<div class="retorno-pie-wrap"><div class="retorno-pie-holder">'
        '<div class="retorno-pie"></div><div class="retorno-pie-centro"><span class="retorno-pie-centro-num"></span>'
        '<span class="retorno-pie-centro-label">de mercado</span></div></div>'
        '<p class="donut-title">Representación de mercado</p></div>'
        '<div class="legend retorno-pie-legend"></div>'
        "</div>"
        '<div class="retorno-barras-wrap">'
        '<p class="donut-title">Órdenes al año por frecuencia</p>'
        '<div class="retorno-barras"></div>'
        "</div>"
        "</div>"
        '<details class="chart-toggle" style="margin-top:0.6rem;"><summary>Ver fórmulas</summary>'
        '<div class="chart-panel retorno-formulas">'
        f"{''.join(formulas)}"
        "<p><code>Tasa acumulada = suma de (tasa × multiplicador) de cada frecuencia marcada</code></p>"
        "<p><code>Órdenes estimadas al año = Población base × Tasa acumulada</code> — son ÓRDENES, no pacientes "
        "distintos (un mismo cliente que regresa 12 veces genera 12 órdenes, no cuenta como 12 pacientes)</p>"
        "<p><code>Órdenes por día hábil = Órdenes estimadas al año ÷ 313 días hábiles al año (52 semanas × 6 días, "
        "lunes a sábado)</code></p>"
        "<p><code>Representación de mercado = Pacientes actuales ÷ Población base × 100</code></p>"
        "<p><code>Pacientes no tratados por nosotros = Población base − Pacientes actuales</code></p>"
        "</div></details>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note" style="margin-top:0.6rem;">Las frecuencias vienen de tu propia tabla de retorno de '
        'negocio, no del censo — desmarca las que no quieras incluir en el total. "15+ años" es población total '
        "menos 0-14 años — INEGI no publica el corte exacto en 20 años a nivel AGEB (solo "
        '0-14/15-29/30-59/60+), es la aproximación más cercana disponible al mercado 20-60+.</p>'
        "</details>"
        "</div>"
    )


RETORNO_CLIENTES_SCRIPT = """
<script>
(function () {
  // Dona SVG vía stroke-dasharray, mismo truco que _donut_svg del lado del servidor pero en
  // JS porque estos dos valores (representación de mercado / no tratados) se calculan en el
  // navegador a partir de inputs del usuario, no del censo.
  function donutSvg(segments, size, stroke) {
    size = size || 110; stroke = stroke || 16;
    var r = (size - stroke) / 2, c = 2 * Math.PI * r, cx = size / 2, cy = size / 2;
    var total = segments.reduce(function (s, seg) { return s + seg.value; }, 0);
    var html = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size +
      '" style="transform:rotate(-90deg);flex:none;">' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + r.toFixed(2) + '" fill="none" stroke="#88888022" stroke-width="' + stroke + '"/>';
    var offset = 0;
    if (total > 0) {
      segments.forEach(function (seg) {
        var frac = seg.value / total, dash = frac * c;
        if (dash > 0) {
          html += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r.toFixed(2) + '" fill="none" stroke="' + seg.color +
            '" stroke-width="' + stroke + '" stroke-dasharray="' + dash.toFixed(2) + ' ' + Math.max(c - dash, 0).toFixed(2) +
            '" stroke-dashoffset="' + (-offset).toFixed(2) + '"/>';
          offset += dash;
        }
      });
    }
    return html + '</svg>';
  }

  var DIAS_HABILES_ANIO = 313; // 52 semanas x 6 días (lunes a sábado), fijo — no configurable

  function recalcular(box) {
    var baseSel = box.querySelector('.retorno-base-poblacion').value;
    var attr = baseSel === 'total' ? 'data-poblacion-total' : 'data-poblacion-15mas';
    var poblacion = parseFloat(box.getAttribute(attr)) || 0;
    var pacientes = parseFloat(box.querySelector('.retorno-pacientes').value.replace(',', '.'));
    if (isNaN(pacientes) || pacientes < 0) pacientes = 0;

    // Tasa acumulada = suma de (tasa x multiplicador) de cada frecuencia marcada en el
    // checklist — por default las 5 vienen marcadas (igual al total de tu tabla de Excel);
    // desmarcar una la saca de la suma.
    var tasaAcumulada = 0;
    box.querySelectorAll('.retorno-freq:checked').forEach(function (chk) {
      var directo = chk.getAttribute('data-directo');
      if (directo !== null) {
        tasaAcumulada += parseFloat(directo);
      } else {
        var tasa = parseFloat(chk.getAttribute('data-tasa'));
        var mult = parseFloat(chk.getAttribute('data-mult'));
        tasaAcumulada += tasa * mult;
      }
    });

    var ordenesAnio = poblacion * (tasaAcumulada / 100);
    var ordenesDia = ordenesAnio / DIAS_HABILES_ANIO;
    var representacion = poblacion > 0 ? Math.min((pacientes / poblacion) * 100, 100) : 0;
    var noTratados = Math.max(poblacion - pacientes, 0);

    box.querySelector('.retorno-poblacion').textContent = poblacion.toLocaleString('es-MX', { maximumFractionDigits: 0 });
    box.querySelector('.retorno-tasa-acumulada').textContent = tasaAcumulada.toLocaleString('es-MX', { maximumFractionDigits: 2 }) + '%';
    box.querySelector('.retorno-clientes').textContent = ordenesAnio.toLocaleString('es-MX', { maximumFractionDigits: 0 });
    box.querySelector('.retorno-ordenes-dia').textContent = ordenesDia.toLocaleString('es-MX', { maximumFractionDigits: 1 });

    var segments = [
      { label: 'Pacientes actuales (' + representacion.toFixed(1) + '%)', value: pacientes, color: '#2f9e6f' },
      { label: 'No tratados por nosotros (' + (100 - representacion).toFixed(1) + '%)', value: noTratados, color: '#8f97a3' },
    ];
    var pieEl = box.querySelector('.retorno-pie');
    pieEl.innerHTML = donutSvg(segments, 190, 26);
    // Animación: la dona entra creciendo/apareciendo cada vez que cambia un valor — reinicia
    // la animación quitando y re-agregando la clase (si no, CSS no la vuelve a disparar).
    pieEl.classList.remove('retorno-pie-animar');
    void pieEl.offsetWidth;
    pieEl.classList.add('retorno-pie-animar');
    box.querySelector('.retorno-pie-centro-num').textContent = representacion.toFixed(1) + '%';
    var legend = box.querySelector('.retorno-pie-legend');
    legend.innerHTML = segments.map(function (seg) {
      return '<div class="legend-item"><span class="legend-dot" style="background:' + seg.color + ';"></span>' +
        '<span>' + seg.label + '</span><span class="legend-val">' + Math.round(seg.value).toLocaleString('es-MX') + '</span></div>';
    }).join('');

    // Segundo gráfico: barras con las órdenes anuales que aporta CADA frecuencia marcada —
    // para ver de un vistazo cuál frecuencia pesa más en el total, no solo el número global.
    var barras = [];
    box.querySelectorAll('.retorno-freq:checked').forEach(function (chk) {
      var directo = chk.getAttribute('data-directo');
      var tasaChk = directo !== null ? parseFloat(directo) : parseFloat(chk.getAttribute('data-tasa')) * parseFloat(chk.getAttribute('data-mult'));
      barras.push({
        label: chk.getAttribute('data-label'),
        color: chk.getAttribute('data-color'),
        ordenes: poblacion * (tasaChk / 100),
      });
    });
    var maxOrdenes = Math.max.apply(null, barras.map(function (b) { return b.ordenes; }).concat([1]));
    var barrasWrap = box.querySelector('.retorno-barras');
    barrasWrap.innerHTML = barras.map(function (b) {
      return '<div class="retorno-barra-item">' +
        '<div class="retorno-barra-cabeza"><span>' + b.label + '</span><b>' + Math.round(b.ordenes).toLocaleString('es-MX') + '</b></div>' +
        '<div class="retorno-barra-track"><div class="retorno-barra-fill" style="background:' + b.color + ';"></div></div>' +
        "</div>";
    }).join('');
    // El ancho se pone DESPUÉS de insertar el HTML (arranca en 0% por CSS) para que la
    // transición de "width" sí se dispare — si se pone de una vez en el innerHTML no anima.
    requestAnimationFrame(function () {
      var fills = barrasWrap.querySelectorAll('.retorno-barra-fill');
      barras.forEach(function (b, i) {
        fills[i].style.width = ((b.ordenes / maxOrdenes) * 100) + '%';
      });
    });
  }

  document.querySelectorAll('.retorno-box').forEach(function (box) {
    recalcular(box);
    box.querySelectorAll('input').forEach(function (input) {
      input.addEventListener('input', function () { recalcular(box); });
      input.addEventListener('change', function () { recalcular(box); });
    });
    box.querySelector('.retorno-base-poblacion').addEventListener('change', function () { recalcular(box); });
  });

  // Al guardar un análisis en /comparar, se captura un snapshot de texto de "Valor de la
  // zona" (población + representación de mercado / órdenes anuales) justo antes de enviar el
  // formulario — este cálculo depende de inputs manuales que la query string guardada no
  // trae, así que sin esto la lista de guardados no mostraría nada útil de un vistazo.
  var guardarForm = document.querySelector('.guardar-form');
  var retornoBox = document.querySelector('.retorno-box');
  if (guardarForm && retornoBox) {
    var campoPoblacion = guardarForm.querySelector('.guardar-resumen-poblacion');
    var campoValor = guardarForm.querySelector('.guardar-resumen-valor');
    guardarForm.addEventListener('submit', function () {
      if (campoPoblacion) {
        campoPoblacion.value = retornoBox.querySelector('.retorno-poblacion').textContent + ' habitantes';
      }
      if (campoValor) {
        var pct = retornoBox.querySelector('.retorno-pie-centro-num').textContent;
        var ordenes = retornoBox.querySelector('.retorno-clientes').textContent;
        campoValor.value = ordenes + ' órdenes/año · ' + pct + ' de mercado';
      }
    });
  }
})();
</script>
"""


def _comercios_html(agebs: list[dict]) -> str:
    """Comercios de referencia (cadenas configuradas por el usuario, ej. Calimax/Comex/Truper)
    como proxy de perfil de consumidor en la zona — mismo patrón de tarjeta + modal que
    _denue_html, pero con una lista de marcas fija en vez de categorías SCIAN."""
    conteo = contar_comercios_referencia([a["cve_geo"] for a in agebs])
    if conteo is None or conteo["total"] == 0:
        return ""

    cve_geos = [a["cve_geo"] for a in agebs]
    desglose = conteo["desglose"]
    maximo = max(desglose.values(), default=0) or 1
    filas = []
    modales = []
    for idx, marca in enumerate(sorted(desglose, key=lambda m: -desglose[m])):
        n = desglose[marca]
        color = COMERCIOS_COLOR.get(marca, "#8a8f98")
        pct = round((n / maximo) * 100, 1)
        modal_id = f"comercio-modal-{idx}"
        filas.append(
            f'<div class="bar-row-inline denue-cat-row" data-modal-target="{modal_id}" tabindex="0" role="button" '
            f'aria-label="Ver listado de {html.escape(marca)}">'
            '<div class="bar-top">'
            f'<span class="bar-label">{html.escape(marca)} ▸</span>'
            f'<span class="bar-value" style="color:{color};">{n:,}</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct}%;background:{color};"></span></span>'
            "</div>"
        )
        establecimientos = establecimientos_por_marca(cve_geos, marca)
        modales.append(_modal_listado_html(modal_id, marca, n, establecimientos))

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{conteo["total"]:,}</span>'
        '<span class="bar-label">Comercios de referencia (perfil de consumidor)</span>'
        "</div>"
        "</div>"
        f'<div style="margin-top:0.7rem;">{"".join(filas)}</div>'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note">Sucursales de cadenas comerciales configuradas manualmente (DENUE, INEGI, '
        "geocodificadas a su AGEB) — no es el comercio completo de la zona, solo las cadenas que se hayan "
        "cargado para comparar presencia formal entre zonas. Clic en una marca para ver las sucursales.</p>"
        "</details>"
        "</div>"
        f'{"".join(modales)}'
    )


DENUE_MODAL_SCRIPT = """
<script>
(function () {
  var modalAbierto = null;

  function abrir(id) {
    var modal = document.getElementById(id);
    if (!modal) return;
    modal.hidden = false;
    modalAbierto = modal;
    document.body.style.overflow = 'hidden';
    var cerrarBtn = modal.querySelector('.denue-modal-close-btn');
    if (cerrarBtn) cerrarBtn.focus();
  }

  function cerrar() {
    if (!modalAbierto) return;
    modalAbierto.hidden = true;
    modalAbierto = null;
    document.body.style.overflow = '';
  }

  document.querySelectorAll('.denue-cat-row').forEach(function (fila) {
    var abrirEsteModal = function () { abrir(fila.getAttribute('data-modal-target')); };
    fila.addEventListener('click', abrirEsteModal);
    fila.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); abrirEsteModal(); }
    });
  });

  document.querySelectorAll('[data-modal-close]').forEach(function (el) {
    el.addEventListener('click', cerrar);
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') cerrar();
  });

  // Re-aplica el color intercalado solo sobre las filas visibles (no por posición absoluta
  // en la tabla), para que la búsqueda no rompa el patrón al ocultar filas.
  function restriar(tbody) {
    var visibles = Array.prototype.filter.call(tbody.querySelectorAll('tr'), function (fila) {
      return fila.style.display !== 'none';
    });
    visibles.forEach(function (fila, i) {
      fila.classList.toggle('denue-fila-par', i % 2 === 1);
    });
    return visibles.length;
  }

  document.querySelectorAll('.denue-modal').forEach(function (modal) {
    var input = modal.querySelector('.denue-modal-search');
    var tbody = modal.querySelector('.denue-modal-tabla tbody');
    var vacio = modal.querySelector('.denue-modal-empty');
    var resultados = modal.querySelector('.denue-modal-resultados');
    var total = resultados ? parseInt(resultados.getAttribute('data-total'), 10) || 0 : 0;
    if (!tbody) return;
    restriar(tbody);
    if (!input) return;
    input.addEventListener('input', function () {
      var termino = input.value.trim().toLowerCase();
      Array.prototype.forEach.call(tbody.querySelectorAll('tr'), function (fila) {
        var texto = fila.textContent.toLowerCase();
        fila.style.display = termino === '' || texto.indexOf(termino) !== -1 ? '' : 'none';
      });
      var visiblesRestantes = restriar(tbody);
      if (vacio) vacio.style.display = visiblesRestantes === 0 ? 'block' : 'none';
      if (resultados) resultados.textContent = visiblesRestantes.toLocaleString('es-MX') + ' de ' + total.toLocaleString('es-MX') + ' resultados';
    });
  });
})();
</script>
"""


def _denue_modal_html(modal_id: str, categoria: str, total: int, cve_geos: list[str]) -> str:
    establecimientos = establecimientos_por_categoria(cve_geos, categoria)
    return _modal_listado_html(modal_id, categoria, total, establecimientos)


def _modal_listado_html(modal_id: str, titulo: str, total: int, establecimientos: list[dict]) -> str:
    filas_html = "".join(
        '<tr>'
        f'<td class="denue-modal-nombre">{html.escape(e["nombre"])}</td>'
        f'<td class="denue-modal-dir">{html.escape(e["direccion"]) if e["direccion"] else "—"}</td>'
        "</tr>"
        for e in establecimientos
    )
    return (
        f'<div id="{modal_id}" class="denue-modal" hidden>'
        '<div class="denue-modal-backdrop" data-modal-close></div>'
        '<div class="denue-modal-panel" role="dialog" aria-modal="true">'
        '<div class="denue-modal-header">'
        f'<h3>{html.escape(titulo)} <span class="denue-modal-count">({total:,})</span></h3>'
        '<button type="button" class="denue-modal-close-btn" data-modal-close aria-label="Cerrar">✕</button>'
        "</div>"
        '<div class="denue-modal-search-wrap">'
        '<input type="text" class="denue-modal-search" placeholder="Buscar por nombre o dirección…" '
        'aria-label="Buscar en el listado">'
        f'<p class="denue-modal-resultados" data-total="{total}">{total:,} de {total:,} resultados</p>'
        "</div>"
        '<div class="denue-modal-body">'
        f'<table class="denue-modal-tabla"><thead><tr><th>Nombre</th><th>Dirección aproximada</th></tr></thead>'
        f"<tbody>{filas_html}</tbody></table>"
        '<p class="denue-modal-empty">Sin resultados para esa búsqueda.</p>'
        "</div>"
        "</div>"
        "</div>"
    )


def _esep_html(agebs: list[dict]) -> str:
    rec = obtener_recursos_hospitalarios([a["cve_geo"] for a in agebs])
    if rec is None:
        return ""

    filas = []
    for campo, etiqueta in ETIQUETAS_ESEP.items():
        n = rec[campo]
        if n:
            filas.append(f"<li><strong>{n:,}</strong> {html.escape(etiqueta)}</li>")

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{rec["n_hospitales"]:,}</span>'
        '<span class="bar-label">Hospitales privados con equipamiento verificado (ESEP, INEGI)</span>'
        "</div>"
        "</div>"
        f'<ul style="margin:0.6rem 0 0; padding-left:1.1rem; font-size:0.82rem; columns:2; gap:1rem;">{"".join(filas)}</ul>'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note">Recursos materiales reportados directamente por los hospitales privados a INEGI '
        "(Estadística de Salud en Establecimientos Particulares, ESEP 2025) — dato real de capacidad instalada, no "
        "un conteo de negocios ni una aproximación por nombre. Solo cubre hospitales (no consultorios ni "
        "laboratorios independientes); si no aparece nada aquí, la zona no tiene un hospital privado encuestado.</p>"
        "</details>"
        "</div>"
    )


RADIO_HOSPITALES_CARDIO_KM = 5.0


def _hospitales_cardio_html(agebs: list[dict]) -> str:
    """Hospitales privados de Tijuana con capacidad cardiovascular/quirúrgica (nivel II/III,
    quirófanos, camas) CERCANOS a la zona analizada — a diferencia de _esep_html, esta fuente
    no viene geocodificada a AGEB, pero sí trae coordenadas reales por hospital (ver
    etl_local.py:load_hospitales_cardio), así que se puede filtrar por distancia real desde el
    centro de masa de los AGEBs consultados en vez de listar los 20 de toda la ciudad — el
    usuario pidió explícitamente que solo aparezcan los cercanos a la zona que se investiga.
    La distancia en sí la calcula hospitales_cardio_cercanos() (query_engine_local.py), para
    que el Excel exportado use exactamente el mismo criterio de "cercanía" que esta caja.
    cve_geo tiene el formato cve_ent(2)+cve_mun(3)+cve_loc(4)+cve_ageb(4) — cve_mun de Tijuana
    es "004"."""
    if not any(a["cve_geo"][2:5] == "004" for a in agebs):
        return ""
    cercanos = hospitales_cardio_cercanos([a["cve_geo"] for a in agebs])
    if not cercanos:
        return ""
    aviso_extra = ""
    if cercanos[-1][0] > RADIO_HOSPITALES_CARDIO_KM:
        # Si el radio fijo deja muy pocos (ej. zona en las afueras), hospitales_cardio_cercanos
        # completa con los más cercanos aunque queden fuera del radio — mejor mostrar algo útil
        # con la distancia real a la vista que dejar la caja vacía por un radio arbitrario.
        aviso_extra = (
            f" No hay suficientes hospitales dentro de {RADIO_HOSPITALES_CARDIO_KM:g} km de esta "
            "zona — se muestran los más cercanos aunque algunos queden más lejos."
        )

    def _rango(minimo, maximo) -> str:
        if minimo is None:
            return "—"
        return str(minimo) if minimo == maximo else f"{minimo}-{maximo}"

    filas = []
    for dist_km, h in cercanos:
        filas.append(
            "<tr>"
            f"<td>{html.escape(h['hospital'])}</td>"
            f"<td>{html.escape(h['nivel'])}</td>"
            f"<td>{dist_km:.1f} km</td>"
            f"<td>{html.escape(h['especialidades'])}</td>"
            f"<td>{_rango(h['quirofanos_min'], h['quirofanos_max'])}</td>"
            f"<td>{_rango(h['camas_min'], h['camas_max'])}</td>"
            "</tr>"
        )

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{len(cercanos):,}</span>'
        '<span class="bar-label">Hospitales privados con capacidad quirúrgica cerca de esta zona</span>'
        "</div>"
        "</div>"
        '<details class="chart-toggle" style="margin-top:0.6rem;" open><summary>Ver listado</summary>'
        '<div style="overflow-x:auto;"><table><tr><th>Hospital</th><th>Nivel</th><th>Distancia</th>'
        f"<th>Especialidades de cardiología</th><th>Quirófanos</th><th>Camas</th></tr>{''.join(filas)}</table></div>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        f'<p class="nse-note">Ordenados por distancia en línea recta desde el centro de la zona consultada '
        f"(radio de referencia: {RADIO_HOSPITALES_CARDIO_KM:g} km).{aviso_extra} Ver el mapa completo con "
        f'todos los hospitales en <a href="/hospitales">🏥 Hospitales de Tijuana</a>.</p>'
        '<p class="nse-note">Nivel III = alta especialidad con hemodinamia/quirófano cardiovascular; '
        "Nivel II = cirugía general con soporte de cardiología clínica.</p>"
        "</details>"
        "</details>"
        "</div>"
    )


def _laboratorios_zona_html(agebs: list[dict]) -> str:
    """Laboratorios de análisis clínicos (competencia real, barrido de Google Maps) CERCANOS a
    la zona analizada — mismo criterio de distancia que _hospitales_cardio_html, pero sobre el
    catálogo de laboratorios_cercanos() (query_engine_local.py). Antes esta comparación solo
    existía a nivel de TODA la ciudad en /mercado-laboratorios; esta caja la trae también a la
    búsqueda normal y a "comparar", para ver de un vistazo qué competidores hay justo en la
    zona de interés."""
    if not any(a["cve_geo"][2:5] == "004" for a in agebs):
        return ""
    cercanos = laboratorios_cercanos([a["cve_geo"] for a in agebs])
    if not cercanos:
        return ""
    aviso_extra = ""
    if cercanos[-1][0] > RADIO_LABORATORIOS_CERCANOS_KM:
        aviso_extra = (
            f" No hay suficientes laboratorios dentro de {RADIO_LABORATORIOS_CERCANOS_KM:g} km de "
            "esta zona — se muestran los más cercanos aunque algunos queden más lejos."
        )

    filas = []
    for dist_km, lab in cercanos:
        filas.append(
            "<tr>"
            f"<td>{html.escape(lab['nombre'])}</td>"
            f"<td>{html.escape(lab['cadena'])}</td>"
            f"<td>{dist_km:.1f} km</td>"
            f"<td>{html.escape(lab['colonia'] or '')}</td>"
            f"<td>{html.escape(lab['direccion'] or '')}</td>"
            "</tr>"
        )

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{len(cercanos):,}</span>'
        '<span class="bar-label">Laboratorios de análisis cerca de esta zona</span>'
        "</div>"
        "</div>"
        '<details class="chart-toggle" style="margin-top:0.6rem;"><summary>Ver listado</summary>'
        '<div style="overflow-x:auto;"><table><tr><th>Laboratorio</th><th>Cadena/marca</th>'
        f"<th>Distancia</th><th>Colonia</th><th>Dirección</th></tr>{''.join(filas)}</table></div>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note">Ordenados por distancia en línea recta desde el centro de la zona consultada '
        f"(radio de referencia: {RADIO_LABORATORIOS_CERCANOS_KM:g} km).{aviso_extra} Ver el mapa completo con "
        f'todos los laboratorios en <a href="/mercado-laboratorios">🧪 Mercado de Laboratorios</a>.</p>'
        "</details>"
        "</details>"
        "</div>"
    )


def _empresas_zona_html(agebs: list[dict]) -> str:
    """Empresas/maquiladoras con nómina alta (101+ empleados) DENTRO de la zona analizada — para
    estimar público potencial a captar (trabajadores) en el sector/zona de interés, tanto en la
    búsqueda normal como en "comparar" (zonas de flujo). Igual que _hospitales_cardio_html,
    factoriza el criterio real en query_engine_local.empresas_en_zona (coincidencia por colonia,
    con respaldo por distancia real para las pocas filas con coordenadas) para que el Excel
    exportado use el mismo criterio. Solo se muestra si la zona toca Tijuana (todo el catálogo
    es de Tijuana)."""
    if not any(a["cve_geo"][2:5] == "004" for a in agebs):
        return ""
    empresas = empresas_en_zona([a["cve_geo"] for a in agebs])
    if not empresas:
        return ""

    total_empleados = sum(e["empleados_estimados"] or 0 for e in empresas)
    filas = []
    for e in empresas:
        empleados_txt = f"{e['empleados_estimados']:,}" if e["empleados_estimados"] is not None else "—"
        filas.append(
            "<tr>"
            f"<td>{html.escape(e['nombre'])}</td>"
            f"<td>{html.escape(e['sector'] or '')}</td>"
            f"<td>{empleados_txt}</td>"
            f"<td>{html.escape(e['colonia'] or '')}</td>"
            "</tr>"
        )

    return (
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{len(empresas):,}</span>'
        '<span class="bar-label">Empresas con nómina alta (101+) en esta zona</span>'
        "</div>"
        '<div class="denue-stat">'
        f'<span class="denue-num">{total_empleados:,.0f}</span>'
        '<span class="bar-label">Empleados estimados — público potencial a captar</span>'
        "</div>"
        "</div>"
        '<details class="chart-toggle" style="margin-top:0.6rem;"><summary>Ver listado</summary>'
        '<div style="overflow-x:auto;"><table><tr><th>Empresa</th><th>Sector</th>'
        f"<th>Empleados (est.)</th><th>Colonia</th></tr>{''.join(filas)}</table></div>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note">Empresas cuya colonia cae dentro de esta zona (catálogo de maquiladoras + DENUE, '
        f'ver <a href="/mercado-empresas">🏭 Mercado de Empresas</a> para el desglose completo de la ciudad).</p>'
        "</details>"
        "</details>"
        "</div>"
    )


def _intercensal_2025_html(cve_mun: str) -> str:
    """Panel de contexto con la Encuesta Intercensal 2025 de INEGI (población, edad, salud,
    economía) — SOLO se muestra en búsquedas por Municipio, porque es la única granularidad
    donde esta fuente y el Censo 2020 (que arma el resto del reporte, a nivel AGEB) coinciden:
    INEGI nunca publica la intercensal por AGEB/colonia, así que no se puede combinar a esa
    escala sin inventar un reparto. Ver local_engine/intercensal_2025.py."""
    dato_municipio = EIC2025_POBLACION_MUNICIPIOS.get(cve_mun)
    if not dato_municipio:
        return ""
    nombre, poblacion, pct_estatal, edad_mediana = dato_municipio
    e = EIC2025_ESTATAL

    def _barras(dic: dict[str, float]) -> str:
        maximo = max(dic.values()) or 1
        filas = []
        for etiqueta, pct in dic.items():
            ancho = round((pct / maximo) * 100, 1)
            filas.append(
                '<div class="bar-row-inline">'
                '<div class="bar-top">'
                f'<span class="bar-label">{html.escape(etiqueta)}</span>'
                f'<span class="bar-value">{pct:g}%</span>'
                "</div>"
                f'<span class="bar-track"><span class="bar-fill" style="width:{ancho}%;background:#3f6fb0;"></span></span>'
                "</div>"
            )
        return "".join(filas)

    return (
        '<details class="audit" style="margin:0.75rem 0;">'
        '<summary>📊 Contexto 2025 (Encuesta Intercensal, INEGI) — no confundir con el Censo 2020 de abajo</summary>'
        '<div class="nse-box">'
        '<div class="denue-stats">'
        '<div class="denue-stat">'
        f'<span class="denue-num">{poblacion:,}</span>'
        f'<span class="bar-label">Población de {html.escape(nombre)} en 2025 ({pct_estatal:g}% del estado)</span>'
        "</div>"
        '<div class="denue-stat">'
        f'<span class="denue-num">{edad_mediana}</span>'
        '<span class="bar-label">Edad mediana (años)</span>'
        "</div>"
        "</div>"
        '<p class="nse-note" style="margin-top:0.7rem;">Contexto estatal de Baja California (2025): '
        f'población en viviendas particulares {e["poblacion_viviendas_particulares"]:,} '
        f'(+{(e["poblacion_viviendas_particulares"] / e["poblacion_2020_viviendas_particulares"] - 1) * 100:.1f}% vs. 2020), '
        f'{e["pct_afiliacion_salud"]:g}% de la población afiliada a algún servicio de salud, '
        f'grado promedio de escolaridad {e["grado_promedio_escolaridad"]:g} años.</p>'
        '<details class="chart-toggle" style="margin-top:0.5rem;"><summary>Ver desglose estatal completo</summary>'
        '<div class="chart-panel">'
        "<p><strong>Grupos de edad</strong></p>"
        f'{_barras(e["grupos_edad"])}'
        "<p style=\"margin-top:0.8rem;\"><strong>Afiliación a servicios de salud</strong></p>"
        f'{_barras(e["afiliacion_por_institucion"])}'
        "<p style=\"margin-top:0.8rem;\"><strong>Sector económico de la población ocupada</strong></p>"
        f'{_barras(e["sector_economico"])}'
        "</div></details>"
        '<p class="nse-note" style="margin-top:0.6rem;">Fuente: INEGI, Encuesta Intercensal 2025 '
        "(momento de referencia 15-oct-2025) — cifras a nivel estatal/municipal, publicadas en texto. "
        "No sustituyen ni se combinan con el Censo 2020 por AGEB que arma el resto de este reporte: "
        "INEGI no publica la intercensal a ese nivel de detalle.</p>"
        "</div>"
        "</details>"
    )


def _zonas_form_html(valor: str, radio: str, zonas_todas: list[dict], zonas_usadas: list[dict]) -> str:
    ids_usadas = {z["id"] for z in zonas_usadas}
    items = []
    for z in zonas_todas:
        checked = "checked" if z["id"] in ids_usadas else ""
        items.append(
            '<label class="zona-item">'
            f'<input type="checkbox" name="zona" value="{z["id"]}" {checked}>'
            f'<span><span class="zona-cp">CP {html.escape(str(z["cp"]))}</span> — {html.escape(z["colonia"])}</span>'
            "</label>"
        )
    plural = "zonas" if len(zonas_todas) != 1 else "zona"
    intro = (
        f'Se {"encontró" if len(zonas_todas) == 1 else "encontraron"} {len(zonas_todas)} {plural} de código postal '
        f'que coincide{"n" if len(zonas_todas) != 1 else ""} con "{html.escape(valor)}". '
        "Cada una lista las colonias reales que agrupa (así identificas exactamente qué representa cada CP). "
        "Desmarca las que no correspondan y vuelve a calcular."
    )
    return (
        '<div class="zonas-box">'
        f"<p>{intro}</p>"
        f'<form method="get" action="/">'
        f'<input type="hidden" name="valor" value="{html.escape(valor)}">'
        f'<input type="hidden" name="radio" value="{html.escape(radio)}">'
        '<input type="hidden" name="zonas_form" value="1">'
        f'<div class="zonas-list">{"".join(items)}</div>'
        '<div class="zonas-actions"><button type="submit" class="secondary">Recalcular con selección</button></div>'
        "</form>"
        "</div>"
    )


def _filtro_nse_html(
    tipo: str, valor_original: str, radio: str, niveles_marcados: set[str], municipio_cve: str = "",
) -> str:
    """Checkboxes para quedarse solo con los AGEBs de cierto Nivel Socioeconómico dentro de
    la consulta actual (útil sobre todo con selecciones grandes: municipio completo, radio
    amplio, colonia con muchas zonas) — recalcula totales, mapa y la lista de colonias/CP
    reales que caen en el filtro, sin tener que rearmar la búsqueda desde cero."""
    if tipo == "Municipio":
        campos_ocultos = f'<input type="hidden" name="municipio" value="{html.escape(valor_original)}">'
    else:
        campos_ocultos = f'<input type="hidden" name="valor" value="{html.escape(valor_original)}">'
        if municipio_cve:
            campos_ocultos += f'<input type="hidden" name="municipio" value="{html.escape(municipio_cve)}">'
    items = []
    for nivel in NIVELES_NSE:
        checked = "checked" if nivel in niveles_marcados else ""
        color = NSE_COLOR.get(nivel, "#6b7280")
        items.append(
            '<label class="nse-filtro-item">'
            f'<input type="checkbox" name="nse" value="{html.escape(nivel)}" {checked}>'
            f'<span class="mapa-leg-dot" style="background:{color};"></span> {html.escape(nivel)}'
            "</label>"
        )
    return (
        '<div class="nse-filtro-box">'
        '<p class="nse-filtro-hint">Filtrar por Nivel Socioeconómico (marca los que te interesan):</p>'
        '<form method="get" action="/">'
        f"{campos_ocultos}"
        f'<input type="hidden" name="radio" value="{html.escape(radio)}">'
        f'<div class="nse-filtro-list">{"".join(items)}</div>'
        '<div class="nse-filtro-actions"><button type="submit" class="secondary">Aplicar filtro</button></div>'
        "</form>"
        "</div>"
    )


def _colonias_filtradas_html(colonias: list[dict]) -> str:
    if not colonias:
        return ""
    filas = "".join(
        f"<tr><td>{html.escape(c['municipio'])}</td><td>{html.escape(str(c['cp'] or '—'))}</td>"
        f"<td>{html.escape(c['colonia'])}</td></tr>"
        for c in colonias
    )
    return (
        f'<details class="audit" open><summary>Colonias/CP en este filtro ({len(colonias)})</summary>'
        "<table><tr><th>Municipio</th><th>CP</th><th>Colonia</th></tr>"
        f"{filas}</table>"
        '<p class="nse-filtro-hint">Calculado por punto-en-polígono contra los AGEBs filtrados '
        "(misma asignación Colonia/CP → AGEB que usa el resto del agente) — no todos los CP "
        "aparecen aquí, solo los que tienen colonias/CP con nombre real cargadas en el catálogo.</p>"
        "</details>"
    )


def _punto_info_html(lat: float, lon: float, info: dict) -> str:
    ageb = info.get("ageb")
    zonas = info.get("zonas") or []

    if ageb:
        ageb_txt = f"AGEB {html.escape(ageb['cve_ageb'])} (clave completa {html.escape(ageb['cve_geo'])})"
    else:
        ageb_txt = "fuera de cualquier AGEB conocido del Marco Geoestadístico"

    if zonas:
        nombres = ", ".join(f"{html.escape(z['colonia'])} (CP {html.escape(str(z['cp']))})" for z in zonas)
        zonas_txt = f"dentro de: {nombres}"
    else:
        zonas_txt = "no cae dentro de ninguna zona de Colonia/CP catalogada"

    return (
        '<div class="zonas-box">'
        f'<p>Coordenada identificada: <strong>{lat:.5f}, {lon:.5f}</strong> — {ageb_txt}; {zonas_txt}.</p>'
        "</div>"
    )


_RE_COORDENADAS = re.compile(r"^\s*(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$")
_RE_CP = re.compile(r"^\d{5}$")
_RE_AGEB_CORTA = re.compile(r"^[0-9A-Za-z]{4}$")
_RE_AGEB_COMPLETA = re.compile(r"^\d{13}$")


def _detectar_tipo(valor: str) -> str:
    """Detecta automáticamente qué está buscando el usuario a partir de un solo campo de
    texto, sin que tenga que elegir el tipo a mano:
    - "lat,lon" con ambos números en rango válido -> Coordenadas.
    - 5 dígitos -> Código Postal.
    - 4 caracteres alfanuméricos o 13 dígitos -> clave de AGEB (corta o completa).
    - cualquier otra cosa -> Colonia (búsqueda por nombre)."""
    v = valor.strip()

    m = _RE_COORDENADAS.match(v)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return "Coordenadas"

    if _RE_CP.match(v):
        return "CP"

    if _RE_AGEB_CORTA.match(v) or _RE_AGEB_COMPLETA.match(v):
        return "AGEB"

    return "Colonia"


NIVELES_NSE = ["Alto", "Medio", "Bajo", "Muy bajo"]


def _query_string_actual(
    tipo: str, valor_original: str, radio: str, nse_filtro: set[str] | None, municipio_sel: str = "",
) -> str:
    """Arma la query string para que el link 'Descargar CSV' reproduzca EXACTAMENTE la
    consulta que se está viendo (mismo municipio/valor, radio y filtro de NSE)."""
    if tipo == "Municipio":
        params = [("municipio", valor_original)]
    else:
        params = [("valor", valor_original)]
        if municipio_sel:
            params.append(("municipio", municipio_sel))
    if radio:
        params.append(("radio", radio))
    for nivel in nse_filtro or ():
        params.append(("nse", nivel))
    return urllib.parse.urlencode(params)


class _ErrorConsulta(Exception):
    """Mensaje de error ya en HTML (escapado), para cortar _resolver_consulta() desde
    cualquier rama sin duplicar el try/except en cada llamador (render_resultado y el
    endpoint de exportar CSV comparten esta misma resolución de la consulta)."""


def _resolver_consulta(
    tipo: str, valor: str, radio: str, zona_ids: list[str] | None, nse_filtro: set[str] | None,
    municipio_nombre: str | None = None,
) -> dict:
    """Corre la consulta (Municipio/Coordenadas/Colonia/CP/AGEB) y aplica el filtro por NSE si
    corresponde — toda la parte que NO es HTML, compartida entre la página de resultados y la
    exportación a CSV. Lanza _ErrorConsulta con el mensaje listo para mostrar si algo falla."""
    valor_original = valor  # antes de que la rama "Municipio" lo cambie por el nombre legible
    radio = radio.strip()
    radio_km = None
    if radio:
        try:
            radio_km = float(radio)
        except ValueError:
            raise _ErrorConsulta('<p class="error">Radio inválido: debe ser un número en kilómetros (ej. 1.5).</p>')
        if tipo not in ("Colonia", "CP", "Coordenadas"):
            raise _ErrorConsulta('<p class="error">El radio solo aplica cuando buscas por Colonia, Código Postal o Coordenadas.</p>')

    lat = lon = None
    info_punto = None
    if tipo == "Municipio":
        nombre_mun = MUNICIPIOS_BC.get(valor)
        if nombre_mun is None:
            raise _ErrorConsulta('<p class="error">Municipio no reconocido.</p>')
        try:
            totals, agebs = analizar_municipio(valor)
        except (ZonaNoEncontradaError, ValueError) as e:
            raise _ErrorConsulta(f'<p class="error">{html.escape(str(e))}</p>')
        except Exception:
            logger.exception("Error procesando consulta web.")
            raise _ErrorConsulta('<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>')
        valor = nombre_mun  # para mostrar el nombre ("Mexicali"), no la clave ("002"), en el encabezado
        zonas_todas, zonas_usadas = [], []
    elif tipo == "Coordenadas":
        partes_coord = [p.strip() for p in valor.split(",")]
        if len(partes_coord) != 2:
            raise _ErrorConsulta('<p class="error">Formato inválido. Escribe "lat,lon" (ej. 32.5048,-116.9350).</p>')
        try:
            lat, lon = float(partes_coord[0]), float(partes_coord[1])
        except ValueError:
            raise _ErrorConsulta('<p class="error">Coordenada inválida: lat y lon deben ser números.</p>')
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise _ErrorConsulta('<p class="error">Coordenada fuera de rango (lat entre -90 y 90, lon entre -180 y 180).</p>')
        try:
            totals, agebs, info_punto = analizar_por_coordenada(lat, lon, radio_km=radio_km)
        except ZonaNoEncontradaError as e:
            raise _ErrorConsulta(f'<p class="error">{html.escape(str(e))}</p>')
        except Exception:
            logger.exception("Error procesando consulta web.")
            raise _ErrorConsulta('<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>')
        zona_punto = {"id": "coord", "cp": None, "colonia": "Coordenada elegida", "lat": lat, "lon": lon}
        zonas_todas = [zona_punto]
        zonas_usadas = [zona_punto]
    else:
        zona_ids_set = None
        if zona_ids is not None:
            try:
                zona_ids_set = {int(z) for z in zona_ids}
            except ValueError:
                zona_ids_set = set()

        try:
            totals, agebs, zonas_todas, zonas_usadas = analizar_locacion(
                tipo, valor, radio_km=radio_km, zona_ids=zona_ids_set, municipio=municipio_nombre
            )
        except ZonaNoEncontradaError as e:
            raise _ErrorConsulta(f'<p class="error">{html.escape(str(e))}</p>')
        except ValueError as e:
            raise _ErrorConsulta(f'<p class="error">{html.escape(str(e))}</p>')
        except Exception:
            logger.exception("Error procesando consulta web.")
            raise _ErrorConsulta('<p class="error">Ocurrió un error procesando la consulta. Revisa logs/server.log.</p>')

    # Filtro por Nivel Socioeconómico: solo tiene sentido con más de un AGEB (con uno solo,
    # "filtrar" no cambia nada). Si el usuario marcó un subconjunto propio de los 4 niveles,
    # se recorta `agebs`/`totals` a solo esos AGEBs — todo lo que sigue (mapa, gráficas,
    # exportar CSV) ya trabaja sobre el resultado filtrado sin necesitar más cambios.
    filtro_nse_activo = bool(nse_filtro) and len(agebs) > 1 and set(nse_filtro) != set(NIVELES_NSE)
    agebs_pre_filtro = agebs
    colonias_filtradas = None
    if filtro_nse_activo:
        niveles_todos = nse_por_ageb([a["cve_geo"] for a in agebs])
        cve_geos_filtrados = [a["cve_geo"] for a in agebs if niveles_todos.get(a["cve_geo"]) in nse_filtro]
        if cve_geos_filtrados:
            totals, agebs = totales_por_agebs(cve_geos_filtrados)
            colonias_filtradas = colonias_para_agebs(cve_geos_filtrados)
        else:
            agebs = []

    return {
        "tipo": tipo, "valor": valor, "valor_original": valor_original, "radio": radio,
        "radio_km": radio_km, "totals": totals, "agebs": agebs,
        "agebs_pre_filtro": agebs_pre_filtro, "zonas_todas": zonas_todas,
        "zonas_usadas": zonas_usadas, "filtro_nse_activo": filtro_nse_activo,
        "colonias_filtradas": colonias_filtradas, "lat": lat, "lon": lon, "info_punto": info_punto,
        "municipio_nombre": nombre_mun if tipo == "Municipio" else municipio_nombre,
    }


# Construido con .replace() (no .format()) para poder reusar SHARED_STYLE_BLOCK (mismo CSS
# que PAGE_TEMPLATE, sin re-escapar llaves) — así los reportes por zona embebidos (que usan
# clases como .card/.grid/.bar-track/.nse-box/.denue-modal definidas ahí) se ven igual que en
# la página principal en vez de salir sin estilo.
COMPARAR_PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI — Combinar zonas</title>
<style>
__ESTILO_COMPARTIDO__
  .comparar-layout { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-start; }
  #comparar-mapa { flex: 2 1 520px; height: 520px; border-radius: 10px; border: 1px solid var(--border); min-width: 320px; }
  .comparar-panel { flex: 1 1 280px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1rem; align-self: flex-start; }
  .comparar-panel h3 { margin: 0 0 0.5rem; font-size: 1rem; }
  .comparar-hint { font-size: 0.78rem; color: var(--text-muted); margin: 0 0 0.75rem; }
  .lugar-form { border: 1px dashed var(--border); border-radius: 8px; padding: 0.6rem 0.7rem; margin: 0 0 0.75rem; }
  .lugar-form input[type="text"] { width: 100%; box-sizing: border-box; padding: 0.4rem 0.5rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); font-size: 0.85rem; margin-bottom: 0.4rem; }
  .lugar-form-row { display: flex; align-items: center; gap: 0.4rem; }
  .lugar-form-row input[type="text"] { width: 3.5rem; margin-bottom: 0; }
  .lugar-form-row button { flex: 1; padding: 0.4rem; font-size: 0.82rem; }
  .punto-row { display: flex; align-items: center; gap: 0.4rem; padding: 0.4rem 0; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
  .punto-row input[type="text"] { width: 4.5rem; padding: 0.25rem 0.4rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); }
  .punto-row .punto-label { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .punto-row button { background: none; border: none; color: var(--error); cursor: pointer; font-size: 1rem; padding: 0.2rem 0.4rem; }
  #btn-comparar { margin-top: 0.75rem; width: 100%; padding: 0.6rem; border: none; border-radius: 8px; background: var(--accent); color: white; font-weight: 600; cursor: pointer; }
  #btn-comparar:disabled { opacity: 0.5; cursor: not-allowed; }
  details.zona-detalle { margin-top: 1rem; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 0 1rem; }
  details.zona-detalle summary { cursor: pointer; font-weight: 600; padding: 0.75rem 0; }
  details.zona-detalle[open] summary { border-bottom: 1px solid var(--border); }
</style>
</head>
<body>
<h1>Combinar zonas</h1>
<p class="subtitle"><a href="/">← Volver a la búsqueda normal</a> · Baja California · Censo 2020 · 100% local · <a href="/logout">🔒 Cerrar sesión</a></p>
<div class="comparar-layout">
  <div id="comparar-mapa" data-tiles="__TILES_DISPONIBLES__" data-max-zoom="__TILE_MAX_ZOOM__"
       data-puntos-iniciales="__PUNTOS_INICIALES_JSON__" data-agebs-iniciales="__AGEBS_INICIALES_JSON__"
       data-lugares-iniciales="__LUGARES_INICIALES_JSON__"></div>
  <div class="comparar-panel">
    <h3>Zonas a combinar</h3>
    <p class="comparar-hint">Clic directo sobre un AGEB/colonia para agregarlo tal cual, o clic en área vacía para agregar un punto con radio propio. Presiona "Analizar zonas combinadas" para fusionarlas en un solo reporte.</p>
    <div class="lugar-form">
      <p class="comparar-hint" style="margin-top:0;">O escribe una zona directo (más preciso que marcarla en el mapa). Si escribes coordenadas "lat,lon" se ve el punto en el mapa; colonia/CP/AGEB no se puede previsualizar, pero sí se incluye en el análisis igual:</p>
      <input type="text" id="lugar-valor" placeholder="Colonia, CP, AGEB o &quot;lat,lon&quot;">
      <div class="lugar-form-row">
        <input type="text" id="lugar-radio" value="1" title="Radio en km (solo aplica a Colonia/CP/coordenadas)">
        <span class="comparar-hint" style="margin:0;">km</span>
        <button type="button" id="btn-agregar-lugar" class="secondary">Agregar</button>
      </div>
    </div>
    <div id="lista-puntos"></div>
    <button type="button" id="btn-comparar" disabled>Analizar zonas combinadas</button>
  </div>
</div>
__GUARDADOS__
__RESULTADO__
<footer style="margin-top:2rem;color:var(--text-muted);font-size:0.78rem;text-align:center;">Fuente: INEGI — Marco Geoestadístico y Censo de Población y Vivienda 2020.</footer>
</body>
</html>
"""


HOSPITALES_PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI — Hospitales</title>
<style>
__ESTILO_COMPARTIDO__
  .hosp-layout { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-start; }
  #hosp-mapa { flex: 2 1 520px; height: 560px; border-radius: 10px; border: 1px solid var(--border); min-width: 320px; }
  .hosp-panel { flex: 1 1 320px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1rem; align-self: flex-start; max-height: 560px; overflow-y: auto; }
  .hosp-panel h3 { margin: 0 0 0.5rem; font-size: 1rem; }
  .hosp-stats { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 0.8rem; }
  .hosp-stat { text-align: center; }
  .hosp-stat b { display: block; font-size: 1.3rem; color: var(--accent); }
  .hosp-stat span { font-size: 0.72rem; color: var(--text-muted); }
  .hosp-filtros { display: flex; gap: 0.9rem; margin-bottom: 0.7rem; font-size: 0.85rem; }
  .hosp-item { border: 1px solid var(--border); border-radius: 8px; padding: 0.5rem 0.65rem; margin-bottom: 0.5rem; cursor: pointer; }
  .hosp-item:hover { border-color: var(--accent); }
  .hosp-item-head { display: flex; justify-content: space-between; align-items: baseline; gap: 0.5rem; }
  .hosp-item-head b { font-size: 0.88rem; }
  .hosp-nivel-badge { font-size: 0.68rem; padding: 0.1rem 0.4rem; border-radius: 4px; color: white; flex: none; }
  .hosp-item-meta { font-size: 0.76rem; color: var(--text-muted); margin-top: 0.2rem; }
  .hosp-sin-coord { opacity: 0.7; cursor: default; }
  .hosp-sin-coord:hover { border-color: var(--border); }
  .leaflet-popup-content { font-size: 0.82rem; max-width: 240px; }
  .leaflet-popup-content b { display: block; margin-bottom: 0.2rem; }
</style>
</head>
<body>
<h1>Hospitales — Capacidad Quirúrgica en Tijuana</h1>
<p class="subtitle"><a href="/">← Volver a la búsqueda normal</a> · Baja California · 100% local · <a href="/logout">🔒 Cerrar sesión</a></p>
__RESULTADO__
<footer style="margin-top:2rem;color:var(--text-muted);font-size:0.78rem;text-align:center;">Inventario de infraestructura hospitalaria privada — curado a mano, no es un dato oficial de INEGI.</footer>
</body>
</html>
"""


def render_hospitales_cardio() -> str:
    """Página dedicada de hospitales privados con capacidad cardiovascular (nivel II/III) en
    Tijuana — mapa con un pin por hospital + panel con lista/filtro, en vez de mezclarse dentro
    del reporte normal de zona (que ya tenía la caja _hospitales_cardio_html): el usuario pidió
    poder "analizar hospitales" como su propia sección, con sus funciones propias (filtrar por
    nivel, ver todo el mapa de una vez) en lugar de un dato más dentro de otra búsqueda."""
    hospitales = listar_hospitales_cardio()
    if not hospitales:
        return '<p class="error">No hay hospitales cargados — corre <code>python main_local.py run-etl</code> con el CSV en data/hospitales_cardio/.</p>'

    con_coord = [h for h in hospitales if h["lat"] is not None and h["lon"] is not None]
    sin_coord = [h for h in hospitales if h["lat"] is None or h["lon"] is None]

    n_hospitales = len(hospitales)
    q_min = sum(h["quirofanos_min"] or 0 for h in hospitales)
    q_max = sum(h["quirofanos_max"] or 0 for h in hospitales)
    c_min = sum(h["camas_min"] or 0 for h in hospitales)
    c_max = sum(h["camas_max"] or 0 for h in hospitales)

    def _rango(minimo, maximo) -> str:
        if not minimo and not maximo:
            return "—"
        return str(minimo) if minimo == maximo else f"{minimo}-{maximo}"

    items = []
    for idx, h in enumerate(hospitales):
        tiene_coord = h["lat"] is not None and h["lon"] is not None
        color = "#c0392b" if h["nivel"] == "Nivel III" else "#3a7ca8"
        clase = "hosp-item" if tiene_coord else "hosp-item hosp-sin-coord"
        data_idx = f' data-idx="{idx}"' if tiene_coord else ""
        items.append(
            f'<div class="{clase}"{data_idx}>'
            '<div class="hosp-item-head">'
            f"<b>{html.escape(h['hospital'])}</b>"
            f'<span class="hosp-nivel-badge" style="background:{color};">{html.escape(h["nivel"])}</span>'
            "</div>"
            f'<div class="hosp-item-meta">🔪 {_rango(h["quirofanos_min"], h["quirofanos_max"])} quirófanos · '
            f'🛏️ {_rango(h["camas_min"], h["camas_max"])} camas'
            f'{"" if tiene_coord else " · sin coordenada (no se puede ubicar en el mapa todavía)"}</div>'
            "</div>"
        )

    marcadores_json = json.dumps([
        {
            "idx": idx,
            "lat": h["lat"],
            "lon": h["lon"],
            "hospital": h["hospital"],
            "nivel": h["nivel"],
            "especialidades": h["especialidades"],
            "quirofanos": _rango(h["quirofanos_min"], h["quirofanos_max"]),
            "camas": _rango(h["camas_min"], h["camas_max"]),
            "notas": h["notas"] or "",
        }
        for idx, h in enumerate(hospitales) if h["lat"] is not None and h["lon"] is not None
    ])

    aviso_sin_coord = ""
    if sin_coord:
        nombres = ", ".join(html.escape(h["hospital"]) for h in sin_coord)
        aviso_sin_coord = (
            f'<p class="nse-note">{len(sin_coord)} hospital(es) sin coordenada confirmada — no aparecen '
            f"en el mapa, solo en la lista: {nombres}.</p>"
        )

    return (
        '<div class="hosp-layout">'
        f'<div id="hosp-mapa" data-tiles="{"1" if _comparar_mapa_disponible() else "0"}" '
        f'data-max-zoom="{TILE_MAX_ZOOM_DESCARGADO}" '
        f'data-marcadores="{_html_attr_escape_comparar(marcadores_json)}"></div>'
        '<div class="hosp-panel">'
        '<div class="hosp-stats">'
        f'<div class="hosp-stat"><b>{n_hospitales}</b><span>Hospitales</span></div>'
        f'<div class="hosp-stat"><b>{_rango(q_min, q_max)}</b><span>Quirófanos (total)</span></div>'
        f'<div class="hosp-stat"><b>{_rango(c_min, c_max)}</b><span>Camas (total)</span></div>'
        "</div>"
        '<div class="hosp-filtros">'
        '<label><input type="checkbox" class="hosp-filtro-nivel" value="Nivel III" checked> Nivel III</label>'
        '<label><input type="checkbox" class="hosp-filtro-nivel" value="Nivel II" checked> Nivel II</label>'
        "</div>"
        f'<div id="hosp-lista">{"".join(items)}</div>'
        f"{aviso_sin_coord}"
        "</div>"
        "</div>"
    )


HOSPITALES_MAPA_SCRIPT = """
<script>
(function () {
  var div = document.getElementById('hosp-mapa');
  if (!div || typeof L === 'undefined') return;
  var marcadoresData = JSON.parse(div.getAttribute('data-marcadores') || '[]');
  var maxZoom = parseInt(div.getAttribute('data-max-zoom'), 10) || 14;
  var tilesOk = div.getAttribute('data-tiles') === '1';

  var map = L.map(div).setView([32.52, -117.01], 12);
  if (tilesOk) {
    L.tileLayer('/tiles/{z}/{x}/{y}.png', {
      maxNativeZoom: maxZoom, maxZoom: 19, minZoom: 3,
      attribution: '&copy; colaboradores de OpenStreetMap',
    }).addTo(map);
  }

  var capasPorIdx = {};
  var grupo = L.layerGroup().addTo(map);
  var bounds = [];

  function colorNivel(nivel) { return nivel === 'Nivel III' ? '#c0392b' : '#3a7ca8'; }

  marcadoresData.forEach(function (h) {
    var marker = L.circleMarker([h.lat, h.lon], {
      radius: h.nivel === 'Nivel III' ? 10 : 7,
      color: '#fff', weight: 1.5, fillColor: colorNivel(h.nivel), fillOpacity: 0.9,
    });
    var popup =
      '<b>' + h.hospital + '</b>' +
      '<div>' + h.nivel + '</div>' +
      '<div style="margin:0.3rem 0;">' + h.especialidades.split(';').join('<br>') + '</div>' +
      '<div>🔪 ' + h.quirofanos + ' quirófanos · 🛏️ ' + h.camas + ' camas</div>' +
      (h.notas ? '<div style="margin-top:0.3rem;color:#8a8f98;">' + h.notas + '</div>' : '');
    marker.bindPopup(popup);
    marker.addTo(grupo);
    capasPorIdx[h.idx] = marker;
    bounds.push([h.lat, h.lon]);
  });

  if (bounds.length) map.fitBounds(bounds, { padding: [30, 30] });

  document.querySelectorAll('.hosp-item[data-idx]').forEach(function (item) {
    item.addEventListener('click', function () {
      var idx = item.getAttribute('data-idx');
      var marker = capasPorIdx[idx];
      if (!marker) return;
      map.setView(marker.getLatLng(), 15);
      marker.openPopup();
    });
  });

  function aplicarFiltro() {
    var nivelesActivos = Array.prototype.filter.call(
      document.querySelectorAll('.hosp-filtro-nivel'), function (c) { return c.checked; }
    ).map(function (c) { return c.value; });
    grupo.clearLayers();
    marcadoresData.forEach(function (h) {
      if (nivelesActivos.indexOf(h.nivel) !== -1) capasPorIdx[h.idx].addTo(grupo);
    });
    document.querySelectorAll('.hosp-item[data-idx]').forEach(function (item) {
      var idx = item.getAttribute('data-idx');
      var h = marcadoresData[parseInt(idx, 10)] || marcadoresData.find(function (m) { return String(m.idx) === idx; });
      item.style.display = (h && nivelesActivos.indexOf(h.nivel) === -1) ? 'none' : '';
    });
  }
  document.querySelectorAll('.hosp-filtro-nivel').forEach(function (chk) {
    chk.addEventListener('change', aplicarFiltro);
  });
})();
</script>
"""


MERCADO_LAB_PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI — Mercado de Laboratorios</title>
<style>
__ESTILO_COMPARTIDO__
  .mlab-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; }
  .mlab-stat { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 0.9rem 1.2rem; }
  .mlab-cadena-dot { display: inline-block; width: 0.6rem; height: 0.6rem; border-radius: 50%; margin-right: 0.35rem; flex: none; }
  .mlab-proyeccion-input { display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; font-weight: 600; }
  .mlab-proyeccion-input input { padding: 0.4rem 0.5rem; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); color: var(--text); width: 90px; font-size: 0.95rem; }
  .mlab-stat b { display: block; font-size: 1.5rem; color: var(--accent); }
  .mlab-stat span { font-size: 0.78rem; color: var(--text-muted); }
  .mlab-inputs { display: flex; gap: 1rem; flex-wrap: wrap; margin: 1rem 0; }
  .mlab-inputs label { display: flex; flex-direction: column; gap: 0.3rem; font-size: 0.85rem; font-weight: 600; }
  .mlab-inputs input[type="number"] { padding: 0.5rem 0.6rem; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); color: var(--text); font-size: 1rem; width: 180px; }
  .mlab-donas { display: flex; gap: 2rem; flex-wrap: wrap; margin-top: 1.2rem; }
  .mlab-dona-col { text-align: center; flex: 0 1 220px; }
  .mlab-dona-col .retorno-pie-legend { min-width: 0; }
  .mlab-layout { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-start; margin-top: 1rem; }
  #mlab-mapa { flex: 2 1 480px; height: 460px; border-radius: 10px; border: 1px solid var(--border); min-width: 300px; }
  .mlab-cadenas-col { flex: 1 1 320px; min-width: 280px; }
  .mlab-cadena-row { cursor: pointer; border-radius: 8px; padding: 0.25rem 0.35rem; margin: 0 -0.35rem; transition: background 0.15s; }
  .mlab-cadena-row:hover { background: rgba(127,127,127,0.12); }
  .mlab-cadena-row.activo { background: var(--accent-soft); }
  .mlab-reset-filtro { display: none; font-size: 0.78rem; margin: 0 0 0.6rem; background: none; border: 1px solid var(--border); border-radius: 6px; padding: 0.25rem 0.6rem; color: var(--text); cursor: pointer; }
  .mlab-reset-filtro.visible { display: inline-block; }
  .mlab-panel-layout { display: flex; gap: 1.2rem; flex-wrap: wrap; margin-top: 0.8rem; align-items: stretch; }
  .mlab-panel-izq { flex: 2 1 480px; border: 1px solid var(--border); border-radius: 10px; padding: 1rem; }
  .mlab-panel-der { flex: 1 1 260px; border: 1px solid var(--border); border-radius: 10px; padding: 1rem; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.8rem; }
  .mlab-objetivo-label { display: flex; flex-direction: column; gap: 0.3rem; font-size: 0.85rem; font-weight: 600; align-self: stretch; text-align: center; }
  .mlab-objetivo-label input { padding: 0.5rem 0.6rem; border: 1px solid var(--border); border-radius: 6px; background: var(--surface); color: var(--text); font-size: 1rem; width: 100%; max-width: 180px; margin: 0 auto; text-align: center; }
  .mlab-total-objetivo { margin: 0.4rem 0 0; font-size: 0.85rem; font-weight: 700; color: var(--accent); text-align: center; }
  .mlab-donas-par { display: flex; gap: 1.5rem; flex-wrap: wrap; margin-top: 0.8rem; }
</style>
</head>
<body>
<h1>Mercado de Laboratorios — % que representamos</h1>
<p class="subtitle"><a href="/">← Volver a la búsqueda normal</a> · 100% local · <a href="/logout">🔒 Cerrar sesión</a></p>
__RESULTADO__
<footer style="margin-top:2rem;color:var(--text-muted);font-size:0.78rem;text-align:center;">Universo de laboratorios: barrido propio de Google Maps (Tijuana). Demanda estimada: misma fórmula de "Valor de la zona".</footer>
</body>
</html>
"""


PALETA_CADENAS_MERCADO_LAB = [
    "#3a7ca8", "#c9433a", "#7a9a3a", "#9a6ac9", "#c9973a", "#3a9ac9", "#c93a7a",
    "#5a8a5a", "#a85a3a", "#3a5aa8", "#a83a5a", "#5a3aa8", "#8a8a3a", "#3a8a8a",
    "#a8735a", "#735aa8", "#a89a3a",
]


def _colores_cadenas_mercado_lab(cadenas: list[dict], cadena_propia: str) -> dict[str, str]:
    """Un color fijo y distinto por cadena/marca (para identificarlas a la vez en el ranking de
    barras y como pines en el mapa) — la propia siempre en verde/acento, "Independiente" (bolsa
    de 46 negocios sin relación entre sí, no una cadena real) en gris neutro, y cada cadena real
    restante toma un color de PALETA_CADENAS_MERCADO_LAB en el mismo orden que el ranking (así
    las cadenas más grandes, más relevantes para el análisis, se quedan con los colores más
    distinguibles al principio de la paleta)."""
    colores = {}
    idx = 0
    for c in cadenas:
        nombre = c["cadena"]
        if nombre == cadena_propia:
            colores[nombre] = "#2f9e6f"
        elif nombre == "Independiente":
            colores[nombre] = "#8f97a3"
        else:
            colores[nombre] = PALETA_CADENAS_MERCADO_LAB[idx % len(PALETA_CADENAS_MERCADO_LAB)]
            idx += 1
    return colores


def render_mercado_laboratorios() -> str:
    """Modelaje de "% de mercado" a nivel de TODA la ciudad (a diferencia de "Valor de la
    zona", que es por AGEB/zona puntual): compara la cadena propia (CADENA_PROPIA_MERCADO_LAB)
    contra el universo real de laboratorios de análisis clínicos de Tijuana — un barrido curado
    a mano de Google Maps con coordenadas exactas y cadena identificada por sucursal, ver
    etl_local.py:load_laboratorios_mercado — en vez de estimar con el DENUE (que para esta
    industria mezcla patología/imagen bajo la misma clase SCIAN y no siempre da un nombre de
    cadena limpio). El % de sucursales sale directo de este barrido (dato real, sin captura
    manual); el % de mercado por pacientes/órdenes sigue siendo un input manual porque INEGI
    no publica volumen de pacientes por laboratorio — eso es dato interno del negocio."""
    datos = analizar_mercado_laboratorios()
    if datos["total_laboratorios"] == 0:
        return (
            '<p class="error">No hay laboratorios de mercado cargados — corre '
            "<code>python main_local.py run-etl</code> con el CSV en data/mercado_laboratorios/.</p>"
        )

    maximo = datos["cadenas"][0]["sucursales"] if datos["cadenas"] else 1
    color_por_cadena = _colores_cadenas_mercado_lab(datos["cadenas"], datos["cadena_propia"])
    filas_cadenas = []
    for c in datos["cadenas"][:12]:
        es_propia = c["cadena"] == datos["cadena_propia"]
        color = color_por_cadena[c["cadena"]]
        pct_barra = round((c["sucursales"] / maximo) * 100, 1) if maximo else 0
        filas_cadenas.append(
            f'<div class="bar-row-inline mlab-cadena-row" data-cadena="{html.escape(c["cadena"])}" '
            'title="Clic para ver solo sus sucursales en el mapa">'
            '<div class="bar-top">'
            f'<span class="bar-label"><span class="mlab-cadena-dot" style="background:{color};"></span>'
            f'{"⭐ " if es_propia else ""}{html.escape(c["cadena"])} '
            f'<span style="color:var(--text-muted);font-size:0.78rem;">({html.escape(c["tipo"] or "")})</span></span>'
            f'<span class="bar-value" style="color:{color};">{c["sucursales"]} ({c["pct"]:g}%)</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct_barra}%;background:{color};"></span></span>'
            "</div>"
        )
    if len(datos["cadenas"]) > 12:
        filas_cadenas.append(
            f'<p class="nse-note">+{len(datos["cadenas"]) - 12} cadenas/marcas más con menos sucursales.</p>'
        )

    filas_lab = "".join(
        f"<tr><td>{html.escape(lab['nombre'])}</td><td>{html.escape(lab['cadena'])}</td>"
        f"<td>{html.escape(lab['colonia'] or '')}</td><td>{html.escape(lab['direccion'] or '')}</td></tr>"
        for lab in datos["laboratorios"]
    )

    marcadores_json = json.dumps([
        {
            "nombre": lab["nombre"], "cadena": lab["cadena"], "propia": lab["cadena"] == datos["cadena_propia"],
            "color": color_por_cadena[lab["cadena"]],
            "colonia": lab["colonia"] or "", "direccion": lab["direccion"] or "",
            "lat": lab["lat"], "lon": lab["lon"],
        }
        for lab in datos["laboratorios"] if lab["lat"] is not None and lab["lon"] is not None
    ])

    return (
        '<div class="mlab-stats">'
        f'<div class="mlab-stat"><b>{datos["poblacion_total"]:,.0f}</b><span>Población de {html.escape(datos["municipio"])}</span></div>'
        f'<div class="mlab-stat"><b>{datos["total_laboratorios"]:,}</b><span>Laboratorios de análisis (barrido propio)</span></div>'
        f'<div class="mlab-stat"><b>{datos["sucursales_propias"]:,} ({datos["pct_sucursales_propias"]:g}%)</b>'
        f'<span>Sucursales {html.escape(datos["cadena_propia"])}</span></div>'
        f'<div class="mlab-stat"><b>{datos["demanda_estimada_anual"]:,.0f}</b><span>Órdenes/año estimadas en toda la ciudad</span></div>'
        "</div>"
        '<div class="mlab-layout">'
        f'<div id="mlab-mapa" data-tiles="{"1" if _comparar_mapa_disponible() else "0"}" '
        f'data-max-zoom="{TILE_MAX_ZOOM_DESCARGADO}" '
        f'data-marcadores="{_html_attr_escape_comparar(marcadores_json)}"></div>'
        '<div class="mlab-cadenas-col">'
        '<p class="donut-title" style="margin-top:0;">Sucursales por cadena/marca</p>'
        '<button type="button" class="mlab-reset-filtro">✕ Ver todas las sucursales</button>'
        f'{"".join(filas_cadenas)}'
        "</div>"
        "</div>"
        '<div class="nse-box mlab-box" '
        f'data-demanda-estimada="{datos["demanda_estimada_anual"]:.4f}">'
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note" style="margin:0 0 0.6rem;">El % de mercado por pacientes/órdenes es la única parte que sigue '
        "capturándose a mano: INEGI no publica volumen de pacientes por laboratorio, es información de tu propio negocio.</p>"
        "</details>"
        '<div class="mlab-panel-layout">'
        '<div class="mlab-panel-izq">'
        '<div class="mlab-inputs">'
        '<label>Tus pacientes/órdenes atendidos al año<input type="number" class="mlab-pacientes" min="0" value="0"></label>'
        "</div>"
        '<div class="mlab-donas-par">'
        '<div class="mlab-dona-col">'
        '<div class="retorno-pie-holder"><div class="mlab-pie-pacientes"></div>'
        '<div class="retorno-pie-centro"><span class="mlab-pct-pacientes retorno-pie-centro-num"></span>'
        '<span class="retorno-pie-centro-label">de mercado</span></div></div>'
        '<p class="donut-title">% de mercado que representas</p>'
        '<div class="legend retorno-pie-legend mlab-legend-pacientes"></div>'
        "</div>"
        '<div class="mlab-dona-col">'
        '<div class="retorno-pie-holder"><div class="mlab-pie-faltante"></div>'
        '<div class="retorno-pie-centro"><span class="mlab-pct-faltante retorno-pie-centro-num"></span>'
        '<span class="retorno-pie-centro-label">sin cubrir</span></div></div>'
        '<p class="donut-title">% de la demanda que NO cubrimos</p>'
        '<div class="legend retorno-pie-legend mlab-legend-faltante"></div>'
        "</div>"
        "</div>"
        "</div>"
        '<div class="mlab-panel-der">'
        '<label class="mlab-objetivo-label">% de mercado objetivo (para proyección)'
        '<input type="number" class="mlab-objetivo" min="0" max="100" step="0.1" value="0"></label>'
        '<div class="mlab-dona-col">'
        '<div class="retorno-pie-holder"><div class="mlab-pie-proyeccion"></div>'
        '<div class="retorno-pie-centro"><span class="mlab-pct-proyeccion retorno-pie-centro-num"></span>'
        '<span class="retorno-pie-centro-label">del objetivo</span></div></div>'
        '<p class="donut-title">Proyección: órdenes para llegar al objetivo</p>'
        '<div class="legend retorno-pie-legend mlab-legend-proyeccion"></div>'
        '<p class="mlab-total-objetivo"></p>'
        "</div>"
        "</div>"
        "</div>"
        '<details class="chart-toggle" style="margin-top:0.8rem;"><summary>Ver fórmulas</summary>'
        '<div class="chart-panel">'
        f"<p><code>% de sucursales = sucursales de {html.escape(datos['cadena_propia'])} ÷ "
        f"{datos['total_laboratorios']} laboratorios totales × 100</code> — dato real del barrido, no estimado</p>"
        f"<p><code>% de mercado = tus pacientes/órdenes ÷ {datos['demanda_estimada_anual']:,.0f} órdenes/año estimadas × 100</code></p>"
        f"<p><code>Órdenes/año estimadas = población de {html.escape(datos['municipio'])} × {datos['tasa_acumulada']:g}% "
        "(tasa acumulada, misma fórmula y frecuencias de \"Valor de la zona\", con las 5 marcadas)</code></p>"
        "</div></details>"
        f'<details class="chart-toggle" style="margin-top:0.5rem;"><summary>Ver los {datos["total_laboratorios"]} laboratorios</summary>'
        '<div style="overflow-x:auto;max-height:300px;overflow-y:auto;"><table>'
        f"<tr><th>Nombre</th><th>Cadena</th><th>Colonia</th><th>Dirección</th></tr>{filas_lab}</table></div>"
        "</details>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note" style="margin-top:0.6rem;">Universo de competidores: barrido propio sobre Google Maps '
        "(3 rondas de búsqueda, septiembre 2026) — no es un directorio oficial de INEGI, puede no capturar el 100% de "
        "los laboratorios reales de la ciudad (estimación propia: 170-200). La demanda estimada es una proyección "
        "poblacional (no ventas reales de la industria), igual que en \"Valor de la zona\".</p>"
        "</details>"
        "</div>"
    )


MERCADO_LAB_MAPA_SCRIPT = """
<script>
(function () {
  var div = document.getElementById('mlab-mapa');
  if (!div || typeof L === 'undefined') return;
  var marcadores = JSON.parse(div.getAttribute('data-marcadores') || '[]');
  var maxZoom = parseInt(div.getAttribute('data-max-zoom'), 10) || 14;
  var tilesOk = div.getAttribute('data-tiles') === '1';

  var map = L.map(div).setView([32.52, -117.02], 11);
  if (tilesOk) {
    L.tileLayer('/tiles/{z}/{x}/{y}.png', {
      maxNativeZoom: maxZoom, maxZoom: 19, minZoom: 3,
      attribution: '&copy; colaboradores de OpenStreetMap',
    }).addTo(map);
  }

  var bounds = [];
  var registro = [];
  marcadores.forEach(function (lab) {
    var marker = L.circleMarker([lab.lat, lab.lon], {
      radius: lab.propia ? 8 : 5,
      color: '#fff', weight: 1.2,
      fillColor: lab.color,
      fillOpacity: lab.propia ? 0.95 : 0.8,
    }).addTo(map);
    marker.bindPopup(
      '<b>' + lab.nombre + '</b><div>' + lab.cadena + '</div>' +
      '<div style="color:#8a8f98;">' + lab.colonia + (lab.direccion ? ' — ' + lab.direccion : '') + '</div>'
    );
    bounds.push([lab.lat, lab.lon]);
    registro.push({ marker: marker, cadena: lab.cadena, lat: lab.lat, lon: lab.lon });
  });
  if (bounds.length) map.fitBounds(bounds, { padding: [20, 20] });

  // Filtro por cadena — pedido explícito: al hacer clic en una cadena del ranking, el mapa
  // solo muestra sus sucursales (el resto desaparece) y hace zoom a ellas; null/vacío restaura
  // todas. Se expone en window para que el script de la lista de cadenas (fuera de esta IIFE)
  // pueda llamarlo sin duplicar la referencia al mapa/marcadores.
  window.mlabFiltrarCadena = function (cadena) {
    var visibles = [];
    registro.forEach(function (r) {
      var mostrar = !cadena || r.cadena === cadena;
      if (mostrar) {
        if (!map.hasLayer(r.marker)) r.marker.addTo(map);
        visibles.push([r.lat, r.lon]);
      } else if (map.hasLayer(r.marker)) {
        map.removeLayer(r.marker);
      }
    });
    if (visibles.length) {
      map.fitBounds(visibles, { padding: [30, 30], maxZoom: 15 });
    } else if (bounds.length) {
      map.fitBounds(bounds, { padding: [20, 20] });
    }
  };
})();
</script>
"""


MERCADO_LAB_SCRIPT = """
<script>
(function () {
  var box = document.querySelector('.mlab-box');
  if (!box) return;
  var demandaEstimada = parseFloat(box.getAttribute('data-demanda-estimada')) || 0;

  function donutSvg(segments, size, stroke) {
    size = size || 190; stroke = stroke || 26;
    var r = (size - stroke) / 2, c = 2 * Math.PI * r, cx = size / 2, cy = size / 2;
    var total = segments.reduce(function (s, seg) { return s + seg.value; }, 0);
    var svg = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size +
      '" style="transform:rotate(-90deg);flex:none;">' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + r.toFixed(2) + '" fill="none" stroke="#88888022" stroke-width="' + stroke + '"/>';
    var offset = 0;
    if (total > 0) {
      segments.forEach(function (seg) {
        var frac = seg.value / total, dash = frac * c;
        if (dash > 0) {
          svg += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r.toFixed(2) + '" fill="none" stroke="' + seg.color +
            '" stroke-width="' + stroke + '" stroke-dasharray="' + dash.toFixed(2) + ' ' + Math.max(c - dash, 0).toFixed(2) +
            '" stroke-dashoffset="' + (-offset).toFixed(2) + '"/>';
          offset += dash;
        }
      });
    }
    return svg + '</svg>';
  }

  function pintarDona(holderClass, legendClass, pctClass, principal, total, etiquetaPrincipal, etiquetaResto, colorPrincipal) {
    var pct = total > 0 ? Math.min((principal / total) * 100, 100) : 0;
    var resto = Math.max(total - principal, 0);
    var segments = [
      { label: etiquetaPrincipal + ' (' + pct.toFixed(1) + '%)', value: principal, color: colorPrincipal },
      { label: etiquetaResto + ' (' + (100 - pct).toFixed(1) + '%)', value: resto, color: '#8f97a3' },
    ];
    var holder = box.querySelector(holderClass);
    holder.innerHTML = donutSvg(segments);
    box.querySelector(pctClass).textContent = pct.toFixed(1) + '%';
    var legend = box.querySelector(legendClass);
    legend.innerHTML = segments.map(function (seg) {
      return '<div class="legend-item"><span class="legend-dot" style="background:' + seg.color + ';"></span>' +
        '<span>' + seg.label + '</span><span class="legend-val">' + Math.round(seg.value).toLocaleString('es-MX') + '</span></div>';
    }).join('');
  }

  function recalcular() {
    var pacientes = parseFloat(box.querySelector('.mlab-pacientes').value) || 0;
    var objetivoPct = parseFloat(box.querySelector('.mlab-objetivo').value) || 0;

    // Dona 1: % de mercado que sí cubrimos (tus pacientes/órdenes vs demanda estimada).
    pintarDona('.mlab-pie-pacientes', '.mlab-legend-pacientes', '.mlab-pct-pacientes',
      pacientes, demandaEstimada, 'Tus pacientes/órdenes', 'Resto de la demanda estimada', '#2f9e6f');

    // Dona 2: la misma proporción pero al revés — lo que NO cubrimos como segmento principal
    // (en rojo, para que salte a la vista), pedido explícito del usuario junto a la de arriba.
    var faltanteMercado = Math.max(demandaEstimada - pacientes, 0);
    pintarDona('.mlab-pie-faltante', '.mlab-legend-faltante', '.mlab-pct-faltante',
      faltanteMercado, demandaEstimada, 'Demanda sin cubrir', 'Ya cubierto por nosotros', '#c0392b');

    // Dona 3: proyección — cuántas órdenes hacen falta para llegar al % de mercado objetivo
    // que el usuario escribe, comparado contra lo que ya tiene hoy.
    var ordenesObjetivo = demandaEstimada * (objetivoPct / 100);
    var yaTiene = Math.min(pacientes, ordenesObjetivo);
    var faltaObjetivo = Math.max(ordenesObjetivo - pacientes, 0);
    pintarDona('.mlab-pie-proyeccion', '.mlab-legend-proyeccion', '.mlab-pct-proyeccion',
      yaTiene, ordenesObjetivo, 'Ya tienes', 'Te faltan para el objetivo', '#3a7ca8');
    var totalObjetivo = box.querySelector('.mlab-total-objetivo');
    if (totalObjetivo) {
      totalObjetivo.textContent = 'Total de órdenes/año necesarias para el objetivo: ' +
        Math.round(ordenesObjetivo).toLocaleString('es-MX');
    }
  }

  box.querySelectorAll('input').forEach(function (input) {
    input.addEventListener('input', recalcular);
  });
  recalcular();
})();
</script>
<script>
(function () {
  // Clic en una cadena del ranking -> el mapa muestra solo sus sucursales (pedido explícito:
  // "que me puntee en el mapa directamente donde se encuentran las sucursales y me desaparezca
  // las demás"). Clic de nuevo en la misma, o en "Ver todas", restaura el mapa completo.
  var filas = document.querySelectorAll('.mlab-cadena-row');
  var resetBtn = document.querySelector('.mlab-reset-filtro');
  if (!filas.length) return;

  function limpiar() {
    filas.forEach(function (f) { f.classList.remove('activo'); });
    if (resetBtn) resetBtn.classList.remove('visible');
    if (typeof window.mlabFiltrarCadena === 'function') window.mlabFiltrarCadena(null);
  }

  filas.forEach(function (fila) {
    fila.addEventListener('click', function () {
      var cadena = fila.getAttribute('data-cadena');
      var yaActiva = fila.classList.contains('activo');
      limpiar();
      if (!yaActiva) {
        fila.classList.add('activo');
        if (resetBtn) resetBtn.classList.add('visible');
        if (typeof window.mlabFiltrarCadena === 'function') window.mlabFiltrarCadena(cadena);
      }
    });
  });
  if (resetBtn) resetBtn.addEventListener('click', limpiar);
})();
</script>
"""


EMPRESAS_PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI — Mercado de Empresas</title>
<style>
__ESTILO_COMPARTIDO__
  .emp-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0; }
  .emp-stat { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 0.9rem 1.2rem; }
  .emp-stat b { display: block; font-size: 1.5rem; color: var(--accent); }
  .emp-stat span { font-size: 0.78rem; color: var(--text-muted); }
  .emp-sector-dot { display: inline-block; width: 0.6rem; height: 0.6rem; border-radius: 50%; margin-right: 0.35rem; flex: none; }
  .emp-layout { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-start; margin-top: 1rem; }
  .emp-col-izq { flex: 2 1 480px; min-width: 300px; display: flex; flex-direction: column; gap: 1rem; }
  #emp-mapa { height: 420px; border-radius: 10px; border: 1px solid var(--border); }
  .emp-sectores-col { flex: 1 1 320px; min-width: 280px; }
  .emp-sector-row { cursor: pointer; border-radius: 8px; padding: 0.25rem 0.35rem; margin: 0 -0.35rem; transition: background 0.15s; }
  .emp-sector-row:hover { background: rgba(127,127,127,0.12); }
  .emp-sector-row.activo { background: var(--accent-soft); }
  .emp-top5-box { border: 1px solid var(--border); border-radius: 10px; padding: 1rem; background: var(--surface); }
  .emp-top5-box h4 { margin: 0 0 0.7rem; font-size: 0.92rem; }
  .emp-top5-item { display: flex; align-items: center; gap: 0.6rem; padding: 0.4rem 0; border-bottom: 1px dashed var(--border); font-size: 0.85rem; }
  .emp-top5-item:last-child { border-bottom: none; }
  .emp-top5-rank { flex: none; width: 1.6rem; height: 1.6rem; border-radius: 50%; background: var(--accent-soft); color: var(--accent); font-weight: 700; font-size: 0.78rem; display: flex; align-items: center; justify-content: center; }
  .emp-top5-nombre { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .emp-top5-empleados { flex: none; font-weight: 700; color: var(--accent); }
  .emp-reset-filtro { display: none; font-size: 0.78rem; margin: 0 0 0.6rem; background: none; border: 1px solid var(--border); border-radius: 6px; padding: 0.25rem 0.6rem; color: var(--text); cursor: pointer; }
  .emp-reset-filtro.visible { display: inline-block; }
</style>
</head>
<body>
<h1>Mercado de Empresas — nómina alta en Tijuana</h1>
<p class="subtitle"><a href="/">← Volver a la búsqueda normal</a> · 100% local · <a href="/logout">🔒 Cerrar sesión</a></p>
__RESULTADO__
<footer style="margin-top:2rem;color:var(--text-muted);font-size:0.78rem;text-align:center;">Fuentes: directorio de maquiladoras (catálogo propio) + DENUE-INEGI filtrado por personal ocupado, ambos combinados. Umbral: 101 empleados o más.</footer>
</body>
</html>
"""


def _colores_sectores_empresas(sectores: list[dict]) -> dict[str, str]:
    """Un color fijo por sector (mismo criterio que _colores_cadenas_mercado_lab): reutiliza la
    misma paleta, en el orden del ranking por empleados, para que los sectores más grandes
    obtengan los colores más distinguibles."""
    colores = {}
    for idx, s in enumerate(sectores):
        colores[s["sector"]] = PALETA_CADENAS_MERCADO_LAB[idx % len(PALETA_CADENAS_MERCADO_LAB)]
    return colores


def render_mercado_empresas() -> str:
    """Empresas/maquiladoras con nómina alta (101+ empleados) en Tijuana — a diferencia de
    hospitales/laboratorios, la mayoría de las filas no trae coordenadas (el directorio de
    maquiladoras no las publica), así que el análisis se apoya en el ranking por empleados y el
    desglose por sector; el mapa solo muestra las filas que sí tienen lat/lon (ver
    query_engine_local.analizar_empresas_nomina)."""
    datos = analizar_empresas_nomina()
    if datos["total_empresas"] == 0:
        return (
            '<p class="error">No hay empresas/maquiladoras cargadas — corre '
            "<code>python main_local.py run-etl</code> con el CSV en data/empresas_nomina/.</p>"
        )

    color_por_sector = _colores_sectores_empresas(datos["sectores"])
    maximo = datos["sectores"][0]["empleados"] if datos["sectores"] else 1
    filas_sectores = []
    for s in datos["sectores"][:15]:
        color = color_por_sector[s["sector"]]
        pct_barra = round((s["empleados"] / maximo) * 100, 1) if maximo else 0
        filas_sectores.append(
            f'<div class="bar-row-inline emp-sector-row" data-sector="{html.escape(s["sector"])}" '
            'title="Clic para ver el top 5 de empresas de este sector">'
            '<div class="bar-top">'
            f'<span class="bar-label"><span class="emp-sector-dot" style="background:{color};"></span>'
            f'{html.escape(s["sector"])} <span style="color:var(--text-muted);font-size:0.78rem;">'
            f'({s["empresas"]} empresa{"s" if s["empresas"] != 1 else ""})</span></span>'
            f'<span class="bar-value" style="color:{color};">{s["empleados"]:,} ({s["pct_empleados"]:g}%)</span>'
            "</div>"
            f'<span class="bar-track"><span class="bar-fill" style="width:{pct_barra}%;background:{color};"></span></span>'
            "</div>"
        )
    if len(datos["sectores"]) > 15:
        filas_sectores.append(
            f'<p class="nse-note">+{len(datos["sectores"]) - 15} sectores más con menos empleados.</p>'
        )

    def _fila_empresa(e: dict) -> str:
        empleados_txt = f"{e['empleados_estimados']:,}" if e["empleados_estimados"] is not None else "—"
        return (
            f"<tr><td>{html.escape(e['nombre'])}</td><td>{html.escape(e['sector'] or '')}</td>"
            f"<td>{html.escape(e['rango_personal'] or '')}</td><td>{empleados_txt}</td>"
            f"<td>{html.escape(e['colonia'] or '')}</td></tr>"
        )

    filas_empresas = "".join(_fila_empresa(e) for e in datos["empresas"])

    marcadores_json = json.dumps([
        {
            "nombre": e["nombre"], "sector": e["sector"] or "", "color": color_por_sector.get(e["sector"] or "", "#8f97a3"),
            "colonia": e["colonia"] or "", "direccion": e["direccion"] or "",
            "empleados": e["empleados_estimados"], "lat": e["lat"], "lon": e["lon"],
        }
        for e in datos["con_coordenadas"]
    ])

    # Top 5 general (sin filtro) — se manda ya renderizado desde el servidor para que la caja
    # no salga vacía sin JavaScript; el filtrado por sector (clic en el ranking) se hace en el
    # cliente con empresas_top5_json, que trae solo los 3 campos que necesita esa caja (no
    # el detalle completo de las 319 filas, ya servido en la tabla de abajo).
    def _item_top5(rank: int, e: dict) -> str:
        empleados_txt = f"{e['empleados_estimados']:,}" if e["empleados_estimados"] is not None else "—"
        return (
            '<div class="emp-top5-item">'
            f'<span class="emp-top5-rank">{rank}</span>'
            f'<span class="emp-top5-nombre" title="{html.escape(e["nombre"])}">{html.escape(e["nombre"])}</span>'
            f'<span class="emp-top5-empleados">{empleados_txt}</span>'
            "</div>"
        )

    top5_general_html = "".join(_item_top5(i, e) for i, e in enumerate(datos["empresas"][:5], start=1))
    empresas_top5_json = json.dumps([
        {"nombre": e["nombre"], "sector": e["sector"] or "Sin clasificar", "empleados": e["empleados_estimados"] or 0}
        for e in datos["empresas"]
    ])

    return (
        '<div class="emp-stats">'
        f'<div class="emp-stat"><b>{datos["total_empresas"]:,}</b><span>Empresas con 101+ empleados (Tijuana)</span></div>'
        f'<div class="emp-stat"><b>{datos["total_empleados_estimados"]:,.0f}</b><span>Empleados estimados en total</span></div>'
        f'<div class="emp-stat"><b>{len(datos["sectores"])}</b><span>Sectores/giros distintos</span></div>'
        f'<div class="emp-stat"><b>{len(datos["con_coordenadas"])}</b><span>Con ubicación geolocalizada</span></div>'
        "</div>"
        '<div class="emp-layout">'
        '<div class="emp-col-izq">'
        f'<div id="emp-mapa" data-tiles="{"1" if _comparar_mapa_disponible() else "0"}" '
        f'data-max-zoom="{TILE_MAX_ZOOM_DESCARGADO}" '
        f'data-marcadores="{_html_attr_escape_comparar(marcadores_json)}"></div>'
        f'<div class="emp-top5-box" data-empresas="{_html_attr_escape_comparar(empresas_top5_json)}">'
        '<h4 class="emp-top5-titulo">🏆 Top 5 empresas — general</h4>'
        '<div class="emp-top5-lista">' + top5_general_html + "</div>"
        "</div>"
        "</div>"
        '<div class="emp-sectores-col">'
        '<p class="donut-title" style="margin-top:0;">Empleados estimados por sector</p>'
        '<button type="button" class="emp-reset-filtro">✕ Ver ranking general</button>'
        f'{"".join(filas_sectores)}'
        "</div>"
        "</div>"
        '<details class="chart-toggle ver-mas"><summary>Ver más</summary>'
        '<p class="nse-note" style="margin-top:0.8rem;">Solo '
        f'{len(datos["con_coordenadas"])} de {datos["total_empresas"]} empresas tienen coordenadas '
        "(el directorio de maquiladoras no siempre las publica) — el mapa muestra únicamente esas; "
        "el ranking y el desglose por sector sí cubren el 100% de las filas.</p>"
        '<p class="nse-note" style="margin-top:0.6rem;">"Empleados (est.)" se extrae del texto de "rango de personal": '
        "cifra directa cuando el directorio la da, o el promedio del rango cuando viene estilo DENUE "
        '("101 a 250 personas"). Fuente: catálogo de maquiladoras + DENUE-INEGI, combinados por '
        "etl_local.py:load_empresas_nomina — no es volumen de nómina real, es una estimación a partir del rango publicado.</p>"
        "</details>"
        f'<details class="chart-toggle" style="margin-top:0.5rem;"><summary>Ver las {datos["total_empresas"]} empresas (ordenadas por empleados)</summary>'
        '<div style="overflow-x:auto;max-height:340px;overflow-y:auto;"><table>'
        f"<tr><th>Nombre</th><th>Sector</th><th>Rango de personal</th><th>Empleados (est.)</th><th>Colonia</th></tr>{filas_empresas}</table></div>"
        "</details>"
    )


EMPRESAS_MAPA_SCRIPT = """
<script>
(function () {
  var div = document.getElementById('emp-mapa');
  if (!div || typeof L === 'undefined') return;
  var marcadores = JSON.parse(div.getAttribute('data-marcadores') || '[]');
  var maxZoom = parseInt(div.getAttribute('data-max-zoom'), 10) || 14;
  var tilesOk = div.getAttribute('data-tiles') === '1';

  var map = L.map(div).setView([32.52, -117.02], 11);
  if (tilesOk) {
    L.tileLayer('/tiles/{z}/{x}/{y}.png', {
      maxNativeZoom: maxZoom, maxZoom: 19, minZoom: 3,
      attribution: '&copy; colaboradores de OpenStreetMap',
    }).addTo(map);
  }

  var bounds = [];
  marcadores.forEach(function (emp) {
    var marker = L.circleMarker([emp.lat, emp.lon], {
      radius: 6, color: '#fff', weight: 1.2,
      fillColor: emp.color, fillOpacity: 0.85,
    }).addTo(map);
    marker.bindPopup(
      '<b>' + emp.nombre + '</b><div>' + emp.sector + (emp.empleados ? ' — ~' + emp.empleados.toLocaleString('es-MX') + ' empleados' : '') + '</div>' +
      '<div style="color:#8a8f98;">' + emp.colonia + (emp.direccion ? ' — ' + emp.direccion : '') + '</div>'
    );
    bounds.push([emp.lat, emp.lon]);
  });
  if (bounds.length) map.fitBounds(bounds, { padding: [20, 20] });
})();
</script>
<script>
(function () {
  // Top 5 empresas interactivo: por defecto (sin clic) muestra el top 5 general; al hacer
  // clic en un sector del ranking de la derecha, filtra a las top 5 de ESE sector — misma
  // variante de interacción que el filtro por cadena de /mercado-laboratorios (clic = filtrar,
  // clic de nuevo o "Ver ranking general" = volver a mostrar todo).
  var caja = document.querySelector('.emp-top5-box');
  var filas = document.querySelectorAll('.emp-sector-row');
  var resetBtn = document.querySelector('.emp-reset-filtro');
  if (!caja || !filas.length) return;
  var empresas = JSON.parse(caja.getAttribute('data-empresas') || '[]');
  var titulo = caja.querySelector('.emp-top5-titulo');
  var lista = caja.querySelector('.emp-top5-lista');

  function pintarTop5(sector) {
    var filtradas = sector ? empresas.filter(function (e) { return e.sector === sector; }) : empresas.slice();
    filtradas.sort(function (a, b) { return b.empleados - a.empleados; });
    var top5 = filtradas.slice(0, 5);
    titulo.textContent = sector ? '🏆 Top 5 empresas — ' + sector : '🏆 Top 5 empresas — general';
    lista.innerHTML = top5.map(function (e, idx) {
      var empleadosTxt = e.empleados ? e.empleados.toLocaleString('es-MX') : '—';
      return '<div class="emp-top5-item"><span class="emp-top5-rank">' + (idx + 1) + '</span>' +
        '<span class="emp-top5-nombre" title="' + e.nombre + '">' + e.nombre + '</span>' +
        '<span class="emp-top5-empleados">' + empleadosTxt + '</span></div>';
    }).join('') || '<p class="nse-note">Sin empresas en este sector.</p>';
  }

  function limpiar() {
    filas.forEach(function (f) { f.classList.remove('activo'); });
    if (resetBtn) resetBtn.classList.remove('visible');
    pintarTop5(null);
  }

  filas.forEach(function (fila) {
    fila.addEventListener('click', function () {
      var sector = fila.getAttribute('data-sector');
      var yaActiva = fila.classList.contains('activo');
      filas.forEach(function (f) { f.classList.remove('activo'); });
      if (yaActiva) {
        if (resetBtn) resetBtn.classList.remove('visible');
        pintarTop5(null);
      } else {
        fila.classList.add('activo');
        if (resetBtn) resetBtn.classList.add('visible');
        pintarTop5(sector);
      }
    });
  });
  if (resetBtn) resetBtn.addEventListener('click', limpiar);
})();
</script>
"""


COMPARAR_MAPA_SCRIPT = r"""
<script>
(function () {
  var div = document.getElementById('comparar-mapa');
  if (!div || typeof L === 'undefined') return;
  var puntos = JSON.parse(div.getAttribute('data-puntos-iniciales') || '[]');
  var agebsIniciales = JSON.parse(div.getAttribute('data-agebs-iniciales') || '[]');
  var lugaresIniciales = JSON.parse(div.getAttribute('data-lugares-iniciales') || '[]');
  var maxZoom = parseInt(div.getAttribute('data-max-zoom'), 10) || 14;
  var map = L.map(div).setView(puntos.length ? [puntos[0].lat, puntos[0].lon] : [32.5027, -117.0037], puntos.length ? 12 : 9);
  L.tileLayer('/tiles/{z}/{x}/{y}.png', {
    maxNativeZoom: maxZoom, maxZoom: 19, minZoom: 3,
    attribution: '&copy; colaboradores de OpenStreetMap',
  }).addTo(map);

  var marcadores = []; // { marker, circle, radioKm } — zonas por punto+radio (clic en área vacía)
  var agebsSeleccionados = {}; // cve_geo -> capa geoJSON de ese polígono — zonas por clic directo en AGEB
  var lugares = []; // { valor, radioKm } — zonas tipeadas a mano (colonia/CP/AGEB/coordenadas), sin marcador en el mapa porque no se resuelven a lat/lon en el navegador

  function colorZona(i) {
    var paleta = ['#c0392b', '#2f6f4f', '#6f5a9a', '#b0546b', '#3a7ca8', '#c9973a'];
    return paleta[i % paleta.length];
  }

  function redibujar() {
    var lista = document.getElementById('lista-puntos');
    lista.innerHTML = '';
    var i = 0;
    marcadores.forEach(function (p) {
      var fila = document.createElement('div');
      fila.className = 'punto-row';
      var color = colorZona(i++);
      fila.innerHTML =
        '<span style="width:10px;height:10px;border-radius:50%;background:' + color + ';display:inline-block;flex:none;"></span>' +
        '<span class="punto-label">Punto (' + p.marker.getLatLng().lat.toFixed(4) + ', ' + p.marker.getLatLng().lng.toFixed(4) + ')</span>' +
        '<input type="text" value="' + p.radioKm + '" title="Radio en km">' +
        '<button type="button" title="Quitar">✕</button>';
      var input = fila.querySelector('input');
      input.addEventListener('change', function () {
        var val = parseFloat(input.value.replace(',', '.'));
        if (!isNaN(val) && val > 0) {
          p.radioKm = val;
          p.circle.setRadius(val * 1000);
        }
        actualizarBoton();
      });
      fila.querySelector('button').addEventListener('click', function () {
        map.removeLayer(p.marker);
        map.removeLayer(p.circle);
        marcadores.splice(marcadores.indexOf(p), 1);
        redibujar();
      });
      lista.appendChild(fila);
    });
    Object.keys(agebsSeleccionados).forEach(function (cveGeo) {
      var fila = document.createElement('div');
      fila.className = 'punto-row';
      var color = colorZona(i++);
      fila.innerHTML =
        '<span style="width:10px;height:10px;border-radius:2px;background:' + color + ';display:inline-block;flex:none;"></span>' +
        '<span class="punto-label">AGEB ' + cveGeo + '</span>' +
        '<button type="button" title="Quitar">✕</button>';
      fila.querySelector('button').addEventListener('click', function () {
        quitarAgeb(cveGeo);
      });
      lista.appendChild(fila);
    });
    lugares.forEach(function (lg) {
      var fila = document.createElement('div');
      fila.className = 'punto-row';
      var color = colorZona(i++);
      fila.innerHTML =
        '<span style="width:10px;height:10px;border-radius:50%;background:' + color + ';display:inline-block;flex:none;"></span>' +
        '<span class="punto-label" title="' + lg.valor.replace(/"/g, '&quot;') + '">' + lg.valor + ' (radio ' + lg.radioKm + ' km)</span>' +
        '<button type="button" title="Quitar">✕</button>';
      fila.querySelector('button').addEventListener('click', function () {
        lugares.splice(lugares.indexOf(lg), 1);
        redibujar();
      });
      lista.appendChild(fila);
    });
    actualizarBoton();
  }

  function actualizarBoton() {
    var btn = document.getElementById('btn-comparar');
    btn.disabled = (marcadores.length + Object.keys(agebsSeleccionados).length + lugares.length) < 1;
  }

  function agregarLugar(valor, radioKm) {
    valor = valor.trim();
    if (!valor) return;
    lugares.push({ valor: valor, radioKm: radioKm > 0 ? radioKm : 1 });
    redibujar();
  }

  function agregarPunto(lat, lon, radioKm) {
    var i = marcadores.length + Object.keys(agebsSeleccionados).length;
    var color = colorZona(i);
    var marker = L.marker([lat, lon], { draggable: true }).addTo(map);
    var circle = L.circle([lat, lon], {
      radius: radioKm * 1000, color: color, weight: 1.5, dashArray: '4 3',
      fillColor: color, fillOpacity: 0.08,
    }).addTo(map);
    marker.on('drag', function (ev) { circle.setLatLng(ev.target.getLatLng()); });
    marker.on('dragend', redibujar);
    marcadores.push({ marker: marker, circle: circle, radioKm: radioKm });
    redibujar();
  }

  // Estilo de un polígono de AGEB según si ya está seleccionado — mismo patrón de color que
  // los puntos, para que sea obvio que ambos tipos de zona cuentan igual en el análisis.
  var COLOR_AGEB_SELECCIONADO = '#c0392b';
  function estiloAgeb(feature) {
    var seleccionado = !!agebsSeleccionados[feature.properties.cve_geo];
    return {
      color: seleccionado ? '#ffffff' : '#8f97a3',
      weight: seleccionado ? 1.5 : 0.4,
      fillColor: seleccionado ? COLOR_AGEB_SELECCIONADO : '#3f6fb0',
      fillOpacity: seleccionado ? 0.55 : 0.03,
    };
  }

  function agregarAgeb(cveGeo, capaLayer) {
    if (agebsSeleccionados[cveGeo]) return;
    agebsSeleccionados[cveGeo] = capaLayer;
    capaLayer.setStyle(estiloAgeb(capaLayer.feature));
    redibujar();
  }

  function quitarAgeb(cveGeo) {
    var capaLayer = agebsSeleccionados[cveGeo];
    if (!capaLayer) return;
    delete agebsSeleccionados[cveGeo];
    capaLayer.setStyle(estiloAgeb(capaLayer.feature));
    redibujar();
  }

  // Capa de TODOS los AGEBs de Baja California, clicable — clic directo en un polígono lo
  // agrega/quita de la selección (más preciso que un radio cuando ya sabes qué colonia te
  // interesa); clic en área vacía (fuera de cualquier polígono) sigue agregando un punto+radio.
  fetch('/api/agebs.geojson').then(function (r) { return r.json(); }).then(function (geojson) {
    var capaAgebs = L.geoJSON(geojson, {
      style: estiloAgeb,
      onEachFeature: function (feature, layer) {
        layer.on('click', function (ev) {
          L.DomEvent.stopPropagation(ev);
          var cveGeo = feature.properties.cve_geo;
          if (agebsSeleccionados[cveGeo]) quitarAgeb(cveGeo);
          else agregarAgeb(cveGeo, layer);
        });
      },
    }).addTo(map);
    agebsIniciales.forEach(function (cveGeo) {
      capaAgebs.eachLayer(function (layer) {
        if (layer.feature.properties.cve_geo === cveGeo) agregarAgeb(cveGeo, layer);
      });
    });
  }).catch(function () { /* sin polígonos de fondo, el modo punto+radio sigue funcionando */ });

  map.on('click', function (ev) {
    agregarPunto(ev.latlng.lat, ev.latlng.lng, 1);
  });

  var RE_COORDENADAS = /^\s*(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/;
  // Si lo que se escribió ya es "lat,lon", se agrega como punto CON marcador+círculo en el
  // mapa (igual que si hubiera hecho clic ahí) — mucho más claro visualmente que dejarlo como
  // fila de texto sin ubicar. Colonia/CP/AGEB sí quedan como "lugar" (no hay forma de
  // ubicarlos en el mapa sin geocodificar del lado del servidor, solo se resuelven al analizar).
  function agregarValorComoZona(valor, radioKm) {
    valor = (valor || '').trim();
    if (!valor) return;
    var m = RE_COORDENADAS.exec(valor);
    if (m && Math.abs(parseFloat(m[1])) <= 90 && Math.abs(parseFloat(m[2])) <= 180) {
      agregarPunto(parseFloat(m[1]), parseFloat(m[2]), radioKm);
      map.panTo([parseFloat(m[1]), parseFloat(m[2])]);
    } else {
      agregarLugar(valor, radioKm);
    }
  }

  puntos.forEach(function (p) { agregarPunto(p.lat, p.lon, p.radioKm || 1); });
  lugaresIniciales.forEach(function (lg) { agregarValorComoZona(lg.valor, lg.radioKm || 1); });
  redibujar();

  document.getElementById('btn-agregar-lugar').addEventListener('click', function () {
    var valorInput = document.getElementById('lugar-valor');
    var radioInput = document.getElementById('lugar-radio');
    var radioKm = parseFloat((radioInput.value || '1').replace(',', '.'));
    if (isNaN(radioKm) || radioKm <= 0) radioKm = 1;
    agregarValorComoZona(valorInput.value, radioKm);
    valorInput.value = '';
  });
  document.getElementById('lugar-valor').addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter') { ev.preventDefault(); document.getElementById('btn-agregar-lugar').click(); }
  });

  document.getElementById('btn-comparar').addEventListener('click', function () {
    var partes = marcadores.map(function (p) {
      var ll = p.marker.getLatLng();
      return ll.lat.toFixed(6) + ',' + ll.lng.toFixed(6) + ',' + p.radioKm;
    });
    var agebs = Object.keys(agebsSeleccionados);
    var partesLugares = lugares.map(function (lg) { return lg.valor + '~' + lg.radioKm; });
    window.location.href = '/comparar?puntos=' + encodeURIComponent(partes.join('|')) +
      '&agebs=' + encodeURIComponent(agebs.join(',')) +
      '&lugares=' + encodeURIComponent(partesLugares.join('|'));
  });
})();
</script>
"""


def _comparar_mapa_disponible() -> bool:
    return _mapa_con_tiles_disponible()


def _html_attr_escape_comparar(s: str) -> str:
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


def _parsear_agebs_comparar(raw: str) -> list[str]:
    return [c.strip() for c in (raw or "").split(",") if c.strip()]


def _parsear_puntos_comparar(raw: str) -> list[tuple[float, float, float]]:
    """'lat,lon,radio|lat,lon,radio|...' -> [(lat, lon, radio_km), ...]. Filas inválidas se
    ignoran en silencio (mejor mostrar las zonas que sí se pudieron leer que tumbar toda la
    comparación por una fila mal formada)."""
    puntos = []
    for parte in (raw or "").split("|"):
        parte = parte.strip()
        if not parte:
            continue
        campos = parte.split(",")
        if len(campos) != 3:
            continue
        try:
            lat, lon, radio = float(campos[0]), float(campos[1]), float(campos[2])
        except ValueError:
            continue
        if radio > 0:
            puntos.append((lat, lon, radio))
    return puntos


def _unir_agebs_de_puntos(puntos: list[tuple[float, float, float]]) -> tuple[dict[str, dict], list[str]]:
    """Corre analizar_por_coordenada para cada (lat, lon, radio_km) y devuelve la UNIÓN de sus
    AGEBs (sin duplicar por cve_geo, ver totales_por_agebs) más la lista de errores de las
    zonas que no se pudieron calcular (no tumba las demás)."""
    cve_geos_union: dict[str, dict] = {}
    errores = []
    for i, (lat, lon, radio_km) in enumerate(puntos, start=1):
        try:
            _totals_i, agebs_i, _info = analizar_por_coordenada(lat, lon, radio_km=radio_km)
        except ZonaNoEncontradaError as e:
            errores.append(f"Zona {i} ({lat:.4f}, {lon:.4f}): {e}")
            continue
        for a in agebs_i:
            cve_geos_union[a["cve_geo"]] = a
    return cve_geos_union, errores


def _parsear_lugares_comparar(raw: str) -> list[tuple[str, float]]:
    """'valor~radio|valor~radio|...' -> [(valor, radio_km), ...] — para las zonas que el
    usuario tipea a mano (colonia, CP, AGEB o "lat,lon") en vez de marcarlas en el mapa, misma
    idea que el campo de búsqueda principal pero acumulable. '~' y '|' son separadores poco
    probables en un nombre de colonia real; si alguno los llegara a traer, esa entrada
    simplemente no matchea nada y se ignora en vez de romper las demás."""
    lugares = []
    for parte in (raw or "").split("|"):
        parte = parte.strip()
        if not parte:
            continue
        valor, _sep, radio_str = parte.rpartition("~")
        if not valor:
            continue
        try:
            radio_km = float(radio_str) if radio_str else 1.0
        except ValueError:
            radio_km = 1.0
        if radio_km > 0:
            lugares.append((valor, radio_km))
    return lugares


def _unir_agebs_de_lugares(lugares: list[tuple[str, float]]) -> tuple[dict[str, dict], list[str]]:
    """Como _unir_agebs_de_puntos pero para zonas tipeadas a mano (colonia/CP/AGEB/coordenadas)
    — detecta el tipo con la misma heurística del buscador principal (_detectar_tipo) y
    resuelve cada una con analizar_locacion/analizar_por_coordenada según corresponda."""
    cve_geos_union: dict[str, dict] = {}
    errores = []
    for valor, radio_km in lugares:
        tipo = _detectar_tipo(valor)
        try:
            if tipo == "Coordenadas":
                m = _RE_COORDENADAS.match(valor.strip())
                lat, lon = float(m.group(1)), float(m.group(2))
                _totals_i, agebs_i, _info = analizar_por_coordenada(lat, lon, radio_km=radio_km)
            else:
                _totals_i, agebs_i, _zt, _zu = analizar_locacion(tipo, valor, radio_km=radio_km)
        except (ZonaNoEncontradaError, ValueError) as e:
            errores.append(f'"{valor}": {e}')
            continue
        for a in agebs_i:
            cve_geos_union[a["cve_geo"]] = a
    return cve_geos_union, errores


def render_zonas_combinadas(
    puntos: list[tuple[float, float, float]], agebs_directos: list[str] | None = None,
    lugares: list[tuple[str, float]] | None = None, capa: str = "nse",
) -> str:
    """Fusiona varias zonas en UN SOLO análisis agregado — no una comparación lado a lado, sino
    "enriquecer" la consulta con más colonias/ubicaciones, como pidió el usuario: elegir una
    zona base y poder ir sumando más para que el reporte (población, NSE, comercios, salud,
    etc.) refleje el conjunto completo. Tres formas de agregar zonas, combinables entre sí:
    puntos (lat, lon, radio_km) del clic-en-área-vacía, agebs_directos (cve_geo) del clic
    directo sobre un polígono ya dibujado, y lugares (texto: colonia/CP/AGEB/coordenadas +
    radio) para quien prefiera escribir en vez de usar el mapa, con más precisión que estimar
    un punto a ojo. Reutiliza _cuerpo_reporte_html para no duplicar la lógica de tarjetas con
    render_resultado."""
    if not puntos and not agebs_directos and not lugares:
        return ""

    cve_geos_union, errores = _unir_agebs_de_puntos(puntos) if puntos else ({}, [])
    for cve_geo in (agebs_directos or []):
        cve_geos_union.setdefault(cve_geo, None)
    if lugares:
        cve_geos_lugares, errores_lugares = _unir_agebs_de_lugares(lugares)
        cve_geos_union.update(cve_geos_lugares)
        errores += errores_lugares
    if not cve_geos_union:
        mensaje = "No se pudo calcular ninguna zona."
        if errores:
            mensaje += " " + " ".join(errores)
        return f'<p class="error">{html.escape(mensaje)}</p>'

    totals, agebs = totales_por_agebs(list(cve_geos_union.keys()))
    zonas_todas = [
        {"id": i, "cp": None, "colonia": f"Zona {i} (radio {radio_km:g} km)", "lat": lat, "lon": lon}
        for i, (lat, lon, radio_km) in enumerate(puntos, start=1)
    ]
    n_zonas = len(puntos) + len(agebs_directos or []) + len(lugares or [])

    badge = f"{n_zonas} zonas combinadas · {len(agebs)} AGEBs"
    parts = [
        '<div class="result-header">'
        f"<h2>Análisis combinado: {n_zonas} zonas</h2>"
        f'<span class="badge">{html.escape(badge)}</span>'
        "</div>"
    ]
    if errores:
        parts.append(f'<p class="error">{html.escape(" ".join(errores))}</p>')

    # Aviso de AGEBs "outlier": si alguno quedó muy lejos del centro de masa del resto del
    # grupo (ej. un clic accidental, o un radio que alcanzó a incluir algo de otra colonia),
    # es fácil que pase desapercibido en un análisis de varias zonas combinadas — se avisa en
    # vez de dejar que contamine el reporte en silencio (fue justo lo que reportó el usuario:
    # un laboratorio de una colonia ajena apareciendo sin explicación).
    if len(agebs) > 1:
        centroides = centroides_por_agebs([a["cve_geo"] for a in agebs])
        puntos_centroide = list(centroides.values())
        if puntos_centroide:
            lon_medio = sum(p[0] for p in puntos_centroide) / len(puntos_centroide)
            lat_medio = sum(p[1] for p in puntos_centroide) / len(puntos_centroide)
            distancias = {
                cve: haversine_km(lat_medio, lon_medio, lat, lon)
                for cve, (lon, lat) in centroides.items()
            }
            dists_ordenadas = sorted(distancias.values())
            mediana = dists_ordenadas[len(dists_ordenadas) // 2]
            umbral = max(5.0, mediana * 3)
            outliers = sorted(
                (cve for cve, d in distancias.items() if d > umbral),
                key=lambda cve: -distancias[cve],
            )
            if outliers:
                lista_outliers = ", ".join(f"{cve} (~{distancias[cve]:.1f} km del centro del grupo)" for cve in outliers)
                parts.append(
                    '<p class="error">⚠ '
                    f"{len(outliers)} AGEB(s) quedaron mucho más lejos del resto del grupo que lo esperado — "
                    "revisa si fue un clic o radio accidental antes de sacar conclusiones: "
                    f"{html.escape(lista_outliers)}.</p>"
                )

    colonias = colonias_para_agebs([a["cve_geo"] for a in agebs])
    if colonias:
        # Algunas fuentes (ej. colonias_tijuana_sepomex.geojson) guardan varias colonias que
        # comparten un mismo polígono de CP como un solo string separado por comas — hay que
        # partirlo también, si no el dedup por nombre completo no agarra los repetidos.
        nombres_colonia = sorted({
            pedazo.strip()
            for c in colonias if c["colonia"]
            for pedazo in c["colonia"].split(",")
            if pedazo.strip()
        })
        parts.append(
            '<div class="zonas-box">'
            f"<p>Se está realizando el análisis con {n_zonas} zona(s) combinada(s) en las cuales "
            "se engloban las siguientes colonias:</p>"
            f"<p>{html.escape(', '.join(nombres_colonia))}</p>"
            "</div>"
        )

    query_export = (
        "puntos=" + urllib.parse.quote("|".join(f"{lat:.6f},{lon:.6f},{radio_km:g}" for lat, lon, radio_km in puntos))
        + "&agebs=" + urllib.parse.quote(",".join(agebs_directos or []))
        + "&lugares=" + urllib.parse.quote("|".join(f"{v}~{r:g}" for v, r in (lugares or [])))
    )
    parts.append(
        f'<div class="export-bar"><a class="secondary-link" href="/comparar/export.xlsx?{query_export}">'
        "⬇ Descargar Excel (.xlsx)</a></div>"
    )

    rings_por_ageb, cve_incluidos = geometria_para_mapa(agebs)
    if rings_por_ageb:
        capa_activa = capa if capa in CAPAS_MAPA else "nse"
        valores_capa = capa_por_ageb(list(cve_incluidos), capa_activa)
        paleta_capa = MARGINACION_COLOR if capa_activa == "marginacion" else NSE_COLOR
        colores_por_ageb = {cve: paleta_capa.get(info["nivel"], "#3f6fb0") for cve, info in valores_capa.items()}
        nse_mapa = estimar_nivel_socioeconomico(totals)
        color_zona = NSE_COLOR.get(nse_mapa["nivel"], "#3f6fb0") if nse_mapa else "#3f6fb0"
        zonas_activas_ids = {z["id"] for z in zonas_todas}
        # radio_km=None: cada zona trae su propio radio (no uno compartido) — el círculo único
        # que dibuja render_mapa_leaflet/render_mapa asume un solo radio para todas, así que
        # aquí se omite y basta con los marcadores para ubicar cada punto agregado.
        if _mapa_con_tiles_disponible():
            mapa_html = render_mapa_leaflet(
                rings_por_ageb, cve_incluidos, zonas_todas, zonas_activas_ids, None,
                color_incluido=color_zona, colores_por_ageb=colores_por_ageb,
            )
            hint = "Arrastra para mover · rueda para zoom"
        else:
            mapa_html = render_mapa(
                rings_por_ageb, cve_incluidos, zonas_todas, zonas_activas_ids, None,
                color_incluido=color_zona, colores_por_ageb=colores_por_ageb,
            )
            hint = "Arrastra para mover · Ctrl/Cmd + rueda para zoom"
        leyenda = leyenda_mapa_nse(
            len(cve_incluidos), len(rings_por_ageb) - len(cve_incluidos), None, color_zona,
            capa_etiqueta=CAPAS_MAPA[capa_activa], paleta=paleta_capa,
        )
        parts.append(
            '<details class="audit mapa-details" open>'
            "<summary>Ver mapa de Baja California</summary>"
            '<div class="mapa-toolbar">'
            f'<span class="mapa-hint">{hint}</span>'
            '<span class="mapa-toolbar-btns">'
            '<button type="button" class="mapa-centrar secondary">Centrar en zona</button>'
            '<button type="button" class="mapa-completa secondary">Ver Baja California completa</button>'
            "</span>"
            "</div>"
            f'<div class="mapa-wrap">{mapa_html}</div>'
            f'<div class="mapa-leyenda">{leyenda}</div>'
            "</details>"
        )

    parts.append(_cuerpo_reporte_html(totals, agebs))
    return "".join(parts)


def render_resultado(
    tipo: str, valor: str, radio: str = "", zona_ids: list[str] | None = None,
    nse_filtro: set[str] | None = None, municipio_cve: str = "", capa: str = "nse",
    link_out: dict | None = None,
) -> str:
    if not valor:
        return ""
    # municipio_cve solo restringe búsquedas por texto (Colonia/CP/AGEB) a un municipio ya
    # elegido en el selector — para tipo == "Municipio" no aplica (valor YA es la clave del
    # municipio que se está resumiendo completo).
    municipio_nombre = MUNICIPIOS_BC.get(municipio_cve) if (municipio_cve and tipo != "Municipio") else None
    try:
        r = _resolver_consulta(tipo, valor, radio, zona_ids, nse_filtro, municipio_nombre)
    except _ErrorConsulta as e:
        return str(e)

    tipo, valor, valor_original, radio = r["tipo"], r["valor"], r["valor_original"], r["radio"]
    radio_km, totals, agebs = r["radio_km"], r["totals"], r["agebs"]
    agebs_pre_filtro, zonas_todas, zonas_usadas = r["agebs_pre_filtro"], r["zonas_todas"], r["zonas_usadas"]
    if link_out is not None:
        # Para que el botón "Combinar con otras zonas de flujo" en el header lleve YA puesta
        # la ubicación actual (en vez de mandar a un mapa vacío) — ver do_GET, que arma
        # comparar_href con esto. lat/lon viene directo solo en tipo Coordenadas; para
        # Colonia/CP/AGEB se aproxima con el centro de las zonas usadas (Municipio no trae
        # zonas con lat/lon, ahí queda sin prefill).
        lat_link, lon_link = r["lat"], r["lon"]
        if lat_link is None and zonas_usadas:
            lat_link = sum(z["lat"] for z in zonas_usadas) / len(zonas_usadas)
            lon_link = sum(z["lon"] for z in zonas_usadas) / len(zonas_usadas)
        if lat_link is not None:
            link_out["lat"], link_out["lon"] = lat_link, lon_link
            link_out["radio"] = radio_km or 1
    filtro_nse_activo, colonias_filtradas = r["filtro_nse_activo"], r["colonias_filtradas"]
    lat, lon, info_punto = r["lat"], r["lon"], r["info_punto"]

    badge = f"radio {html.escape(radio)} km · {len(agebs)} AGEBs" if radio_km else f"{len(agebs)} AGEBs"
    if filtro_nse_activo:
        badge += f" (de {len(agebs_pre_filtro)} sin filtrar)"
    parts = [
        '<div class="result-header">'
        f'<h2>{html.escape(tipo)}: "{html.escape(valor)}"</h2>'
        f'<span class="badge">{badge}</span>'
        "</div>"
    ]

    if tipo == "Municipio":
        parts.append(_intercensal_2025_html(valor_original))

    if not radio_km and agebs:
        # Sin --radio explícito (colonia/CP/AGEB tal cual, sin agregar un área alrededor),
        # igual conviene dar una noción de qué tan grande es la zona resultante — sobre todo
        # cuando son varios AGEBs (una colonia grande, un municipio filtrado por NSE).
        radio_equiv = estimar_radio_equivalente_km([a["cve_geo"] for a in agebs])
        if radio_equiv is not None:
            parts.append(
                f'<p class="radio-equivalente">📏 Radio equivalente aproximado: <strong>{radio_equiv:.2f} km</strong> '
                "(si esta zona fuera un círculo del mismo tamaño — es una noción de escala, "
                "no un radio de búsqueda real; la forma real casi nunca es circular).</p>"
            )

    if agebs:
        query_export = _query_string_actual(tipo, valor_original, radio, nse_filtro, municipio_cve)
        parts.append(f'<div class="export-bar"><a class="secondary-link" href="/export.xlsx?{query_export}">'
                      '⬇ Descargar Excel (.xlsx)</a></div>')

    if len(agebs_pre_filtro) > 1:
        parts.append(_filtro_nse_html(tipo, valor_original, radio, nse_filtro or set(NIVELES_NSE), municipio_cve))

    if filtro_nse_activo and not agebs:
        parts.append(
            '<p class="error">Ningún AGEB de esta consulta cae en el nivel socioeconómico '
            "filtrado — prueba con otro nivel.</p>"
        )
        return "".join(parts)

    if filtro_nse_activo and colonias_filtradas:
        parts.append(_colonias_filtradas_html(colonias_filtradas))

    if tipo == "Coordenadas":
        parts.append(_punto_info_html(lat, lon, info_punto))
    elif zonas_todas:
        parts.append(_zonas_form_html(valor, radio, zonas_todas, zonas_usadas))

    if agebs:
        rings_por_ageb, cve_incluidos = geometria_para_mapa(agebs)
        if rings_por_ageb:
            zonas_activas_ids = {z["id"] for z in zonas_usadas}
            hint_marcadores = (
                " · clic en un punto para incluir/excluir esa zona (recalcula al instante)"
                if zonas_todas and tipo != "Coordenadas" else ""
            )
            # Cada AGEB se pinta de SU PROPIO valor en la variable elegida (NSE por defecto,
            # o marginación/densidad/carencias vía el selector "capa" — mapa de calor real,
            # uno por AGEB en vez del promedio de toda la zona) — así el mapa comunica de un
            # vistazo qué partes de la zona consultada son más altas o más bajas, útil sobre
            # todo con selecciones grandes (municipio completo, radio amplio) donde un solo
            # color promedio escondería esa variación interna.
            capa_activa = capa if capa in CAPAS_MAPA else "nse"
            valores_capa = capa_por_ageb(list(cve_incluidos), capa_activa)
            paleta_capa = MARGINACION_COLOR if capa_activa == "marginacion" else NSE_COLOR
            colores_por_ageb = {cve: paleta_capa.get(info["nivel"], "#3f6fb0") for cve, info in valores_capa.items()}
            nse_mapa = estimar_nivel_socioeconomico(totals)
            color_zona = NSE_COLOR.get(nse_mapa["nivel"], "#3f6fb0") if nse_mapa else "#3f6fb0"
            if _mapa_con_tiles_disponible():
                # Assets descargados (ver local_engine/setup_mapa.py): mapa con tiles reales
                # de calles/relieve (Leaflet), servidos 100% desde disco.
                mapa_html = render_mapa_leaflet(
                    rings_por_ageb, cve_incluidos, zonas_todas, zonas_activas_ids, radio_km,
                    color_incluido=color_zona, colores_por_ageb=colores_por_ageb,
                )
                hint = "Arrastra para mover · rueda para zoom" + hint_marcadores
            else:
                # Respaldo: mapa vectorial propio, sin tiles ni internet (funciona siempre,
                # incluso sin correr 'setup-mapa').
                mapa_html = render_mapa(
                    rings_por_ageb, cve_incluidos, zonas_todas, zonas_activas_ids, radio_km,
                    color_incluido=color_zona, colores_por_ageb=colores_por_ageb,
                )
                hint = "Arrastra para mover · Ctrl/Cmd + rueda para zoom" + hint_marcadores
            leyenda = leyenda_mapa_nse(
                len(cve_incluidos), len(rings_por_ageb) - len(cve_incluidos), radio_km, color_zona,
                capa_etiqueta=CAPAS_MAPA[capa_activa], paleta=paleta_capa,
            )
            parts.append(
                '<details class="audit mapa-details" open>'
                "<summary>Ver mapa de Baja California</summary>"
                '<div class="mapa-toolbar">'
                f'<span class="mapa-hint">{hint}</span>'
                '<span class="mapa-toolbar-btns">'
                '<button type="button" class="mapa-centrar secondary">Centrar en zona</button>'
                '<button type="button" class="mapa-completa secondary">Ver Baja California completa</button>'
                "</span>"
                "</div>"
                f'<div class="mapa-wrap">{mapa_html}</div>'
                f'<div class="mapa-leyenda">{leyenda}</div>'
                "</details>"
            )

    parts.append(_cuerpo_reporte_html(totals, agebs))
    return "".join(parts)


def _cuerpo_reporte_html(totals: dict[str, float], agebs: list[dict]) -> str:
    """Grid de categorías (Vivienda/Población/Educación/Salud, con NSE/marginación/comercios/
    DENUE embebidos) + tabla de auditoría de AGEBs — la parte de un reporte que NO depende de
    qué tipo de búsqueda lo generó (Colonia/CP/Coordenada/Municipio/zonas combinadas), así que
    se comparte entre render_resultado y render_zonas_combinadas en vez de duplicarla."""
    parts = ['<div class="grid">']
    for categoria, variables in CATEGORIAS.items():
        color = CATEGORIA_COLOR.get(categoria, "#2f5496")
        titulo = CATEGORIA_LABELS.get(categoria, categoria.replace("_", " / "))
        parts.append(
            '<div class="card"><div class="card-head">'
            f'<h3><span class="dot" style="background:{color};"></span>{html.escape(titulo)}</h3>'
            '<details class="chart-toggle"><summary>Gráfico</summary>'
            f'<div class="chart-panel">{_grafico_categoria(categoria, totals)}</div>'
            "</details>"
            "</div>"
        )
        parts.append(_bar_chart(variables, totals, color))
        if categoria == "Educacion_Socioeconomico":
            parts.append(_marginacion_html(agebs))
            parts.append(_nse_html(totals))
            parts.append(_poder_adquisitivo_html(totals))
            parts.append(_comercios_html(agebs))
            parts.append(_empresas_zona_html(agebs))
        elif categoria == "Salud":
            parts.append(_denue_html(agebs))
            parts.append(_esep_html(agebs))
            parts.append(_hospitales_cardio_html(agebs))
            parts.append(_laboratorios_zona_html(agebs))
        parts.append("</div>")
    retorno_html = _retorno_html(totals)
    if retorno_html:
        parts.append(
            '<div class="card retorno-card"><div class="card-head">'
            '<h3><span class="dot" style="background:#2f9e6f;"></span>Valor de la zona</h3>'
            "</div>"
            f"{retorno_html}"
            "</div>"
        )
    parts.append("</div>")

    if agebs:
        parts.append(
            f'<details class="audit"><summary>Ver los {len(agebs)} AGEBs incluidos '
            f"(para auditar contra INEGI)</summary>"
            '<table><tr><th>Clave AGEB</th><th>Clave completa (cve_geo)</th><th>Población total</th></tr>'
        )
        for ageb in sorted(agebs, key=lambda a: a["cve_geo"]):
            parts.append(
                f"<tr><td>{html.escape(ageb['cve_ageb'])}</td>"
                f"<td>{html.escape(ageb['cve_geo'])}</td>"
                f"<td>{round(ageb['pobtot'], 2)}</td></tr>"
            )
        parts.append("</table></details>")

    return "".join(parts)


def _mapa_con_tiles_disponible() -> bool:
    """True si ya se corrió 'python main_local.py setup-mapa' (Leaflet.js/CSS descargados).
    No exige que haya tiles: sin tiles el mapa igual funciona (fondo en blanco con los
    polígonos encima), y así el usuario ve de inmediato si le faltó terminar la descarga."""
    return (STATIC_DIR / "leaflet.js").exists() and (STATIC_DIR / "leaflet.css").exists()


def _municipio_selector_html(seleccionado: str) -> str:
    """<select> de municipio, parte del form.search principal (un solo submit): vacío + sin
    texto -> mapa de todo el estado; un municipio + sin texto -> resumen de esa ciudad
    completa (analizar_municipio); un municipio + texto -> busca la colonia/CP/AGEB SOLO
    dentro de ese municipio en vez de en los 7 a la vez (ver render_resultado/municipio_cve)."""
    opciones = ['<option value="">Todos los municipios</option>']
    for cve_mun, nombre in MUNICIPIOS_BC.items():
        sel = " selected" if cve_mun == seleccionado else ""
        # San Felipe (007) se creó en 2021, después del Censo 2020 — INEGI todavía no
        # publica censo tabulado para este municipio nuevo (ver analizar_municipio()).
        # Se marca en la etiqueta para que se note antes de hacer clic, no solo al fallar.
        etiqueta = f"{html.escape(nombre)} (sin censo 2020 aún)" if cve_mun == "007" else html.escape(nombre)
        opciones.append(f'<option value="{cve_mun}"{sel}>{etiqueta}</option>')
    return (
        '<select name="municipio" '
        'onchange="this.form.elements[\'valor\'].value=\'\'; this.form.requestSubmit()" '
        'title="Municipio (filtra la búsqueda o, sin texto, resume la ciudad completa). '
        'San Felipe se creó en 2021, después del Censo 2020: INEGI aún no publica censo '
        'tabulado para ese municipio nuevo (esa población sigue contada dentro de Mexicali).">'
        f'{"".join(opciones)}</select>'
    )


def _capa_selector_html(seleccionada: str) -> str:
    """<select> de qué variable colorea cada AGEB en el mapa (mapa de calor) — parte del
    mismo form.search principal, así que auto-envía junto con valor/municipio/radio ya
    puestos. 'nse' es el default (nivel socioeconómico, como ya funcionaba)."""
    opciones = []
    for clave, etiqueta in CAPAS_MAPA.items():
        sel = " selected" if clave == seleccionada else ""
        opciones.append(f'<option value="{clave}"{sel}>{html.escape(etiqueta)}</option>')
    return (
        '<select name="capa" onchange="this.form.requestSubmit()" '
        'title="Variable que colorea el mapa (mapa de calor)">'
        f'{"".join(opciones)}</select>'
    )


def _guardados_html(destino: str, qs_actual: str) -> str:
    """Caja de "lugares/análisis guardados": lista los guardados para ESTE destino (búsqueda
    normal "/" o zonas combinadas "/comparar" — cada uno guarda su propia lista porque la
    query string de uno no sirve para el otro) + un formulario para guardar la consulta que
    se está viendo ahora mismo (qs_actual = la query string actual, tal cual, para poder
    reabrir exactamente lo mismo con un clic más adelante)."""
    guardados = [g for g in listar_analisis_guardados() if g["destino"] == destino]
    items = []
    for g in guardados:
        volver = urllib.parse.quote(f"{destino}?{qs_actual}" if qs_actual else destino)
        resumen_bits = []
        if g.get("resumen_poblacion"):
            resumen_bits.append(f'<span class="guardados-resumen-item">👥 {html.escape(g["resumen_poblacion"])}</span>')
        if g.get("resumen_valor"):
            resumen_bits.append(f'<span class="guardados-resumen-item">💰 {html.escape(g["resumen_valor"])}</span>')
        resumen_html = f'<div class="guardados-resumen">{"".join(resumen_bits)}</div>' if resumen_bits else ""
        items.append(
            '<li class="guardados-item">'
            '<div class="guardados-item-linea">'
            f'<a href="{html.escape(destino)}?{html.escape(g["query_string"])}">{html.escape(g["nombre"])}</a>'
            f'<span class="guardados-fecha">{html.escape(g["creado_en"])}</span>'
            f'<a class="guardados-del" href="/eliminar-guardado?id={g["id"]}&volver={volver}" '
            f'title="Eliminar" onclick="return confirm(\'¿Eliminar {html.escape(g["nombre"])}?\')">✕</a>'
            "</div>"
            f"{resumen_html}"
            "</li>"
        )
    lista_html = f'<ul class="guardados-list">{"".join(items)}</ul>' if items else '<p class="nse-note">Todavía no tienes nada guardado aquí.</p>'

    # Solo en /comparar tiene sentido capturar un snapshot de "Valor de la zona" (población +
    # representación de mercado / órdenes anuales): ahí depende de inputs manuales que la
    # query string no guarda (pacientes actuales, frecuencias marcadas) — sin el snapshot la
    # lista no diría nada de esos números sin reabrir cada uno. Los campos ocultos los llena
    # RETORNO_CLIENTES_SCRIPT justo antes de enviar el formulario, leyendo del propio panel.
    campos_resumen = (
        '<input type="hidden" name="resumen_poblacion" class="guardar-resumen-poblacion">'
        '<input type="hidden" name="resumen_valor" class="guardar-resumen-valor">'
        if destino == "/comparar" else ""
    )

    return (
        '<details class="guardados-box">'
        f"<summary>📍 Lugares guardados ({len(guardados)})</summary>"
        f"{lista_html}"
        '<form class="guardar-form" method="get" action="/guardar">'
        f'<input type="hidden" name="destino" value="{html.escape(destino)}">'
        f'<input type="hidden" name="qs" value="{html.escape(qs_actual)}">'
        f"{campos_resumen}"
        '<input type="text" name="nombre" placeholder="Nombre para guardar la consulta actual" required maxlength="120">'
        "<button type=\"submit\">💾 Guardar consulta actual</button>"
        "</form>"
        "</details>"
    )


def _mapa_inicial_html() -> str:
    """Mapa de toda Baja California SIN ninguna zona resaltada, para que la página muestre
    algo desde la primera carga (antes de buscar nada) en vez de quedar en blanco."""
    todos = rings_municipio()
    if not todos:
        return ""
    if _mapa_con_tiles_disponible():
        mapa_html = render_mapa_leaflet(todos, set(), [], set(), None)
    else:
        mapa_html = render_mapa(todos, set(), [], set(), None)
    return (
        '<details class="audit mapa-details" open>'
        "<summary>Mapa de Baja California</summary>"
        '<div class="mapa-toolbar">'
        '<span class="mapa-hint">Busca una zona o elige un municipio arriba para analizarlo.</span>'
        "</div>"
        f'<div class="mapa-wrap">{mapa_html}</div>'
        "</details>"
    )


_STATIC_CONTENT_TYPES = {".js": "text/javascript", ".css": "text/css", ".png": "image/png"}


LOGIN_PAGE_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agente INEGI — Acceso</title>
<style>
__ESTILO_COMPARTIDO__
  body { max-width: none; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 1.5rem; }
  .login-card { width: 100%; max-width: 380px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 2rem 1.75rem; }
  .login-card h1 { font-size: 1.3rem; margin-bottom: 0.3rem; }
  .login-card .subtitle { margin-bottom: 1.5rem; }
  .login-card label { display: block; font-size: 0.82rem; font-weight: 600; color: var(--text-muted); margin-bottom: 0.35rem; }
  .login-card input[type=password] { width: 100%; padding: 0.6rem 0.75rem; font-size: 1rem; border: 1px solid var(--border); border-radius: 6px; background: var(--bg); color: var(--text); margin-bottom: 1rem; }
  .login-card button { width: 100%; padding: 0.7rem; font-size: 1rem; }
  .login-card .error { margin-bottom: 1rem; }
</style>
</head>
<body>
<div class="login-card">
  <h1>Agente INEGI</h1>
  <p class="subtitle">Baja California · Censo 2020 · 100% local, sin conexión a internet</p>
  __ERROR__
  <form method="post" action="/login">
    <input type="hidden" name="next" value="__NEXT__">
    <label for="password">Contraseña de acceso</label>
    <input type="password" id="password" name="password" autofocus required>
    <button type="submit">Entrar</button>
  </form>
</div>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        logger.info("%s - %s", self.address_string(), format % args)

    def _autenticado(self) -> bool:
        return sesion_valida(self.headers.get("Cookie"))

    def _redirigir_a_login(self, next_path: str) -> None:
        destino = "/login"
        if next_path and next_path != "/":
            destino += "?next=" + urllib.parse.quote(next_path, safe="")
        self.send_response(302)
        self.send_header("Location", destino)
        self.end_headers()

    def _handle_login_get(self, params: dict) -> None:
        next_path = params.get("next", ["/"])[0] or "/"
        error_html = (
            '<p class="error">Contraseña incorrecta — intenta de nuevo.</p>'
            if params.get("error") == ["1"] else ""
        )
        body = (
            LOGIN_PAGE_TEMPLATE
            .replace("__ESTILO_COMPARTIDO__", SHARED_STYLE_BLOCK_RAW)
            .replace("__ERROR__", error_html)
            .replace("__NEXT__", html.escape(next_path))
        )
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _handle_login_post(self, params: dict) -> None:
        intentada = params.get("password", [""])[0]
        next_path = params.get("next", ["/"])[0] or "/"
        if not next_path.startswith("/"):
            # Nunca redirigir fuera del propio servidor (un "next" manipulado con una URL
            # externa sería un open-redirect) — si no empieza con "/", se ignora y va a "/".
            next_path = "/"
        if password_correcta(intentada):
            token = crear_sesion()
            self.send_response(302)
            self.send_header("Location", next_path)
            self.send_header(
                "Set-Cookie", f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Lax"
            )
            self.end_headers()
            return
        destino = "/login?error=1"
        if next_path != "/":
            destino += "&next=" + urllib.parse.quote(next_path, safe="")
        self.send_response(302)
        self.send_header("Location", destino)
        self.end_headers()

    def _handle_logout(self) -> None:
        cerrar_sesion(token_de_cookie(self.headers.get("Cookie")))
        self.send_response(302)
        self.send_header("Location", "/login")
        self.send_header("Set-Cookie", f"{COOKIE_NAME}=; Path=/; Max-Age=0")
        self.end_headers()

    def _serve_file(self, path, content_type: str, cache: bool = False) -> None:
        if not path.is_file():
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        if cache:
            self.send_header("Cache-Control", "public, max-age=604800")
        self.end_headers()
        self.wfile.write(path.read_bytes())

    def _serve_static(self, rel_path: str) -> None:
        # Solo nombre de archivo simple (sin subcarpetas ni "..") — evita path traversal
        # fuera de STATIC_DIR aunque alguien manipule la URL a mano.
        nombre = rel_path.rsplit("/", 1)[-1]
        if not nombre or "/" in nombre or ".." in nombre:
            self.send_response(404)
            self.end_headers()
            return
        ext = "." + nombre.rsplit(".", 1)[-1] if "." in nombre else ""
        content_type = _STATIC_CONTENT_TYPES.get(ext, "application/octet-stream")
        self._serve_file(STATIC_DIR / nombre, content_type, cache=True)

    def _serve_tile(self, path_parts: list[str]) -> None:
        # /tiles/{z}/{x}/{y}.png — cada parte se valida como entero antes de tocar el disco.
        if len(path_parts) != 3 or not path_parts[2].endswith(".png"):
            self.send_response(404)
            self.end_headers()
            return
        z, x, y_png = path_parts
        y = y_png[: -len(".png")]
        if not (z.isdigit() and x.isdigit() and y.isdigit()):
            self.send_response(404)
            self.end_headers()
            return
        # cache=True (no "immutable"): el navegador SÍ debe poder revalidar/refrescar el tile
        # si el contenido en disco cambia (ej. al cambiar de proveedor de mapas) — con
        # "immutable" el navegador nunca vuelve a pedir la misma URL de tile ni con recarga
        # forzada, lo que causó que un cambio de proveedor de tiles pareciera no aplicarse.
        self._serve_file(TILES_DIR / z / x / f"{y}.png", "image/png", cache=True)

    def _resolver_params(self, params: dict) -> tuple[str, str, str, str, set[str] | None]:
        """(tipo, valor, radio, municipio_sel, nse_filtro) a partir de la query string — usado
        tanto por la página principal como por /export.xlsx, para que el Excel descargado
        refleje EXACTAMENTE la misma consulta (mismo municipio/filtro) que se está viendo."""
        valor = params.get("valor", [""])[0]
        radio = params.get("radio", [""])[0]
        municipio_sel = params.get("municipio", [""])[0]
        nse_filtro = set(params["nse"]) if "nse" in params else None
        if municipio_sel and not valor:
            tipo, valor = "Municipio", municipio_sel
        else:
            tipo = _detectar_tipo(valor)
        return tipo, valor, radio, municipio_sel, nse_filtro

    def _handle_export_xlsx(self, params: dict) -> None:
        tipo, valor, radio, municipio_sel, nse_filtro = self._resolver_params(params)
        if not valor:
            self.send_response(400)
            self.end_headers()
            return
        municipio_nombre = MUNICIPIOS_BC.get(municipio_sel) if (municipio_sel and tipo != "Municipio") else None
        try:
            r = _resolver_consulta(tipo, valor, radio, None, nse_filtro, municipio_nombre)
        except _ErrorConsulta:
            self.send_response(404)
            self.end_headers()
            return

        contenido = generar_reporte_xlsx(
            r["totals"], r["tipo"], r["valor"], r["agebs"], r["colonias_filtradas"],
            municipio=r["municipio_nombre"], radio_km=r["radio_km"],
        )

        nombre_archivo = "".join(c if c.isalnum() else "_" for c in r["valor"]) or "reporte"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f'attachment; filename="reporte_{nombre_archivo}_{timestamp}.xlsx"')
        self.end_headers()
        self.wfile.write(contenido)

    def _handle_agebs_geojson(self) -> None:
        """GeoJSON con los polígonos de TODOS los AGEBs de Baja California (solo cve_geo como
        propiedad) — usado por el mapa de /comparar para poder hacer clic directo en un
        polígono (colonia/AGEB) y agregarlo a la zona combinada, en vez de solo poder marcar
        puntos con radio. Es el mismo polígono que ya se dibuja en el mapa de la búsqueda
        normal (ver rings_municipio), aquí expuesto crudo para que el JS del navegador arme su
        propia capa clicable."""
        rings_por_ageb = rings_municipio()
        geojson = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "properties": {"cve_geo": cve_geo},
                    "geometry": {"type": "Polygon", "coordinates": rings},
                }
                for cve_geo, rings in rings_por_ageb.items()
            ],
        }
        body = json.dumps(geojson).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_comparar_export_xlsx(self, params: dict) -> None:
        puntos = _parsear_puntos_comparar(params.get("puntos", [""])[0])
        agebs_directos = _parsear_agebs_comparar(params.get("agebs", [""])[0])
        lugares = _parsear_lugares_comparar(params.get("lugares", [""])[0])
        if not puntos and not agebs_directos and not lugares:
            self.send_response(400)
            self.end_headers()
            return
        cve_geos_union, _errores = _unir_agebs_de_puntos(puntos) if puntos else ({}, [])
        for cve_geo in agebs_directos:
            cve_geos_union.setdefault(cve_geo, None)
        if lugares:
            cve_geos_lugares, _errores_lugares = _unir_agebs_de_lugares(lugares)
            cve_geos_union.update(cve_geos_lugares)
        if not cve_geos_union:
            self.send_response(404)
            self.end_headers()
            return
        totals, agebs = totales_por_agebs(list(cve_geos_union.keys()))
        n_zonas = len(puntos) + len(agebs_directos) + len(lugares)
        contenido = generar_reporte_xlsx(
            totals, "Zonas combinadas", f"{n_zonas} ubicaciones", agebs, [],
        )
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f'attachment; filename="reporte_zonas_combinadas_{timestamp}.xlsx"')
        self.end_headers()
        self.wfile.write(contenido)

    def _handle_comparar(self, params: dict, qs: str) -> None:
        """Página para enriquecer un análisis con varias zonas de flujo (clic en el mapa para
        agregar puntos, cada uno con su propio radio) — ver render_zonas_combinadas: fusiona
        todas las zonas en UN SOLO reporte agregado (no una comparación lado a lado). Sin tiles
        descargados no hay mapa interactivo para agregar puntos con clic (el mapa SVG propio no
        soporta clics arbitrarios en cualquier lat/lon), así que se avisa en vez de mostrar un
        mapa roto; los resultados YA calculados (?puntos=...) sí se pueden seguir viendo/compartiendo."""
        puntos_raw = params.get("puntos", [""])[0]
        puntos = _parsear_puntos_comparar(puntos_raw)
        agebs_directos = _parsear_agebs_comparar(params.get("agebs", [""])[0])
        lugares_raw = params.get("lugares", [""])[0]
        lugares = _parsear_lugares_comparar(lugares_raw)
        tiles_ok = _comparar_mapa_disponible()
        capa_sel = params.get("capa", ["nse"])[0]

        hay_zonas = puntos or agebs_directos or lugares
        resultado_html = render_zonas_combinadas(puntos, agebs_directos, lugares, capa_sel) if hay_zonas else ""
        if (puntos_raw or agebs_directos or lugares_raw) and not hay_zonas and not resultado_html:
            resultado_html = '<p class="error">No se pudo interpretar ninguna zona — vuelve a marcarlas en el mapa.</p>'
        if not tiles_ok:
            aviso = (
                '<p class="error">El mapa interactivo requiere los tiles descargados '
                "(<code>python main_local.py setup-mapa</code>, una vez, con internet). Sin eso no se "
                "pueden agregar zonas con clic — el resto de la app funciona igual.</p>"
            )
            resultado_html = aviso + resultado_html

        puntos_json = json.dumps([{"lat": p[0], "lon": p[1], "radioKm": p[2]} for p in puntos])
        agebs_json = json.dumps(agebs_directos)
        lugares_json = json.dumps([{"valor": v, "radioKm": r} for v, r in lugares])
        body = (
            COMPARAR_PAGE_TEMPLATE
            .replace("__ESTILO_COMPARTIDO__", SHARED_STYLE_BLOCK_RAW)
            .replace("__GUARDADOS__", _guardados_html("/comparar", qs))
            .replace("__RESULTADO__", resultado_html)
            .replace("__TILES_DISPONIBLES__", "1" if tiles_ok else "0")
            .replace("__TILE_MAX_ZOOM__", str(TILE_MAX_ZOOM_DESCARGADO))
            .replace("__PUNTOS_INICIALES_JSON__", _html_attr_escape_comparar(puntos_json))
            .replace("__AGEBS_INICIALES_JSON__", _html_attr_escape_comparar(agebs_json))
            .replace("__LUGARES_INICIALES_JSON__", _html_attr_escape_comparar(lugares_json))
        )
        necesita_leaflet = tiles_ok or "mapa-leaflet" in resultado_html
        if necesita_leaflet:
            head_leaflet = '<link rel="stylesheet" href="/static/leaflet.css">'
            body = body.replace("</head>", head_leaflet + "</head>")
            scripts = '<script src="/static/leaflet.js"></script>'
            if tiles_ok:
                scripts += COMPARAR_MAPA_SCRIPT
            if "mapa-leaflet" in resultado_html:
                scripts += MAPA_LEAFLET_SCRIPT
            body = body.replace("</body>", scripts + "</body>")
        if "denue-modal" in resultado_html:
            body = body.replace("</body>", DENUE_MODAL_SCRIPT + "</body>")
        if "retorno-box" in resultado_html:
            body = body.replace("</body>", RETORNO_CLIENTES_SCRIPT + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _handle_hospitales(self) -> None:
        """Página dedicada de hospitales privados con capacidad cardiovascular (nivel II/III)
        en Tijuana — pedido explícito del usuario: no quería este dato mezclado dentro del
        reporte normal de zona, sino su propia sección con mapa de pines y filtros propios,
        similar en espíritu a /comparar pero sin combinar zonas, solo explorar el catálogo."""
        resultado_html = render_hospitales_cardio()
        body = HOSPITALES_PAGE_TEMPLATE.replace(
            "__ESTILO_COMPARTIDO__", SHARED_STYLE_BLOCK_RAW
        ).replace("__RESULTADO__", resultado_html)
        body = body.replace(
            "</head>", '<link rel="stylesheet" href="/static/leaflet.css"></head>'
        )
        scripts = '<script src="/static/leaflet.js"></script>' + HOSPITALES_MAPA_SCRIPT
        body = body.replace("</body>", scripts + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _handle_mercado_laboratorios(self) -> None:
        """Página dedicada de "% de mercado" de laboratorios a nivel de TODA la ciudad —
        distinta de /hospitales (que es un catálogo geolocalizado) y de "Valor de la zona"
        (que es por AGEB/zona puntual, no por ciudad): compara la cadena propia contra el
        universo real de laboratorios de Tijuana (barrido de Google Maps, con mapa de pines) y
        la demanda estimada de toda la ciudad. Fijo a Tijuana por ahora — es la única ciudad
        con este barrido (ver query_engine_local.analizar_mercado_laboratorios)."""
        resultado_html = render_mercado_laboratorios()
        body = (
            MERCADO_LAB_PAGE_TEMPLATE
            .replace("__ESTILO_COMPARTIDO__", SHARED_STYLE_BLOCK_RAW)
            .replace("__RESULTADO__", resultado_html)
        )
        body = body.replace("</head>", '<link rel="stylesheet" href="/static/leaflet.css"></head>')
        scripts = '<script src="/static/leaflet.js"></script>' + MERCADO_LAB_MAPA_SCRIPT + MERCADO_LAB_SCRIPT
        body = body.replace("</body>", scripts + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _handle_mercado_empresas(self) -> None:
        """Página dedicada de empresas/maquiladoras con nómina alta (101+ empleados) en Tijuana
        — combina directorio de maquiladoras + DENUE filtrado por personal ocupado (ver
        query_engine_local.analizar_empresas_nomina). La mayoría de las filas no trae
        coordenadas, así que el mapa solo muestra las que sí las tienen."""
        resultado_html = render_mercado_empresas()
        body = (
            EMPRESAS_PAGE_TEMPLATE
            .replace("__ESTILO_COMPARTIDO__", SHARED_STYLE_BLOCK_RAW)
            .replace("__RESULTADO__", resultado_html)
        )
        body = body.replace("</head>", '<link rel="stylesheet" href="/static/leaflet.css"></head>')
        scripts = '<script src="/static/leaflet.js"></script>' + EMPRESAS_MAPA_SCRIPT
        body = body.replace("</body>", scripts + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def _handle_guardar(self, params: dict) -> None:
        nombre = params.get("nombre", [""])[0]
        destino = params.get("destino", ["/"])[0]
        qs = params.get("qs", [""])[0]
        resumen_poblacion = params.get("resumen_poblacion", [""])[0]
        resumen_valor = params.get("resumen_valor", [""])[0]
        if nombre.strip():
            guardar_analisis(nombre, destino, qs, resumen_poblacion, resumen_valor)
        location = f"{destino}?{qs}" if qs else destino
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def _handle_eliminar_guardado(self, params: dict) -> None:
        try:
            id_ = int(params.get("id", ["0"])[0])
            eliminar_analisis_guardado(id_)
        except ValueError:
            pass
        volver = params.get("volver", ["/"])[0]
        self.send_response(302)
        self.send_header("Location", urllib.parse.unquote(volver))
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path.startswith("/static/"):
            self._serve_static(parsed.path[len("/static/"):])
            return
        if parsed.path.startswith("/tiles/"):
            self._serve_tile([p for p in parsed.path[len("/tiles/"):].split("/") if p])
            return

        params = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/login":
            self._handle_login_get(params)
            return

        if not self._autenticado():
            destino = parsed.path + (f"?{parsed.query}" if parsed.query else "")
            self._redirigir_a_login(destino)
            return

        if parsed.path == "/logout":
            self._handle_logout()
            return

        if parsed.path == "/export.xlsx":
            self._handle_export_xlsx(params)
            return

        if parsed.path == "/comparar/export.xlsx":
            self._handle_comparar_export_xlsx(params)
            return

        if parsed.path == "/api/agebs.geojson":
            self._handle_agebs_geojson()
            return

        if parsed.path == "/comparar":
            self._handle_comparar(params, parsed.query)
            return

        if parsed.path == "/hospitales":
            self._handle_hospitales()
            return

        if parsed.path == "/mercado-laboratorios":
            self._handle_mercado_laboratorios()
            return

        if parsed.path == "/mercado-empresas":
            self._handle_mercado_empresas()
            return

        if parsed.path == "/guardar":
            self._handle_guardar(params)
            return

        if parsed.path == "/eliminar-guardado":
            self._handle_eliminar_guardado(params)
            return

        tipo, valor, radio, municipio_sel, nse_filtro = self._resolver_params(params)
        zona_ids = params.get("zona") if params.get("zonas_form") == ["1"] else None
        capa_sel = params.get("capa", ["nse"])[0]

        link_out: dict = {}
        resultado_html = render_resultado(tipo, valor, radio, zona_ids, nse_filtro, municipio_sel, capa_sel, link_out)
        if not resultado_html:
            # Primera carga de la página (sin buscar nada todavía): igual se muestra el mapa
            # de todo Baja California, para que el usuario vea de entrada dónde está parado
            # en vez de una página en blanco hasta la primera búsqueda.
            resultado_html = _mapa_inicial_html()

        if link_out.get("lat") is not None:
            # El botón de combinar zonas ya sale apuntando a la ubicación actual como primer
            # punto (en vez de mandar a un mapa vacío) — el usuario solo agrega las zonas que
            # quiera sumar a esta.
            comparar_href = (
                "/comparar?puntos=" + urllib.parse.quote(
                    f"{link_out['lat']:.6f},{link_out['lon']:.6f},{link_out['radio']:g}"
                )
            )
        else:
            comparar_href = "/comparar"

        body = PAGE_TEMPLATE.format(
            valor_escaped=html.escape(valor if tipo != "Municipio" else ""),
            radio_escaped=html.escape(radio),
            resultado=resultado_html,
            municipio_selector=_municipio_selector_html(municipio_sel),
            capa_selector=_capa_selector_html(capa_sel),
            comparar_href=comparar_href,
            guardados_html=_guardados_html("/", parsed.query),
        )
        if "mapa-leaflet" in resultado_html:
            head_leaflet = '<link rel="stylesheet" href="/static/leaflet.css">'
            body = body.replace("</head>", head_leaflet + "</head>")
            body = body.replace(
                "</body>", '<script src="/static/leaflet.js"></script>' + MAPA_LEAFLET_SCRIPT + "</body>"
            )
        elif "mapa-svg" in resultado_html:
            body = body.replace("</body>", MAPA_SCRIPT + "</body>")
        if "denue-modal" in resultado_html:
            body = body.replace("</body>", DENUE_MODAL_SCRIPT + "</body>")
        if "retorno-box" in resultado_html:
            body = body.replace("</body>", RETORNO_CLIENTES_SCRIPT + "</body>")

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/login":
            largo = int(self.headers.get("Content-Length", 0))
            cuerpo = self.rfile.read(largo).decode("utf-8") if largo else ""
            params = urllib.parse.parse_qs(cuerpo)
            self._handle_login_post(params)
            return
        self.send_response(404)
        self.end_headers()


def run_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    server = HTTPServer((host, port), Handler)
    logger.info("Servidor local iniciado en http://%s:%d (Ctrl+C para detener)", host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Servidor detenido.")
    finally:
        server.server_close()


if __name__ == "__main__":
    run_server()
