"""CLI del modo 100% local (sin PostgreSQL, sin librerías externas — solo Python estándar).

Uso:
    python main_local.py setup-db
    python main_local.py run-etl
    python main_local.py setup-mapa                       # una vez, con internet: mapa con calles/relieve reales
    python main_local.py query --tipo Colonia --valor "Zona Rio"
    python main_local.py query --tipo Colonia --valor "Villa Fontana" --radio 1.5
    python main_local.py centro --tipo Colonia --valor "Villa Fontana"
    python main_local.py query-radio --lat 32.5048 --lon -116.8604 --radio 1.5
    python main_local.py punto --lat 32.5048 --lon -116.8604
    python main_local.py punto --lat 32.5048 --lon -116.8604 --radio 1.5
    python main_local.py serve [--port 8000]
"""
import argparse
import sys
from pathlib import Path

from logger_setup import get_logger

logger = get_logger("main_local")


def cmd_setup_db(_args: argparse.Namespace) -> None:
    from config import SQLITE_DB_PATH
    from local_engine.db_sqlite import setup_database

    setup_database(SQLITE_DB_PATH)
    print(f"Base de datos SQLite lista en {SQLITE_DB_PATH}")


def cmd_run_etl(_args: argparse.Namespace) -> None:
    from local_engine.etl_local import run_etl_local

    run_etl_local()


def cmd_setup_mapa(args: argparse.Namespace) -> None:
    from local_engine.setup_mapa import setup_mapa

    setup_mapa(zoom_min=args.zoom_min, zoom_max=args.zoom_max)


def cmd_query(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import analizar_locacion, exportar_a_csv

    if args.radio and args.tipo == "AGEB":
        print("Error: --radio no aplica cuando --tipo es 'AGEB'.")
        sys.exit(1)

    output_path = Path(args.output) if args.output else None
    totals, agebs, zonas_todas, _zonas_usadas = analizar_locacion(args.tipo, args.valor, radio_km=args.radio)
    valor_reporte = f"{args.valor} (radio {args.radio}km)" if args.radio else args.valor

    if len(zonas_todas) > 1:
        print(
            f"Nota: '{args.valor}' coincidió con {len(zonas_todas)} zonas; se sumaron todas "
            "(usa el modo web para incluir/excluir zonas específicas)."
        )
    if args.radio:
        print(f"{len(agebs)} AGEBs agregados dentro de {args.radio} km.")

    path = exportar_a_csv(totals, args.tipo, valor_reporte, output_path, agebs=agebs)
    print(f"Reporte generado: {path} (incluye {len(agebs)} clave(s) de AGEB para auditar).")


def cmd_centro(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import buscar_centros

    resultados = buscar_centros(args.tipo, args.valor)
    if not resultados:
        print(f"No se encontraron zonas para {args.tipo} = '{args.valor}'.")
        return
    print(f"{len(resultados)} zona(s) encontrada(s):\n")
    for r in resultados:
        print(f"CP {r['cp']}  |  lat={r['lat']:.6f}, lon={r['lon']:.6f}")
        print(f"  Colonias: {r['colonia']}\n")


def cmd_query_radio(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import analizar_por_radio, exportar_a_csv

    output_path = Path(args.output) if args.output else None
    totals, n_agebs, agebs = analizar_por_radio(args.lat, args.lon, args.radio)
    valor_desc = f"{args.lat},{args.lon},{args.radio}km"
    path = exportar_a_csv(totals, "Radio", valor_desc, output_path, agebs=agebs)
    print(f"{n_agebs} AGEBs agregados dentro del radio.")
    print(f"Reporte generado: {path}")


def cmd_punto(args: argparse.Namespace) -> None:
    from local_engine.query_engine_local import analizar_por_coordenada, exportar_a_csv

    output_path = Path(args.output) if args.output else None
    totals, agebs, info = analizar_por_coordenada(args.lat, args.lon, radio_km=args.radio)

    if info["ageb"]:
        print(f"La coordenada cae dentro del AGEB {info['ageb']['cve_ageb']} (cve_geo {info['ageb']['cve_geo']}).")
    else:
        print("La coordenada no cae dentro de ningún AGEB conocido.")
    if info["zonas"]:
        for z in info["zonas"]:
            print(f"  Zona: CP {z['cp']} — {z['colonia']}")

    valor_desc = f"{args.lat},{args.lon}" + (f" (radio {args.radio}km)" if args.radio else "")
    path = exportar_a_csv(totals, "Coordenadas", valor_desc, output_path, agebs=agebs)
    print(f"{len(agebs)} AGEBs agregados.")
    print(f"Reporte generado: {path}")


def cmd_serve(args: argparse.Namespace) -> None:
    from local_engine.server import run_server

    run_server(port=args.port)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Agente INEGI - Baja California (modo 100% local, sin librerías externas)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("setup-db", help="Inicializa la base de datos SQLite local.").set_defaults(func=cmd_setup_db)
    subparsers.add_parser("run-etl", help="Ejecuta el pipeline ETL completo (local).").set_defaults(func=cmd_run_etl)

    mapa_parser = subparsers.add_parser(
        "setup-mapa",
        help="Descarga UNA VEZ (requiere internet) Leaflet.js y tiles OSM de Baja California, para el "
             "mapa con calles/relieve reales. Después 'serve' los usa 100% desde disco.",
    )
    mapa_parser.add_argument("--zoom-min", type=int, default=11)
    mapa_parser.add_argument("--zoom-max", type=int, default=12)
    mapa_parser.set_defaults(func=cmd_setup_mapa)

    query_parser = subparsers.add_parser("query", help="Consulta una zona por Colonia o CP.")
    query_parser.add_argument("--tipo", required=True, choices=["Colonia", "CP", "AGEB"])
    query_parser.add_argument("--valor", required=True)
    query_parser.add_argument(
        "--radio", required=False, type=float,
        help="Opcional (solo Colonia/CP): radio en km alrededor del centro de la zona; "
             "agrega el censo de todos los AGEBs dentro de ese radio en vez de la asignación por nombre.",
    )
    query_parser.add_argument("--output", required=False)
    query_parser.set_defaults(func=cmd_query)

    centro_parser = subparsers.add_parser(
        "centro", help="Busca Colonia/CP por nombre y muestra sus coordenadas (lat/lon) para usar con query-radio."
    )
    centro_parser.add_argument("--tipo", required=True, choices=["Colonia", "CP"])
    centro_parser.add_argument("--valor", required=True)
    centro_parser.set_defaults(func=cmd_centro)

    radio_parser = subparsers.add_parser(
        "query-radio", help="Agrega el censo de todos los AGEBs dentro de un radio (km) de un punto lat/lon."
    )
    radio_parser.add_argument("--lat", required=True, type=float)
    radio_parser.add_argument("--lon", required=True, type=float)
    radio_parser.add_argument("--radio", required=True, type=float, help="Radio en kilómetros.")
    radio_parser.add_argument("--output", required=False)
    radio_parser.set_defaults(func=cmd_query_radio)

    punto_parser = subparsers.add_parser(
        "punto",
        help="Identifica el AGEB/Colonia de una coordenada exacta y analiza (AGEB exacto, o el área en --radio km).",
    )
    punto_parser.add_argument("--lat", required=True, type=float)
    punto_parser.add_argument("--lon", required=True, type=float)
    punto_parser.add_argument("--radio", required=False, type=float, help="Radio en km (opcional).")
    punto_parser.add_argument("--output", required=False)
    punto_parser.set_defaults(func=cmd_punto)

    serve_parser = subparsers.add_parser("serve", help="Levanta el servidor web local (HTML dinámico).")
    serve_parser.add_argument("--port", type=int, default=8000)
    serve_parser.set_defaults(func=cmd_serve)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as exc:
        logger.error("Error ejecutando comando '%s': %s", args.command, exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
