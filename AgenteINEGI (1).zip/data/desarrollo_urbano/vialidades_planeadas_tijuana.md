# Proyectos de infraestructura/vialidades planeadas — Tijuana

Fuente: Actualización del Programa de Desarrollo Urbano del Centro de Población de Tijuana,
B.C. (PDUCPT 2009-2030), pág. 326 — extraído vía Gemini/NotebookLM el 22-oct-2026.

Referencia documental únicamente — NO geocodificado (sin coordenadas ni límites de AGEB/colonia
en la fuente), así que todavía no aparece como capa del mapa en la app. Útil para dar contexto
manual si una zona consultada cae cerca de alguno de estos corredores.

| Proyecto | Ubicación | Estatus |
|---|---|---|
| Ampliación y adecuación del Corredor Lázaro Cárdenas | Corredor Lázaro Cárdenas | Planeado / en análisis de factibilidad |
| Adecuación del distribuidor vial Glorieta Soler | Glorieta Soler | Planeado |
| Ampliación y adecuación de bulevares | Díaz Ordaz, Cuauhtémoc Sur, Fundadores, Alba Roja y Cucapah | Planeado |
| Ampliación del Blvd. Ferrocarril | Blvd. Ferrocarril (incl. tramo en Valle Redondo) | Planeado |
| Par vial Murúa-El Fuerte y vías rápidas del Arroyo Alamar | Arroyo Alamar | Planeado |
| Conversión de la Carretera Libre Tijuana-Mexicali a bulevar de jerarquía primaria | Carretera Libre Tijuana-Mexicali | Planeado |
| Blvd. Machado y Blvd. García (Cueros de Venado) | Enlaces al exterior del municipio | Planeado |
| Blvd. Sánchez Taboada (Santa Fe) y San Pedro | Santa Fe / Valle de Las Palmas | Planeado |

## Secciones sin información en los documentos consultados

Zonificación/uso de suelo por zona específica, división territorial por delegaciones,
proyecciones de crecimiento poblacional por zona, y corredores comerciales/polos económicos
estratégicos — el PDUCPT y el PMD 2025-2027 (según lo que Gemini pudo extraer) solo traen la
matriz normativa general de usos de suelo, no un desglose geográfico específico de estas 4
categorías.
