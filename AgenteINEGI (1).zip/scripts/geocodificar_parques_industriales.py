"""Geocodifica los parques industriales/zonas de data/empresas_nomina/*.csv usando Nominatim
(OpenStreetMap, gratuito, sin llave de API) y rellena lat/lon para TODAS las empresas que
comparten el mismo parque — da la ubicación del parque/zona industrial, no del edificio exacto
de cada empresa (Nominatim no tiene esa granularidad para la mayoría de estos parques, y el
catálogo de maquiladoras tampoco trae dirección exacta por empresa).

IMPORTANTE: corre esto en TU máquina, no en un entorno de desarrollo en la nube — el sandbox
donde Claude corre este proyecto tiene el acceso a servicios de geocodificación bloqueado por
política de red, por eso este script no se pudo ejecutar ahí. Aquí sí debería funcionar con tu
conexión normal a internet.

Uso (sin instalar nada, solo Python estándar):
    cd Agente-INEGI
    python scripts/geocodificar_parques_industriales.py

Después de correrlo, vuelve a correr `python main_local.py run-etl` para que la base de datos
recoja las coordenadas nuevas.

Respeta la política de uso de Nominatim (máximo 1 solicitud por segundo, con un User-Agent que
te identifique) — no lo aceleres, podrían bloquear tu IP de ese servicio.
"""
import csv
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

CSV_PATH = (
    Path(__file__).resolve().parent.parent
    / "data" / "empresas_nomina" / "empresas_tijuana_101plus.csv"
)
# Nominatim pide un User-Agent identificable (no un navegador genérico) — cambia el correo
# por el tuyo si quieres, no es obligatorio pero es buena práctica con su servicio gratuito.
USER_AGENT = "AgenteINEGI-uso-interno/1.0 (contacto: tu-correo@ejemplo.com)"
CIUDAD = "Tijuana, Baja California, México"
PAUSA_SEGUNDOS = 1.1  # política de Nominatim: no más de 1 solicitud/segundo


def geocodificar(parque: str) -> tuple[float, float] | None:
    query = f"{parque}, {CIUDAD}"
    url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode(
        {"q": query, "format": "json", "limit": 1, "countrycodes": "mx"}
    )
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as e:
        print(f"  ERROR geocodificando '{parque}': {e}")
        return None
    if not data:
        return None
    return float(data[0]["lat"]), float(data[0]["lon"])


def main() -> None:
    if not CSV_PATH.is_file():
        print(f"No se encontró {CSV_PATH}")
        return

    with CSV_PATH.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    fieldnames = list(rows[0].keys())

    parques = sorted({(row.get("colonia") or "").strip() for row in rows} - {""})
    print(f"{len(parques)} parques/zonas distintos a geocodificar (1 solicitud cada {PAUSA_SEGUNDOS}s)...\n")

    coords_por_parque: dict[str, tuple[float, float]] = {}
    sin_resultado = []
    for i, parque in enumerate(parques, 1):
        print(f"[{i}/{len(parques)}] {parque}...", end=" ", flush=True)
        resultado = geocodificar(parque)
        if resultado:
            coords_por_parque[parque] = resultado
            print(f"OK ({resultado[0]:.5f}, {resultado[1]:.5f})")
        else:
            sin_resultado.append(parque)
            print("SIN RESULTADO")
        time.sleep(PAUSA_SEGUNDOS)

    actualizadas = 0
    for row in rows:
        parque = (row.get("colonia") or "").strip()
        ya_tiene_coords = (row.get("lat") or "").strip() and (row.get("lon") or "").strip()
        if parque in coords_por_parque and not ya_tiene_coords:
            lat, lon = coords_por_parque[parque]
            row["lat"] = lat
            row["lon"] = lon
            actualizadas += 1

    with CSV_PATH.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n{actualizadas} empresas actualizadas con coordenadas del parque industrial al que pertenecen.")
    print("(Es la ubicación del parque/zona, no del edificio exacto de cada empresa dentro de él —")
    print(" varias empresas en el mismo parque comparten el mismo punto en el mapa.)")

    if sin_resultado:
        print(f"\n{len(sin_resultado)} parques SIN coordenadas (revísalos a mano en Google Maps y edita el CSV):")
        for p in sin_resultado:
            print(f"  - {p}")

    print(f"\nListo. Corre 'python main_local.py run-etl' para recargar la base de datos con esto.")


if __name__ == "__main__":
    main()
