"""Script de uso ÚNICO (no forma parte del ETL): une el catálogo de colonias de SEPOMEX
(XML "NewDataSet" descargado de correosdemexico.gob.mx, con d_codigo/d_asenta/D_mnpio) con
el polígono real de cada CP (GeoJSON de Correos de México, con solo d_codigo) para producir
un archivo colonias_baja_california.geojson en el mismo esquema que ya usa Tijuana
(colonia, cp, municipio, polígono) — lo que le falta al polígono lo da el catálogo, y
viceversa; ninguno de los dos por separado alcanza.

Uso:
    python scripts_merge_sepomex_colonias.py <sepomex.xml> <poligonos_cp.geojson> <salida.geojson>
"""
import json
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path


def cargar_colonias_por_cp(xml_path: Path) -> dict[str, list[str]]:
    tree = ET.parse(xml_path)
    root = tree.getroot()
    ns = {"ns": "NewDataSet"}
    colonias_por_cp: dict[str, list[str]] = defaultdict(list)
    municipio_por_cp: dict[str, str] = {}
    for tabla in root.findall("ns:table", ns):
        campos = {child.tag.split("}")[-1]: (child.text or "").strip() for child in tabla}
        cp = campos.get("d_codigo", "")
        asenta = campos.get("d_asenta", "")
        mnpio = campos.get("D_mnpio", "")
        if not cp:
            continue
        if asenta and asenta not in colonias_por_cp[cp]:
            colonias_por_cp[cp].append(asenta)
        if mnpio:
            municipio_por_cp[cp] = mnpio
    return colonias_por_cp, municipio_por_cp


def main() -> None:
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    xml_path, poligonos_path, salida_path = (Path(p) for p in sys.argv[1:4])

    colonias_por_cp, municipio_por_cp = cargar_colonias_por_cp(xml_path)
    print(f"Catálogo SEPOMEX: {len(colonias_por_cp)} códigos postales con nombre de colonia.")

    poligonos = json.loads(poligonos_path.read_text(encoding="utf-8"))
    features_salida = []
    con_nombre, sin_nombre, omitidos_tijuana = 0, 0, 0
    for feature in poligonos["features"]:
        cp = str(feature["properties"].get("d_codigo", "")).strip()
        if cp.isdigit():
            cp = cp.zfill(5)
        colonias = colonias_por_cp.get(cp, [])
        municipio = municipio_por_cp.get(cp, "")
        # Tijuana ya tiene una fuente mejor cargada aparte (colonias_tijuana_sepomex.geojson,
        # polígonos reales de colonia de IMPLAN) — incluirla aquí también duplicaría zonas
        # con geometría distinta para el mismo nombre y confundiría los resultados.
        if municipio == "Tijuana":
            omitidos_tijuana += 1
            continue
        if colonias:
            con_nombre += 1
        else:
            sin_nombre += 1
        features_salida.append({
            "type": "Feature",
            "geometry": feature["geometry"],
            "properties": {
                "cp": cp,
                "colonia": ", ".join(colonias) if colonias else None,
                "municipio": municipio or None,
            },
        })

    salida = {"type": "FeatureCollection", "features": features_salida}
    salida_path.write_text(json.dumps(salida, ensure_ascii=False), encoding="utf-8")
    print(
        f"Escrito {salida_path} — {con_nombre} CP con nombre de colonia, {sin_nombre} sin "
        f"nombre (solo polígono), {omitidos_tijuana} de Tijuana omitidos (ya tiene fuente propia)."
    )


if __name__ == "__main__":
    main()
