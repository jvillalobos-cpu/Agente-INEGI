"""Descarga el padrón NACIONAL de gasolineras (catálogo + precios) desde los servicios
oficiales de la CNE (antes CRE) y filtra las que caen dentro de Baja California, dejando el
resultado listo en data/gasolineras/ para que el ETL del proyecto lo cargue.

IMPORTANTE: corre esto en TU máquina, no en un entorno de desarrollo en la nube — el sandbox
donde Claude corre este proyecto tiene bloqueado por política de red el acceso a los dominios
de la CNE/CRE (igual que con el geocodificador de parques industriales), así que este script
no se pudo probar ahí. Aquí, con tu conexión normal a internet, debería funcionar.

Uso (sin instalar nada, solo Python estándar):
    cd Agente-INEGI
    python scripts/descargar_gasolineras_cne.py

Qué hace (dos pasos, porque la CNE separa el catálogo de los precios en dos servicios distintos):
1. PRECIOS: descarga https://publicacionexterna.azurewebsites.net/publicaciones/prices
   (confirmado que funciona — da <place place_id="..."><gas_price type="regular">PRECIO</gas_price>...)
   y arma un diccionario place_id -> precios.
2. CATÁLOGO (nombre + coordenadas): este es el que no se ha podido confirmar desde el sandbox
   de Claude. El script intenta varias rutas candidatas documentadas por la propia CNE/terceros
   que usan su API, una por una, e imprime CLARAMENTE cuál funcionó o por qué falló cada una —
   así, si ninguna funciona, sabemos exactamente qué URL/formato corregir después en vez de
   adivinar otra vez.
3. Cruza catálogo + precios por place_id, filtra a Baja California, y escribe
   data/gasolineras/gasolineras_baja_california.csv listo para 'python main_local.py run-etl'
   (que resuelve el municipio exacto de cada una por punto-en-polígono contra los AGEBs).

Si el catálogo no se puede obtener, el script AVISA explícitamente y no inventa nombres ni
coordenadas — en ese caso mándame la salida completa de la terminal (los intentos y sus
errores) para ajustar las URLs candidatas.
"""
import csv
import json
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

URL_PRECIOS = "https://publicacionexterna.azurewebsites.net/publicaciones/prices"

# Candidatas para el catálogo (nombre + coordenadas) — se prueban en orden, la primera que
# responda con datos utilizables gana. Las de "ciudades" cubren los 7 municipios de Baja
# California con un punto central y radio generoso cada una.
CIUDADES_BC = {
    "Tijuana": (32.52, -117.02), "Mexicali": (32.63, -115.45), "Ensenada": (31.86, -116.60),
    "Tecate": (32.57, -116.63), "Playas de Rosarito": (32.36, -117.07),
    "San Quintín": (30.56, -115.95), "San Felipe": (31.03, -114.84),
}

OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "gasolineras"
OUT_CSV = OUT_DIR / "gasolineras_baja_california.csv"
RAW_DEBUG_DIR = OUT_DIR / "_debug"

BC_LAT_MIN, BC_LAT_MAX = 27.8, 32.75
BC_LON_MIN, BC_LON_MAX = -118.5, -112.7

USER_AGENT = "AgenteINEGI-uso-interno/1.0 (contacto: tu-correo@ejemplo.com)"


def _get(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json, application/xml, */*"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def descargar_precios() -> dict[str, dict]:
    """place_id (str) -> {'regular': .., 'premium': .., 'diesel': ..}. Formato confirmado:
    <places><place place_id="X"><gas_price type="regular">22.95</gas_price>...</place></places>
    (el mismo place_id puede repetirse en varios <place> separados, no siempre en el mismo)."""
    print(f"Descargando precios: {URL_PRECIOS} ...")
    xml_bytes = _get(URL_PRECIOS, timeout=60)
    print(f"  OK — {len(xml_bytes):,} bytes.")
    root = ET.fromstring(xml_bytes)
    precios: dict[str, dict] = {}
    for p in root.findall(".//place"):
        pid = p.get("place_id")
        if not pid:
            continue
        d = precios.setdefault(pid, {})
        for gp in p.findall("gas_price"):
            tipo = gp.get("type")
            if tipo and gp.text:
                d[tipo] = gp.text.strip()
    print(f"  {len(precios):,} estaciones distintas con precio (place_id único).")
    return precios


def _parsear_catalogo_json(data) -> list[dict]:
    """Intenta leer una lista de estaciones desde JSON con varios nombres de campo posibles
    (distintos clones/versiones de esta API usan distintos nombres)."""
    lista = data if isinstance(data, list) else data.get("places") or data.get("data") or data.get("results") or []
    filas = []
    for item in lista:
        if not isinstance(item, dict):
            continue
        pid = str(item.get("place_id") or item.get("placeId") or item.get("id") or "")
        nombre = item.get("name") or item.get("nombre") or item.get("brand") or ""
        lat = item.get("lat") or item.get("latitude") or (item.get("location") or {}).get("y")
        lon = item.get("lon") or item.get("longitude") or (item.get("location") or {}).get("x")
        if not (pid and nombre and lat and lon):
            continue
        filas.append({"place_id": pid, "nombre": nombre, "lat": lat, "lon": lon})
    return filas


def intentar_catalogo() -> list[dict]:
    RAW_DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    encontradas: dict[str, dict] = {}

    # Candidata 1: mismo patrón "/publicaciones/<recurso>" que ya sabemos que funciona para precios.
    for recurso in ("places", "stations", "estaciones", "catalog", "catalogo"):
        url = f"https://publicacionexterna.azurewebsites.net/publicaciones/{recurso}"
        print(f"Probando catálogo: {url} ...")
        try:
            raw = _get(url)
        except Exception as e:
            print(f"  falló: {e}")
            continue
        print(f"  respondió, {len(raw):,} bytes — revisando contenido...")
        (RAW_DEBUG_DIR / f"intento_{recurso}.bin").write_bytes(raw)
        try:
            filas = _parsear_catalogo_json(json.loads(raw))
            if filas:
                print(f"  ¡{len(filas)} estaciones reconocidas en JSON!")
                for f in filas:
                    encontradas[f["place_id"]] = f
                return list(encontradas.values())
        except json.JSONDecodeError:
            try:
                root = ET.fromstring(raw)
                for p in root.findall(".//place"):
                    pid = p.get("place_id")
                    nombre_el = p.find("name")
                    loc = p.find("location")
                    if pid and nombre_el is not None and loc is not None:
                        encontradas[pid] = {
                            "place_id": pid, "nombre": nombre_el.text or "",
                            "lat": (loc.find("y").text if loc.find("y") is not None else ""),
                            "lon": (loc.find("x").text if loc.find("x") is not None else ""),
                        }
                if encontradas:
                    print(f"  ¡{len(encontradas)} estaciones reconocidas en XML!")
                    return list(encontradas.values())
            except ET.ParseError:
                pass
        print("  no tenía la estructura esperada (guardado para revisar).")

    # Candidata 2: API por ubicación/radio (documentada por el proyecto gasolinerasApi de GitHub),
    # una consulta por cada ciudad principal de Baja California.
    for ciudad, (lat, lon) in CIUDADES_BC.items():
        for radio in (50, 15):
            url = f"https://api-reportediario.cne.gob.mx/places/location/{lat},{lon}/{radio}"
            print(f"Probando catálogo por ubicación ({ciudad}, radio {radio}): {url} ...")
            try:
                raw = _get(url)
            except Exception as e:
                print(f"  falló: {e}")
                continue
            (RAW_DEBUG_DIR / f"intento_location_{ciudad.replace(' ', '_')}.bin").write_bytes(raw)
            try:
                filas = _parsear_catalogo_json(json.loads(raw))
                if filas:
                    print(f"  ¡{len(filas)} estaciones reconocidas cerca de {ciudad}!")
                    for f in filas:
                        encontradas[f["place_id"]] = f
                    break  # ya funcionó con este radio, no probar el otro para esta ciudad
            except json.JSONDecodeError:
                print("  respuesta no es JSON reconocible (guardada para revisar).")

    return list(encontradas.values())


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    try:
        precios = descargar_precios()
    except Exception as e:
        print(f"ERROR al descargar precios: {e}")
        sys.exit(1)

    catalogo = intentar_catalogo()

    if not catalogo:
        print("\nNo se pudo obtener el catálogo (nombre + coordenadas) de NINGUNA de las rutas")
        print(f"probadas. Revisa los archivos en {RAW_DEBUG_DIR} y mándame esa carpeta completa")
        print("(o pega aquí la salida de arriba) para que ajuste las URLs — NO voy a inventar")
        print("coordenadas para rellenar esto.")
        sys.exit(1)

    print(f"\nTotal estaciones en catálogo: {len(catalogo):,}")

    filas_bc = []
    for est in catalogo:
        try:
            lat, lon = float(est["lat"]), float(est["lon"])
        except (ValueError, TypeError):
            continue
        if not (BC_LAT_MIN <= lat <= BC_LAT_MAX and BC_LON_MIN <= lon <= BC_LON_MAX):
            continue
        precio = precios.get(est["place_id"], {})
        filas_bc.append({
            "nombre": est["nombre"], "marca": "", "permisionario": "",
            "numero_permiso": est["place_id"], "direccion": "", "colonia": "", "municipio": "",
            "lat": lat, "lon": lon,
            "precio_regular": precio.get("regular", ""), "precio_premium": precio.get("premium", ""),
            "precio_diesel": precio.get("diesel", ""),
            "fuente": "CNE/CRE padrón oficial",
        })

    if not filas_bc:
        print("Ninguna estación del catálogo cayó dentro de Baja California — revisa si las")
        print(f"coordenadas vienen en otro formato. Ejemplo: {catalogo[0]}")
        sys.exit(1)

    campos = ["nombre", "marca", "permisionario", "numero_permiso", "direccion", "colonia",
              "municipio", "lat", "lon", "precio_regular", "precio_premium", "precio_diesel", "fuente"]
    with OUT_CSV.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=campos)
        writer.writeheader()
        writer.writerows(filas_bc)

    print(f"\n{len(filas_bc):,} gasolineras de Baja California guardadas en {OUT_CSV}")
    print("Municipio se deja vacío aquí a propósito — se resuelve solo al correr:")
    print("    python main_local.py run-etl")


if __name__ == "__main__":
    main()
