"""Motor de consultas local (SQLite, sin PostgreSQL) + exportación a CSV."""
import csv
import json
import math
import re
import sqlite3
import unicodedata
from datetime import datetime
from pathlib import Path

from config import (
    FECHA_DATOS,
    FUENTE_DATOS,
    OUTPUT_DIR,
    SQLITE_DB_PATH,
    TOTAL_15A29_MUNICIPIO,
    TOTAL_30A59_MUNICIPIO,
)
from local_engine.db_sqlite import get_connection
from local_engine.xlsx_writer import Celda, Hoja, escribir_xlsx
from local_engine.xlsx_writer import (
    ESTILO_ENCABEZADO_TABLA,
    ESTILO_NORMAL,
    ESTILO_NORMAL_NEGRITA,
    ESTILO_TITULO_SECCION,
)
from local_engine.etl_local import NUMERIC_CENSO_COLUMNS
from local_engine.intercensal_2025 import EIC2025_ESTATAL, EIC2025_POBLACION_MUNICIPIOS
from local_engine.geometry import area_km2_multiring, haversine_km, multiring_centroid, point_in_multiring
from logger_setup import get_logger

logger = get_logger("query_engine_local")


def _sin_acentos(texto: str | None) -> str:
    """Normaliza a mayúsculas sin acentos (NFKD) para comparaciones tolerantes a tildes."""
    if texto is None:
        return ""
    descompuesto = unicodedata.normalize("NFKD", texto)
    return "".join(c for c in descompuesto if not unicodedata.combining(c)).upper()

VARIABLE_LABELS = {
    "vivtot": "Total de viviendas", "tvivparhab": "Viviendas particulares habitadas",
    "vivpar_des": "Viviendas particulares deshabitadas",
    "vph_pisoti": "Viviendas con piso diferente de tierra",
    "vph_c_elec": "Viviendas con energía eléctrica", "vph_excsa": "Viviendas con servicio sanitario",
    "vph_drenaj": "Viviendas con drenaje", "pobtot": "Población total",
    "pobfem": "Población femenina", "pobmas": "Población masculina",
    "p_0a14": "Población 0-14 años", "p_15a29": "Población 15-29 años",
    "p_30a59": "Población 30-59 años", "p_60ymas": "Población 60+ años",
    "pcon_disc": "Población con discapacidad", "p15ym_se": "Población sin escolaridad (15+)",
    "vph_inter": "Viviendas con internet", "vph_autom": "Viviendas con vehículo",
    "pder_ss": "Población con afiliación a servicios de salud", "pder_imss": "Cobertura IMSS",
    "pder_iste": "Cobertura ISSSTE", "pder_segpub": "Cobertura seguro público/privado",
    "psinder": "Población sin cobertura de salud",
}

CATEGORIAS = {
    "Vivienda": ["vivtot", "tvivparhab", "vivpar_des", "vph_pisoti", "vph_c_elec", "vph_excsa", "vph_drenaj"],
    "Poblacion": ["pobtot", "pobfem", "pobmas", "p_0a14", "p_15a29", "p_30a59", "p_60ymas", "pcon_disc"],
    "Educacion_Socioeconomico": ["p15ym_se", "vph_inter", "vph_autom"],
    "Salud": ["pder_ss", "pder_imss", "pder_iste", "pder_segpub", "psinder"],
}

# INEGI no publica estas variables a nivel AGEB en el Censo 2020 (el desglose de edad a ese
# nivel de detalle solo existe a partir de municipio hacia arriba); no es un dato faltante ni
# un error del ETL, es una limitación real de la fuente. Ver etl_local.CENSO_COLUMN_MAP.
VARIABLES_NO_DISPONIBLES_AGEB = {"p_15a29", "p_30a59"}


class ZonaNoEncontradaError(Exception):
    pass


def _lista_agebs(rows) -> list[dict]:
    """Extrae de un conjunto de filas censales la lista auditable de AGEBs incluidos
    (clave completa, clave corta y población total de cada uno)."""
    return [
        {"cve_geo": row["cve_geo"], "cve_ageb": row["cve_ageb"], "pobtot": row["pobtot"] or 0.0}
        for row in rows
    ]


def buscar_centros(tipo_busqueda: str, valor_busqueda: str, municipio: str | None = None) -> list[dict]:
    """Busca Colonia/CP por nombre y devuelve, por cada zona que coincide: su id
    (colonias_cp.id), el/los nombre(s) de colonia que agrupa, su CP y el centro
    (lat/lon) de su polígono — para usarlas luego en analizar_zonas().

    municipio (opcional): nombre exacto tal como está en MUNICIPIOS_BC (p. ej. "Tijuana") —
    si se da, solo busca zonas de ESE municipio. Sin esto, "Zona Centro" encuentra resultados
    de Tijuana, Mexicali, Ensenada, etc. a la vez, todos mezclados; con el municipio elegido
    en el selector de arriba, tiene más sentido buscar solo ahí.
    """
    if tipo_busqueda not in ("Colonia", "CP"):
        raise ValueError("tipo_busqueda debe ser 'Colonia' o 'CP'.")

    conn = get_connection(SQLITE_DB_PATH)
    conn.create_function("sin_acentos", 1, _sin_acentos)
    try:
        filtro_columna = "colonia" if tipo_busqueda == "Colonia" else "cp"
        query = f"""
            SELECT id, cp, colonia, municipio, rings_json FROM colonias_cp
            WHERE sin_acentos({filtro_columna}) LIKE sin_acentos(?)
        """
        args = [f"%{valor_busqueda}%"]
        if municipio:
            query += " AND sin_acentos(municipio) = sin_acentos(?)"
            args.append(municipio)
        rows = conn.execute(query + ";", args).fetchall()

        resultados = []
        for row in rows:
            rings = json.loads(row["rings_json"])
            cx, cy = multiring_centroid(rings)  # cx=lon, cy=lat
            # Algunas fuentes (p. ej. el catálogo nacional de CP de Correos de México) solo
            # traen el polígono y el código postal, sin nombre de colonia — se deja un texto
            # explícito en vez de None, que rompería cualquier lugar que arme HTML con esto.
            colonia = row["colonia"] or "(sin nombre de colonia — solo polígono de CP)"
            resultados.append({
                "id": row["id"],
                "cp": row["cp"],
                "colonia": colonia,
                "municipio": row["municipio"] or "sin identificar",
                "lat": cy,
                "lon": cx,
            })
        return resultados
    finally:
        conn.close()


def analizar_zonas(zonas: list[dict], radio_km: float | None = None) -> tuple[dict[str, float], int, list[dict]]:
    """Agrega el censo de las zonas (Colonia/CP, como las devuelve buscar_centros()) dadas.

    Sin radio_km: usa la asignación Colonia/CP -> AGEB ya calculada en el ETL (por nombre).
    Con radio_km: agrega los AGEBs cuyo centroide cae dentro de radio_km de CADA zona
    (unión sin duplicar), útil cuando el catálogo solo tiene geometría a nivel de código
    postal y puede agrupar varias colonias reales en un mismo polígono.
    """
    if not zonas:
        raise ZonaNoEncontradaError("No hay zonas seleccionadas.")

    conn = get_connection(SQLITE_DB_PATH)
    try:
        if radio_km:
            if radio_km <= 0:
                raise ValueError("radio_km debe ser mayor que 0.")
            query = """
                SELECT ic.*, g.centroid_x, g.centroid_y
                FROM inegi_geometrias g
                JOIN inegi_censo ic ON ic.cve_geo = g.cve_geo
            """
            rows = conn.execute(query).fetchall()
            incluidas: dict[str, object] = {}
            for zona in zonas:
                for row in rows:
                    if row["cve_geo"] in incluidas:
                        continue
                    if haversine_km(zona["lat"], zona["lon"], row["centroid_y"], row["centroid_x"]) <= radio_km:
                        incluidas[row["cve_geo"]] = row
            seleccionadas = list(incluidas.values())
        else:
            ids = [z["id"] for z in zonas]
            placeholders = ",".join("?" for _ in ids)
            query = f"""
                SELECT DISTINCT ic.*
                FROM colonia_ageb_asignacion a
                JOIN inegi_censo ic ON ic.cve_geo = a.cve_geo
                WHERE a.colonia_cp_id IN ({placeholders});
            """
            seleccionadas = conn.execute(query, ids).fetchall()

        if not seleccionadas:
            raise ZonaNoEncontradaError("No se encontraron AGEBs para las zonas seleccionadas.")

        totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
        for row in seleccionadas:
            for col in NUMERIC_CENSO_COLUMNS:
                totals[col] += row[col] or 0.0

        logger.info("Consulta exitosa: %d AGEBs agregados de %d zona(s).", len(seleccionadas), len(zonas))
        return totals, len(seleccionadas), _lista_agebs(seleccionadas)
    finally:
        conn.close()


def analizar_locacion(
    tipo_busqueda: str,
    valor_busqueda: str,
    radio_km: float | None = None,
    zona_ids: set[int] | None = None,
    municipio: str | None = None,
) -> tuple[dict[str, float], list[dict], list[dict], list[dict]]:
    """Punto de entrada principal de consulta. Devuelve (totals, agebs, zonas_todas, zonas_usadas).

    zonas_todas: todas las zonas (Colonia/CP) que coincidieron con la búsqueda por nombre
    (vacío si tipo_busqueda == 'AGEB', que no pasa por el catálogo de colonias).
    zonas_usadas: subconjunto de zonas_todas realmente agregado — todas por defecto, o solo
    las que el llamador filtró explícitamente vía zona_ids (para permitir al usuario
    incluir/excluir zonas ambiguas antes de sumar el censo).
    municipio: nombre exacto (MUNICIPIOS_BC) para restringir la búsqueda a un solo municipio
    (p. ej. cuando el usuario ya eligió uno en el selector) — ver buscar_centros().
    """
    if tipo_busqueda not in ("Colonia", "CP", "AGEB"):
        raise ValueError("tipo_busqueda debe ser 'Colonia', 'CP' o 'AGEB'.")

    logger.info("Consultando %s = '%s'...", tipo_busqueda, valor_busqueda)

    if tipo_busqueda == "AGEB":
        if radio_km:
            raise ValueError("El radio no aplica a búsquedas por AGEB (ya es la unidad geográfica mínima).")
        conn = get_connection(SQLITE_DB_PATH)
        try:
            valor_norm = valor_busqueda.strip()
            if municipio:
                cve_mun = next((k for k, v in MUNICIPIOS_BC.items() if v == municipio), None)
                query = "SELECT * FROM inegi_censo WHERE (cve_ageb = ? OR cve_geo = ?) AND cve_mun = ?;"
                rows = conn.execute(query, (valor_norm.zfill(4), valor_norm, cve_mun)).fetchall()
            else:
                query = "SELECT * FROM inegi_censo WHERE cve_ageb = ? OR cve_geo = ?;"
                rows = conn.execute(query, (valor_norm.zfill(4), valor_norm)).fetchall()
            if not rows:
                raise ZonaNoEncontradaError(f"No se encontraron resultados para AGEB = '{valor_busqueda}'.")
            totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
            for row in rows:
                for col in NUMERIC_CENSO_COLUMNS:
                    totals[col] += row[col] or 0.0
            return totals, _lista_agebs(rows), [], []
        finally:
            conn.close()

    zonas_todas = buscar_centros(tipo_busqueda, valor_busqueda, municipio=municipio)
    if not zonas_todas:
        detalle = f" en {municipio}" if municipio else ""
        raise ZonaNoEncontradaError(f"No se encontraron resultados para {tipo_busqueda} = '{valor_busqueda}'{detalle}.")

    if zona_ids is not None:
        zonas_usar = [z for z in zonas_todas if z["id"] in zona_ids]
        if not zonas_usar:
            raise ValueError("No hay ninguna zona seleccionada. Marca al menos una para continuar.")
    else:
        zonas_usar = zonas_todas

    totals, _n, agebs = analizar_zonas(zonas_usar, radio_km)
    return totals, agebs, zonas_todas, zonas_usar


def analizar_por_radio(lat: float, lon: float, radio_km: float) -> tuple[dict[str, float], int, list[dict]]:
    """Agrega el censo de todos los AGEBs cuyo centroide cae dentro de radio_km del punto (lat, lon)."""
    zona_generica = {"id": None, "cp": None, "colonia": None, "lat": lat, "lon": lon}
    return analizar_zonas([zona_generica], radio_km)


def analizar_municipio(cve_mun: str) -> tuple[dict[str, float], list[dict]]:
    """Agrega el censo de TODOS los AGEBs de un municipio completo (todas sus colonias/CP,
    sin necesidad de buscarlas una por una) — para el selector de municipio del mapa, que
    da un resumen general de la ciudad entera (vivienda, población, salud, NSE, etc.) igual
    que cualquier otra consulta. cve_mun debe ser una de las claves de MUNICIPIOS_BC
    ('001'..'006')."""
    if cve_mun not in MUNICIPIOS_BC:
        raise ValueError(f"Municipio desconocido: '{cve_mun}'.")
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute("SELECT * FROM inegi_censo WHERE cve_mun = ?;", (cve_mun,)).fetchall()
    finally:
        conn.close()

    if not rows:
        if cve_mun == "007":
            # San Felipe se creó como municipio en 2021 (separado de Mexicali), DESPUÉS del
            # Censo 2020 — el Marco Geoestadístico (geometría) ya lo trae como municipio
            # propio, pero el censo tabulado todavía cuenta ese territorio dentro de
            # Mexicali. No es un error de carga: es que INEGI aún no publica un censo
            # tabulado con el municipio nuevo.
            raise ZonaNoEncontradaError(
                "San Felipe se creó como municipio en 2021, después del Censo 2020 — INEGI "
                "todavía no publica un censo tabulado para este municipio nuevo (esa "
                "población sigue contada dentro de Mexicali). Búscalo como parte de Mexicali "
                "por ahora."
            )
        raise ZonaNoEncontradaError(f"No hay AGEBs cargados para el municipio {MUNICIPIOS_BC[cve_mun]}.")

    totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
    for row in rows:
        for col in NUMERIC_CENSO_COLUMNS:
            totals[col] += row[col] or 0.0

    logger.info("Consulta exitosa: municipio %s, %d AGEBs agregados.", MUNICIPIOS_BC[cve_mun], len(rows))
    return totals, _lista_agebs(rows)


def totales_por_agebs(cve_geos: list[str]) -> tuple[dict[str, float], list[dict]]:
    """Agrega el censo de un conjunto arbitrario de AGEBs ya conocidos (por cve_geo) — usado
    para recalcular totals cuando el usuario filtra una consulta más grande (p. ej. un
    municipio completo) a solo los AGEBs de cierto Nivel Socioeconómico, en vez de tener que
    rearmar la consulta original desde cero."""
    if not cve_geos:
        raise ZonaNoEncontradaError("No hay AGEBs para agregar (filtro vacío).")
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT * FROM inegi_censo WHERE cve_geo IN ({placeholders});", cve_geos
        ).fetchall()
    finally:
        conn.close()
    if not rows:
        raise ZonaNoEncontradaError("No se encontraron datos censales para los AGEBs filtrados.")

    totals = {col: 0.0 for col in NUMERIC_CENSO_COLUMNS}
    for row in rows:
        for col in NUMERIC_CENSO_COLUMNS:
            totals[col] += row[col] or 0.0
    return totals, _lista_agebs(rows)


def colonias_para_agebs(cve_geos: list[str]) -> list[dict]:
    """Colonias/CP (con su municipio) que caen dentro de alguno de los AGEBs dados — la
    relación inversa de analizar_zonas(): en vez de "dada una colonia, qué AGEBs le
    corresponden", aquí es "dado un conjunto de AGEBs (p. ej. los de cierto Nivel
    Socioeconómico dentro de un municipio), qué colonias/CP reales caen ahí" — para que el
    filtro por NSE no se quede solo en un mapa de colores, sino que diga en qué colonias
    buscar en la vida real. Usa la misma asignación por centroide ya calculada en el ETL
    (colonia_ageb_asignacion), así que es instantáneo (sin recalcular geometría)."""
    if not cve_geos:
        return []
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT DISTINCT c.cp, c.colonia, c.municipio
            FROM colonia_ageb_asignacion a
            JOIN colonias_cp c ON c.id = a.colonia_cp_id
            WHERE a.cve_geo IN ({placeholders})
            ORDER BY c.municipio, c.colonia;
            """,
            cve_geos,
        ).fetchall()
    finally:
        conn.close()
    return [
        {"cp": r["cp"], "colonia": r["colonia"] or "(sin nombre de colonia — solo polígono de CP)",
         "municipio": r["municipio"] or "sin identificar"}
        for r in rows
    ]


def identificar_punto(lat: float, lon: float) -> dict:
    """Dado un punto (lat, lon) escrito a mano, identifica en qué AGEB cae exactamente y
    qué Colonia/CP lo contiene (punto-en-polígono contra la geometría real de INEGI ya
    cargada). Así el usuario ve qué representa realmente la coordenada que escribió, en vez
    de confiar a ciegas en el número que tecleó."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        punto = (lon, lat)
        ageb = None
        for row in conn.execute(
            "SELECT cve_geo, cve_ageb, rings_json FROM inegi_geometrias WHERE rings_json IS NOT NULL;"
        ):
            rings = json.loads(row["rings_json"])
            if point_in_multiring(punto, rings):
                ageb = {"cve_geo": row["cve_geo"], "cve_ageb": row["cve_ageb"]}
                break

        zonas = []
        for row in conn.execute("SELECT id, cp, colonia, municipio, rings_json FROM colonias_cp;"):
            rings = json.loads(row["rings_json"])
            if point_in_multiring(punto, rings):
                # Ver comentario en buscar_centros(): algunas fuentes no traen nombre de
                # colonia (solo polígono de CP) — sin este respaldo, None rompe el HTML.
                colonia = row["colonia"] or "(sin nombre de colonia — solo polígono de CP)"
                zonas.append({
                    "id": row["id"], "cp": row["cp"], "colonia": colonia,
                    "municipio": row["municipio"] or "sin identificar",
                })

        return {"ageb": ageb, "zonas": zonas}
    finally:
        conn.close()


def analizar_por_coordenada(
    lat: float, lon: float, radio_km: float | None = None
) -> tuple[dict[str, float], list[dict], dict]:
    """Punto de entrada para búsquedas por coordenada exacta (lat, lon).

    Con radio_km: agrega el censo de todos los AGEBs dentro de ese radio del punto (igual
    que analizar_por_radio). Sin radio_km: identifica el AGEB exacto que contiene el punto y
    devuelve solo ese (más preciso, pero falla si el punto cae fuera de cualquier AGEB — en
    ese caso hay que agregar un radio). Devuelve (totals, agebs, info_punto), donde
    info_punto trae la Colonia/CP y el AGEB donde cae la coordenada, para mostrarlo al usuario.
    """
    info = identificar_punto(lat, lon)

    if radio_km:
        zona_generica = {"id": None, "cp": None, "colonia": None, "lat": lat, "lon": lon}
        totals, _n, agebs = analizar_zonas([zona_generica], radio_km)
        return totals, agebs, info

    if not info["ageb"]:
        raise ZonaNoEncontradaError(
            "Esa coordenada no cae dentro de ningún AGEB conocido (puede estar fuera de la "
            "zona urbana cubierta por el Marco Geoestadístico). Agrega un radio (km) para "
            "agregar el área alrededor del punto en vez de un AGEB exacto."
        )

    conn = get_connection(SQLITE_DB_PATH)
    try:
        row = conn.execute("SELECT * FROM inegi_censo WHERE cve_geo = ?;", (info["ageb"]["cve_geo"],)).fetchone()
    finally:
        conn.close()

    if not row:
        raise ZonaNoEncontradaError(
            f"El AGEB {info['ageb']['cve_ageb']} que contiene esa coordenada no tiene datos "
            "censales cargados."
        )

    totals = {col: (row[col] or 0.0) for col in NUMERIC_CENSO_COLUMNS}
    return totals, _lista_agebs([row]), info


def rings_por_agebs(cve_geos: list[str]) -> dict[str, list]:
    """Devuelve {cve_geo: rings} para dibujar el polígono de cada AGEB en el mapa."""
    if not cve_geos:
        return {}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT cve_geo, rings_json FROM inegi_geometrias WHERE cve_geo IN ({placeholders});",
            cve_geos,
        ).fetchall()
        return {row["cve_geo"]: json.loads(row["rings_json"]) for row in rows if row["rings_json"]}
    finally:
        conn.close()


CVE_ENT_BC = "02"
# Códigos oficiales de municipio (INEGI) de Baja California, incluye San Quintín (006, creado
# en 2020 a partir de territorio de Ensenada — ya viene separado en el Censo 2020).
MUNICIPIOS_BC = {
    "001": "Ensenada", "002": "Mexicali", "003": "Tecate",
    "004": "Tijuana", "005": "Playas de Rosarito", "006": "San Quintín",
    "007": "San Felipe",
}
CVE_MUN_TIJUANA = "004"  # nombre histórico del símbolo; se mantiene por compatibilidad


def guardar_analisis(
    nombre: str, destino: str, query_string: str,
    resumen_poblacion: str | None = None, resumen_valor: str | None = None,
) -> int:
    """Guarda un análisis/lugar para volver a abrirlo después con un clic — se guarda la
    query string completa (no cada campo por separado, ver SCHEMA en db_sqlite.py) porque
    tanto la búsqueda normal como la de zonas combinadas ya codifican todo su estado ahí.

    resumen_poblacion/resumen_valor son un snapshot de texto (no se recalculan al reabrir) de
    la población y de "Valor de la zona" al momento de guardar — en /comparar ese cálculo
    depende de inputs manuales (pacientes actuales, frecuencias marcadas) que la query string
    no captura, así que sin este snapshot la lista de guardados no diría nada útil de un
    vistazo (pedido explícito del usuario, sobre todo para zonas de flujo)."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        cur = conn.execute(
            "INSERT INTO analisis_guardados (nombre, destino, query_string, resumen_poblacion, resumen_valor) "
            "VALUES (?, ?, ?, ?, ?);",
            (nombre.strip()[:120], destino, query_string, resumen_poblacion or None, resumen_valor or None),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def listar_analisis_guardados() -> list[dict]:
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT id, nombre, destino, query_string, resumen_poblacion, resumen_valor, creado_en "
            "FROM analisis_guardados ORDER BY creado_en DESC, id DESC;"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


def eliminar_analisis_guardado(id_: int) -> None:
    conn = get_connection(SQLITE_DB_PATH)
    try:
        conn.execute("DELETE FROM analisis_guardados WHERE id = ?;", (id_,))
        conn.commit()
    finally:
        conn.close()


def centroides_por_agebs(cve_geos: list[str]) -> dict[str, tuple[float, float]]:
    """{cve_geo: (lon, lat)} para un conjunto de AGEBs — usado para detectar zonas "outlier"
    (muy alejadas del resto) en un análisis combinado de varias zonas, ver
    server.render_zonas_combinadas."""
    if not cve_geos:
        return {}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT cve_geo, centroid_x, centroid_y FROM inegi_geometrias WHERE cve_geo IN ({placeholders});",
            cve_geos,
        ).fetchall()
        return {r["cve_geo"]: (r["centroid_x"], r["centroid_y"]) for r in rows}
    finally:
        conn.close()


def rings_municipio(cve_mun: str | None = None) -> dict[str, list]:
    """Polígonos de AGEB para usar como mapa base de contexto. Sin cve_mun: TODO Baja
    California (los 7 municipios ya cargados) — así el mapa de fondo siempre muestra el
    estado completo sin importar en qué ciudad cae la consulta. Con cve_mun: solo ese
    municipio (más rápido de dibujar si se sabe que la consulta es de una sola ciudad)."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        if cve_mun:
            rows = conn.execute(
                "SELECT cve_geo, rings_json FROM inegi_geometrias WHERE cve_mun = ? AND rings_json IS NOT NULL;",
                (cve_mun,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT cve_geo, rings_json FROM inegi_geometrias WHERE cve_ent = ? AND rings_json IS NOT NULL;",
                (CVE_ENT_BC,),
            ).fetchall()
        return {row["cve_geo"]: json.loads(row["rings_json"]) for row in rows}
    finally:
        conn.close()


ORDEN_CATEGORIAS_DENUE = [
    "Farmacias",
    "Hospitales",
    "Clínicas (consultorios médicos agrupados)",
    "Consultorios médicos (general y especializada)",
    "Consultorios dentales",
    "Laboratorios clínicos / de análisis",
    "Laboratorios de imagen (radiología/imagenología)",
    "Otros consultorios y servicios de salud",
    "Asistencia social (guarderías, asilos, orientación, etc.)",
    "Otros servicios de salud",
]


def contar_unidades_salud(cve_geos: list[str]) -> dict | None:
    """Cuenta unidades de salud (DENUE, INEGI — sector SCIAN 62) dentro de los AGEBs dados,
    desglosadas por categoría (consultorios médicos, dentales, laboratorios, hospitales,
    asistencia social) — el sector SCIAN 62 es "Salud Y ASISTENCIA SOCIAL", así que sin
    desglosar mezcla clínicas con guarderías/asilos/grupos de autoayuda, que infla el total
    de forma confusa. Devuelve None si la tabla denue_salud no existe (DENUE no cargado —
    es opcional, ver local_engine.etl_local.load_denue_salud)."""
    if not cve_geos:
        return {"unidades_salud": 0, "laboratorios_diagnostico": 0, "desglose": {}}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT categoria, COUNT(*) AS total, COALESCE(SUM(es_laboratorio), 0) AS labs
            FROM denue_salud WHERE cve_geo IN ({placeholders}) GROUP BY categoria;
            """,
            cve_geos,
        ).fetchall()
        desglose = {r["categoria"]: r["total"] for r in rows}
        total = sum(desglose.values())
        labs = sum(r["labs"] or 0 for r in rows)
        return {"unidades_salud": total, "laboratorios_diagnostico": labs, "desglose": desglose}
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


def establecimientos_por_categoria(cve_geos: list[str], categoria: str) -> list[dict]:
    """Lista (no solo cuenta) los establecimientos del DENUE de una categoría dada dentro de
    los AGEBs consultados — nombre real del negocio y una dirección aproximada, para el
    desglose "clic para ver cuáles son" del reporte de Salud (ver contar_unidades_salud, que
    da el conteo por categoría; esta función da el detalle detrás de cada número)."""
    if not cve_geos:
        return []
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT nombre_estab, direccion FROM denue_salud
            WHERE cve_geo IN ({placeholders}) AND categoria = ?
            ORDER BY nombre_estab;
            """,
            [*cve_geos, categoria],
        ).fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()
    return [
        {"nombre": r["nombre_estab"] or "(sin nombre en el DENUE)", "direccion": r["direccion"] or ""}
        for r in rows
    ]


# Tabla de retorno de clientes ("Valor de la zona") — tasas propias del negocio del usuario
# (no son datos del censo), movida aquí (antes vivía solo en server.py) para que tanto la
# página web (cálculo interactivo en JS, ver RETORNO_CLIENTES_SCRIPT) como el Excel/CSV
# exportado (calcular_valor_zona_default, más abajo) usen la MISMA fuente en vez de tener la
# tabla de tasas duplicada y con riesgo de que se desincronicen entre sí.
RETORNO_FRECUENCIAS = [
    # (id, etiqueta, tasa%, multiplicador anual, es_directo, color)
    ("mes", "Cada mes", 2.80, 12, False, "#2f9e6f"),
    ("2a3meses", "Cada 2 a 3 meses", 11.70, 4, False, "#3a7ca8"),
    ("6meses", "Cada 6 meses", 17.10, 2, False, "#c9973a"),
    ("anio", "Cada año", 24.50, 1, False, "#b0546b"),
    ("enfermo", "Cada que me enfermo", 4.58, None, True, "#6f5a9a"),
]
DIAS_HABILES_ANIO = 313  # 52 semanas x 6 días (lunes a sábado), fijo — no configurable


def calcular_valor_zona_default(totals: dict[str, float]) -> dict | None:
    """"Valor de la zona" con TODAS las frecuencias marcadas (el estado por default de la
    página web) y "pacientes actuales" = 0 — usado en el Excel/CSV exportado, que no puede
    reflejar los checkboxes/input que el usuario ajusta interactivamente en el navegador (ver
    RETORNO_CLIENTES_SCRIPT en server.py). Devuelve None si la zona no tiene población."""
    poblacion_total = totals.get("pobtot") or 0
    if not poblacion_total:
        return None
    tasa_acumulada = sum(tasa if directo else tasa * mult for _, _, tasa, mult, directo, _ in RETORNO_FRECUENCIAS)
    ordenes_anio = poblacion_total * (tasa_acumulada / 100)
    return {
        "poblacion_total": poblacion_total,
        "tasa_acumulada": round(tasa_acumulada, 2),
        "ordenes_anio": round(ordenes_anio, 0),
        "ordenes_dia": round(ordenes_anio / DIAS_HABILES_ANIO, 1),
    }


CADENA_PROPIA_MERCADO_LAB = "Certus"  # la cadena del usuario, para resaltarla en el modelaje


def listar_laboratorios_mercado() -> list[dict]:
    """Barrido curado a mano (Google Maps) de laboratorios de análisis clínicos de Tijuana —
    universo de competidores real para el modelaje de "% de mercado", con coordenadas exactas
    y nombre de cadena limpio (ver etl_local.py:load_laboratorios_mercado). Vacío si la tabla
    no existe (CSV no cargado, es opcional)."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT nombre, cadena, tipo, colonia, direccion, telefono, lat, lon, "
            "calificacion, num_resenas FROM laboratorios_mercado ORDER BY cadena, nombre;"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


def analizar_mercado_laboratorios() -> dict:
    """Universo real de laboratorios de análisis clínicos de Tijuana (barrido curado de Google
    Maps, agrupado por cadena) + población y demanda estimada de toda la ciudad — la base para
    comparar cuántas sucursales y qué % de la demanda estimada representa la cadena propia
    (CADENA_PROPIA_MERCADO_LAB) frente al resto del mercado, en
    server.py:render_mercado_laboratorios. Es el mismo tipo de pregunta que "Valor de la zona"
    (_retorno_html) pero a escala de TODA la ciudad, no de una sola zona/AGEB, y comparando
    contra un universo real de competidores geolocalizados en vez de solo población.
    Por ahora está fijo a Tijuana porque es la única ciudad con este barrido; si se junta el
    barrido de otro municipio, esto se generaliza con un parámetro como analizar_municipio."""
    laboratorios = listar_laboratorios_mercado()
    totals, _agebs = analizar_municipio(CVE_MUN_TIJUANA)
    valor_zona = calcular_valor_zona_default(totals)

    por_cadena: dict[str, dict] = {}
    for lab in laboratorios:
        c = por_cadena.setdefault(lab["cadena"], {"cadena": lab["cadena"], "tipo": lab["tipo"], "sucursales": 0})
        c["sucursales"] += 1
    total = len(laboratorios)
    cadenas_ordenadas = sorted(por_cadena.values(), key=lambda c: -c["sucursales"])
    for c in cadenas_ordenadas:
        c["pct"] = round((c["sucursales"] / total) * 100, 2) if total else 0

    propia = por_cadena.get(CADENA_PROPIA_MERCADO_LAB)

    return {
        "municipio": "Tijuana",
        "poblacion_total": totals.get("pobtot") or 0,
        "total_laboratorios": total,
        "laboratorios": laboratorios,
        "cadenas": cadenas_ordenadas,
        "cadena_propia": CADENA_PROPIA_MERCADO_LAB,
        "sucursales_propias": propia["sucursales"] if propia else 0,
        "pct_sucursales_propias": propia["pct"] if propia else 0,
        "demanda_estimada_anual": valor_zona["ordenes_anio"] if valor_zona else 0,
        "tasa_acumulada": valor_zona["tasa_acumulada"] if valor_zona else 0,
    }


def listar_empresas_nomina() -> list[dict]:
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT nombre, razon_social, sector, rango_personal, direccion, colonia, telefono, "
            "lat, lon, fuente FROM empresas_nomina ORDER BY nombre;"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


def _empleados_estimados(rango_personal: str | None) -> int | None:
    """Extrae un número de empleados del texto libre de 'rango_personal' — puede venir como una
    cifra directa ("200 empleados", del directorio de maquiladoras) o como un rango estilo DENUE
    ("101 a 250 personas"), en cuyo caso se toma el promedio del rango. Si no hay ningún dígito
    (fila incompleta), regresa None en vez de inventar un valor."""
    if not rango_personal:
        return None
    numeros = [int(n) for n in re.findall(r"\d+", rango_personal)]
    if not numeros:
        return None
    if len(numeros) == 1:
        return numeros[0]
    return round(sum(numeros) / len(numeros))


def analizar_empresas_nomina() -> dict:
    """Empresas/maquiladoras con nómina alta (101+ empleados) en Tijuana — combina un directorio
    de maquiladoras curado a mano por el usuario con extractos de DENUE filtrados por rango de
    personal ocupado (ver etl_local.py:load_empresas_nomina). A diferencia de hospitales/
    laboratorios, la mayoría de las filas no trae coordenadas (el directorio de maquiladoras no
    las publica), así que el análisis se apoya en la tabla/ranking por número de empleados y en
    el desglose por sector, no en un mapa completo — el mapa solo muestra las filas que sí
    tienen lat/lon."""
    empresas = listar_empresas_nomina()
    for e in empresas:
        e["empleados_estimados"] = _empleados_estimados(e["rango_personal"])

    total_empresas = len(empresas)
    total_empleados = sum(e["empleados_estimados"] or 0 for e in empresas)

    por_sector: dict[str, dict] = {}
    for e in empresas:
        s = e["sector"] or "Sin clasificar"
        d = por_sector.setdefault(s, {"sector": s, "empresas": 0, "empleados": 0})
        d["empresas"] += 1
        d["empleados"] += e["empleados_estimados"] or 0
    sectores_ordenados = sorted(por_sector.values(), key=lambda d: -d["empleados"])
    for d in sectores_ordenados:
        d["pct_empleados"] = round((d["empleados"] / total_empleados) * 100, 2) if total_empleados else 0

    empresas_ordenadas = sorted(empresas, key=lambda e: -(e["empleados_estimados"] or 0))
    con_coordenadas = [e for e in empresas if e["lat"] is not None and e["lon"] is not None]

    return {
        "municipio": "Tijuana",
        "total_empresas": total_empresas,
        "total_empleados_estimados": total_empleados,
        "sectores": sectores_ordenados,
        "empresas": empresas_ordenadas,
        "con_coordenadas": con_coordenadas,
    }


RADIO_HOSPITALES_CARDIO_KM = 5.0
MIN_HOSPITALES_CARDIO_CERCANOS = 3


def hospitales_cardio_cercanos(cve_geos: list[str]) -> list[tuple[float, dict]]:
    """[(distancia_km, hospital)] ordenado por distancia desde el centro de masa de los AGEBs
    dados — misma lógica de server.py:_hospitales_cardio_html (radio de 5 km, o los 3 más
    cercanos si el radio deja menos de eso), factorizada aquí para que el Excel/CSV exportado
    use el mismo criterio de "cercanía" que la caja que se ve en la página web. Vacío si no hay
    AGEBs, no hay hospitales cargados, ninguno tiene coordenadas, o la zona no toca Tijuana
    (todo el catálogo es de Tijuana — sin este filtro, una zona en Ensenada terminaría
    "cerca" de los 3 hospitales de Tijuana menos lejanos, a 80+ km de distancia real).
    cve_geo tiene el formato cve_ent(2)+cve_mun(3)+cve_loc(4)+cve_ageb(4) — cve_mun de Tijuana
    es "004"."""
    if not any(cve[2:5] == "004" for cve in cve_geos):
        return []
    hospitales = listar_hospitales_cardio()
    if not hospitales or not cve_geos:
        return []
    centroides = centroides_por_agebs(cve_geos)
    puntos = list(centroides.values())
    if not puntos:
        return []
    lon_centro = sum(p[0] for p in puntos) / len(puntos)
    lat_centro = sum(p[1] for p in puntos) / len(puntos)

    con_distancia = [
        (haversine_km(lat_centro, lon_centro, h["lat"], h["lon"]), h)
        for h in hospitales if h["lat"] is not None and h["lon"] is not None
    ]
    con_distancia.sort(key=lambda t: t[0])

    cercanos = [t for t in con_distancia if t[0] <= RADIO_HOSPITALES_CARDIO_KM]
    if len(cercanos) < MIN_HOSPITALES_CARDIO_CERCANOS:
        cercanos = con_distancia[:MIN_HOSPITALES_CARDIO_CERCANOS]
    return cercanos


RADIO_LABORATORIOS_CERCANOS_KM = 3.0
MIN_LABORATORIOS_CERCANOS = 3


def laboratorios_cercanos(cve_geos: list[str]) -> list[tuple[float, dict]]:
    """[(distancia_km, laboratorio)] ordenado por distancia desde el centro de masa de los
    AGEBs dados — misma lógica que hospitales_cardio_cercanos (radio fijo, o los N más
    cercanos si el radio deja menos de eso), pero sobre el barrido de laboratorios de análisis
    de Tijuana (listar_laboratorios_mercado) en vez del catálogo de hospitales. Muestra qué
    competidores reales (cadena + independientes) hay cerca de la zona que se está analizando,
    algo que antes solo existía a nivel de TODA la ciudad en /mercado-laboratorios. Vacío si la
    zona no toca Tijuana (todo el barrido es de Tijuana) o ningún laboratorio tiene
    coordenadas."""
    if not any(cve[2:5] == "004" for cve in cve_geos):
        return []
    laboratorios = listar_laboratorios_mercado()
    if not laboratorios or not cve_geos:
        return []
    centroides = centroides_por_agebs(cve_geos)
    puntos = list(centroides.values())
    if not puntos:
        return []
    lon_centro = sum(p[0] for p in puntos) / len(puntos)
    lat_centro = sum(p[1] for p in puntos) / len(puntos)

    con_distancia = [
        (haversine_km(lat_centro, lon_centro, lab["lat"], lab["lon"]), lab)
        for lab in laboratorios if lab["lat"] is not None and lab["lon"] is not None
    ]
    con_distancia.sort(key=lambda t: t[0])

    cercanos = [t for t in con_distancia if t[0] <= RADIO_LABORATORIOS_CERCANOS_KM]
    if len(cercanos) < MIN_LABORATORIOS_CERCANOS:
        cercanos = con_distancia[:MIN_LABORATORIOS_CERCANOS]
    return cercanos


def listar_gasolineras() -> list[dict]:
    """Padrón de gasolineras de Baja California (fuente: CNE/CRE, los 7 municipios — no solo
    Tijuana, a diferencia de hospitales/laboratorios/empresas) con precios vigentes. "nombre" es
    la razón social del permisionario tal como la publica la CNE (ese padrón no distingue marca
    comercial de razón social), ver etl_local.py:load_gasolineras."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT nombre, marca, permisionario, numero_permiso, direccion, colonia, municipio, "
            "lat, lon, precio_regular, precio_premium, precio_diesel, fuente "
            "FROM gasolineras ORDER BY municipio, nombre;"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


def analizar_gasolineras() -> dict:
    """Resumen estatal de gasolineras — precio promedio por tipo de combustible y desglose por
    municipio, para la página dedicada (/mercado-gasolineras). A diferencia de laboratorios/
    empresas, cubre los 7 municipios de Baja California porque la fuente (CNE) es estatal
    completa, no un barrido manual limitado a Tijuana."""
    gasolineras = listar_gasolineras()
    total = len(gasolineras)

    def _promedio(campo: str) -> float | None:
        valores = [g[campo] for g in gasolineras if g[campo] is not None]
        return round(sum(valores) / len(valores), 2) if valores else None

    por_municipio: dict[str, dict] = {}
    for g in gasolineras:
        mun = g["municipio"] or "Sin resolver"
        d = por_municipio.setdefault(mun, {"municipio": mun, "total": 0, "con_coordenadas": 0, "_lats": [], "_lons": []})
        d["total"] += 1
        if g["lat"] is not None and g["lon"] is not None:
            d["con_coordenadas"] += 1
            d["_lats"].append(g["lat"])
            d["_lons"].append(g["lon"])
    municipios_ordenados = sorted(por_municipio.values(), key=lambda d: -d["total"])
    for d in municipios_ordenados:
        lats, lons = d.pop("_lats"), d.pop("_lons")
        # Centro real (promedio de sus propias gasolineras geolocalizadas), no una coordenada
        # fija de ciudad — así el mapa centra justo donde está el grueso de las estaciones de
        # ese municipio, sin mantener una tabla de constantes aparte.
        d["lat_centro"] = round(sum(lats) / len(lats), 5) if lats else None
        d["lon_centro"] = round(sum(lons) / len(lons), 5) if lons else None

    con_coordenadas = [g for g in gasolineras if g["lat"] is not None and g["lon"] is not None]

    return {
        "total": total,
        "con_coordenadas": con_coordenadas,
        "gasolineras": gasolineras,
        "municipios": municipios_ordenados,
        "precio_regular_prom": _promedio("precio_regular"),
        "precio_premium_prom": _promedio("precio_premium"),
        "precio_diesel_prom": _promedio("precio_diesel"),
    }


RADIO_GASOLINERAS_CERCANAS_KM = 3.0
MIN_GASOLINERAS_CERCANAS = 3


def gasolineras_cercanas(cve_geos: list[str]) -> list[tuple[float, dict]]:
    """[(distancia_km, gasolinera)] ordenado por distancia desde el centro de masa de los AGEBs
    dados — misma lógica que laboratorios_cercanos/hospitales_cardio_cercanos, pero SIN el
    filtro de "solo si la zona toca Tijuana" (la fuente, CNE, cubre los 7 municipios de Baja
    California, así que aplica a cualquier zona del estado)."""
    gasolineras = listar_gasolineras()
    if not gasolineras or not cve_geos:
        return []
    centroides = centroides_por_agebs(cve_geos)
    puntos = list(centroides.values())
    if not puntos:
        return []
    lon_centro = sum(p[0] for p in puntos) / len(puntos)
    lat_centro = sum(p[1] for p in puntos) / len(puntos)

    con_distancia = [
        (haversine_km(lat_centro, lon_centro, g["lat"], g["lon"]), g)
        for g in gasolineras if g["lat"] is not None and g["lon"] is not None
    ]
    con_distancia.sort(key=lambda t: t[0])

    cercanas = [t for t in con_distancia if t[0] <= RADIO_GASOLINERAS_CERCANAS_KM]
    if len(cercanas) < MIN_GASOLINERAS_CERCANAS:
        cercanas = con_distancia[:MIN_GASOLINERAS_CERCANAS]
    return cercanas


RADIO_EMPRESAS_CERCANAS_KM = 3.0


def empresas_en_zona(cve_geos: list[str]) -> list[dict]:
    """Empresas/maquiladoras con nómina alta (101+ empleados) que caen dentro de la zona dada
    — para estimar público potencial a captar en un sector/zona de interés desde la búsqueda
    normal y desde "comparar" (zonas de flujo). Solo 9 de las 319 empresas cargadas traen
    coordenadas (el directorio de maquiladoras no las publica), así que el criterio principal
    es por COLONIA: se cruzan las colonias reales que caen dentro de los AGEBs dados
    (colonias_para_agebs, misma asignación por centroide del ETL) contra la columna 'colonia'
    de cada empresa (comparación tolerante a mayúsculas/acentos vía _sin_acentos). Las empresas
    con coordenadas exactas se agregan además si caen dentro de RADIO_EMPRESAS_CERCANAS_KM del
    centro de la zona, por si su colonia no coincide textualmente. Vacío si la zona no toca
    Tijuana (todo el catálogo es de Tijuana)."""
    if not any(cve[2:5] == "004" for cve in cve_geos):
        return []
    empresas = listar_empresas_nomina()
    if not empresas or not cve_geos:
        return []

    # Algunas filas de colonias_para_agebs traen varios nombres juntos separados por coma
    # (colonias cuyo polígono resultó idéntico tras deduplicar) — se separan para comparar cada
    # nombre por su cuenta.
    colonias_zona = set()
    for c in colonias_para_agebs(cve_geos):
        if not c["colonia"]:
            continue
        for parte in c["colonia"].split(","):
            parte = _sin_acentos(parte.strip())
            if parte:
                colonias_zona.add(parte)

    centroides = centroides_por_agebs(cve_geos)
    puntos = list(centroides.values())
    lat_centro = lon_centro = None
    if puntos:
        lon_centro = sum(p[0] for p in puntos) / len(puntos)
        lat_centro = sum(p[1] for p in puntos) / len(puntos)

    resultado = []
    vistas = set()
    for e in empresas:
        colonia_empresa = _sin_acentos(e["colonia"]) if e["colonia"] else ""
        # Comparación por contención, no solo igualdad exacta: el directorio de maquiladoras
        # suele dar el nombre corto de la colonia ("El Florido") mientras que el catálogo
        # oficial de colonias/CP lo desglosa por sección ("El Florido 1a. Sección").
        coincide_colonia = bool(colonia_empresa) and any(
            colonia_empresa in cz or cz in colonia_empresa for cz in colonias_zona
        )
        coincide_distancia = (
            lat_centro is not None and e["lat"] is not None and e["lon"] is not None
            and haversine_km(lat_centro, lon_centro, e["lat"], e["lon"]) <= RADIO_EMPRESAS_CERCANAS_KM
        )
        if coincide_colonia or coincide_distancia:
            clave = e["nombre"]
            if clave in vistas:
                continue
            vistas.add(clave)
            e2 = dict(e)
            e2["empleados_estimados"] = _empleados_estimados(e["rango_personal"])
            resultado.append(e2)

    resultado.sort(key=lambda e: -(e["empleados_estimados"] or 0))
    return resultado


def contar_comercios_referencia(cve_geos: list[str]) -> dict | None:
    """Cuenta comercios de referencia (Calimax, Comex, Truper, ...) dentro de los AGEBs dados,
    desglosados por marca — sirve como proxy de perfil de consumidor (ej. presencia de cadenas
    formales de ferretería/pintura/supermercado vs. comercio informal). Devuelve None si la
    tabla denue_comercios no existe (es opcional, ver local_engine.etl_local.load_denue_comercios)."""
    if not cve_geos:
        return {"total": 0, "desglose": {}}
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT marca, COUNT(*) AS total FROM denue_comercios
            WHERE cve_geo IN ({placeholders}) GROUP BY marca;
            """,
            cve_geos,
        ).fetchall()
        desglose = {r["marca"]: r["total"] for r in rows}
        return {"total": sum(desglose.values()), "desglose": desglose}
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()


def establecimientos_por_marca(cve_geos: list[str], marca: str) -> list[dict]:
    """Lista los comercios de una marca (Calimax/Comex/Truper/...) dentro de los AGEBs
    consultados — mismo patrón que establecimientos_por_categoria para salud."""
    if not cve_geos:
        return []
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT nombre_estab, direccion FROM denue_comercios
            WHERE cve_geo IN ({placeholders}) AND marca = ?
            ORDER BY nombre_estab;
            """,
            [*cve_geos, marca],
        ).fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()
    return [
        {"nombre": r["nombre_estab"] or "(sin nombre en el DENUE)", "direccion": r["direccion"] or ""}
        for r in rows
    ]


ETIQUETAS_ESEP = {
    "camas_censables": "Camas censables",
    "consultorios": "Consultorios",
    "quirofanos": "Quirófanos",
    "unidades_dentales": "Unidades dentales",
    "lab_analisis_clinicos": "Laboratorios de análisis clínicos",
    "lab_anatomia_patologica": "Laboratorios de anatomía patológica",
    "salas_radiologia": "Salas de radiología",
    "equipos_rayos_x": "Equipos de rayos X",
    "equipos_resonancia_magnetica": "Equipos de resonancia magnética",
    "equipos_tomografia": "Equipos de tomografía (TAC)",
    "equipos_mamografia": "Equipos de mamografía",
    "equipos_ultrasonido": "Equipos de ultrasonido",
}


def obtener_recursos_hospitalarios(cve_geos: list[str]) -> dict | None:
    """Suma el equipamiento real de hospitales privados (ESEP, INEGI — encuesta directa a
    establecimientos, no un directorio de negocios) dentro de los AGEBs dados: camas,
    quirófanos, unidades dentales y equipos de imagenología (rayos X, resonancia, tomografía,
    mamografía, ultrasonido) — esto reemplaza la necesidad de adivinar por nombre qué
    laboratorios son "de imagen"; aquí el dato viene de la encuesta oficial. Devuelve None si
    la tabla no existe (ESEP no cargado, opcional) o no hay hospitales en la zona."""
    if not cve_geos:
        return None
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        campos = ", ".join(f"COALESCE(SUM({c}), 0) AS {c}" for c in ETIQUETAS_ESEP)
        row = conn.execute(
            f"""
            SELECT COUNT(*) AS n_hospitales, {campos}
            FROM esep_recursos_salud WHERE cve_geo IN ({placeholders});
            """,
            cve_geos,
        ).fetchone()
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()

    if not row or row["n_hospitales"] == 0:
        return None
    return {"n_hospitales": row["n_hospitales"], **{c: row[c] for c in ETIQUETAS_ESEP}}


def listar_hospitales_cardio() -> list[dict]:
    """Catálogo de hospitales privados de Tijuana con capacidad cardiovascular (nivel II/III,
    quirófanos, camas) — sin geocodificar a AGEB (ver etl_local.py:load_hospitales_cardio),
    así que se lista completo en vez de filtrarse por zona; ordenado Nivel III primero."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            "SELECT hospital, nivel, especialidades, quirofanos_min, quirofanos_max, "
            "camas_min, camas_max, notas, lat, lon FROM hospitales_cardio "
            "ORDER BY nivel DESC, hospital ASC;"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


GRADOS_MARGINACION_ORDEN = ["Muy bajo", "Bajo", "Medio", "Alto", "Muy alto"]


def obtener_marginacion(cve_geos: list[str]) -> dict | None:
    """Índice de Marginación Urbana por AGEB de CONAPO (dato OFICIAL de gobierno, no un
    proxy) para el conjunto de AGEBs dado. Promedia el índice normalizado (0-1, donde más
    alto = MENOS marginación/mejor nivel) ponderado por población, y reporta cuántos AGEBs
    caen en cada grado. Devuelve None si la tabla no existe (CONAPO no cargado — opcional)
    o si ninguno de los AGEBs tiene el dato."""
    if not cve_geos:
        return None
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"""
            SELECT poblacion, indice_normalizado, grado_marginacion
            FROM marginacion_ageb WHERE cve_geo IN ({placeholders});
            """,
            cve_geos,
        ).fetchall()
    except sqlite3.OperationalError:
        return None
    finally:
        conn.close()

    filas = [r for r in rows if r["indice_normalizado"] is not None]
    if not filas:
        return None

    pob_total = sum(r["poblacion"] or 0 for r in filas) or len(filas)
    if pob_total > 0 and any(r["poblacion"] for r in filas):
        promedio = sum((r["indice_normalizado"] or 0) * (r["poblacion"] or 0) for r in filas) / pob_total
    else:
        promedio = sum(r["indice_normalizado"] or 0 for r in filas) / len(filas)

    conteo_grados: dict[str, int] = {}
    for r in filas:
        g = r["grado_marginacion"] or "Sin dato"
        conteo_grados[g] = conteo_grados.get(g, 0) + 1
    grado_predominante = max(conteo_grados, key=lambda g: conteo_grados[g])

    return {
        "indice_normalizado_pct": round(promedio * 100, 1),
        "grado_predominante": grado_predominante,
        "conteo_grados": conteo_grados,
        "n_agebs_con_dato": len(filas),
        "n_agebs_total": len(cve_geos),
    }


def geometria_para_mapa(agebs_incluidos: list[dict]) -> tuple[dict[str, list], set[str]]:
    """Reúne los polígonos a dibujar en el mapa: todos los AGEBs del municipio (como fondo
    de contexto, para ver la ciudad completa) y cuáles de ellos son los incluidos en la
    consulta. Devuelve (rings_por_ageb, cve_geo_incluidos)."""
    cve_incluidos = {a["cve_geo"] for a in agebs_incluidos}
    todos = rings_municipio()
    # Por si algún AGEB incluido no perteneciera al municipio base (caso raro/borde), se agrega igual.
    faltantes = cve_incluidos - todos.keys()
    if faltantes:
        todos.update(rings_por_agebs(list(faltantes)))
    return todos, cve_incluidos


def estimar_radio_equivalente_km(cve_geos: list[str]) -> float | None:
    """"Si esta zona fuera un círculo, ¿de qué radio sería?" — da una noción de escala rápida
    (útil sobre todo cuando NO se buscó con un --radio explícito: una colonia o un AGEB no
    traen ese número por sí solos). Se calcula del área REAL de los polígonos incluidos
    (radio = sqrt(área/π), el "radio de círculo equivalente"), no del bounding box — un
    bounding box exagera mucho el tamaño cuando la forma es alargada o irregular (común en
    AGEBs). Es una noción de escala, NO un radio de búsqueda real (la zona real casi nunca es
    un círculo) — se debe mostrar siempre marcado como aproximado."""
    if not cve_geos:
        return None
    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT rings_json FROM inegi_geometrias WHERE cve_geo IN ({placeholders}) AND rings_json IS NOT NULL;",
            cve_geos,
        ).fetchall()
    finally:
        conn.close()
    if not rows:
        return None

    area_km2 = sum(area_km2_multiring(json.loads(row["rings_json"])) for row in rows)
    if area_km2 <= 0:
        return None
    return math.sqrt(area_km2 / math.pi)


def estimar_edades_15_59(totals: dict[str, float]) -> dict[str, float] | None:
    """Si config.TOTAL_15A29_MUNICIPIO/TOTAL_30A59_MUNICIPIO están configurados, prorratea
    el grupo "15-59 años" de la zona consultada usando esa proporción municipal real (dato
    oficial de INEGI a nivel municipio, no a nivel AGEB). Devuelve None si no hay proporción
    configurada, para no inventar cifras sin fuente. Es una ESTIMACIÓN, no un dato oficial
    a nivel AGEB — se debe presentar siempre marcada como tal.
    """
    if not TOTAL_15A29_MUNICIPIO or not TOTAL_30A59_MUNICIPIO:
        return None
    base_municipio = TOTAL_15A29_MUNICIPIO + TOTAL_30A59_MUNICIPIO
    if base_municipio <= 0:
        return None
    proporcion_15a29 = TOTAL_15A29_MUNICIPIO / base_municipio

    resto_15_59 = max(totals.get("pobtot", 0.0) - totals.get("p_0a14", 0.0) - totals.get("p_60ymas", 0.0), 0.0)
    est_15a29 = resto_15_59 * proporcion_15a29
    est_30a59 = resto_15_59 - est_15a29
    return {"p_15a29_est": est_15a29, "p_30a59_est": est_30a59}


def _indice_socioeconomico_bruto(totals: dict[str, float]) -> float | None:
    """Promedio (0-100) de seis tasas de la zona: piso firme, drenaje, electricidad,
    internet, automóvil y escolaridad. Es solo el número crudo — NO clasificar
    Alto/Medio/Bajo con umbrales absolutos sobre este valor: en zona urbana, drenaje y
    electricidad rondan 95-99% en prácticamente cualquier AGEB (cobertura casi universal),
    así que arrastran el promedio hacia arriba sin importar el nivel real de la zona. Ver
    estimar_nivel_socioeconomico() para la clasificación correcta (por percentil, no
    absoluta)."""
    vivtot = totals.get("vivtot", 0.0)
    pobtot = totals.get("pobtot", 0.0)
    if vivtot <= 0 or pobtot <= 0:
        return None

    tasa_piso_firme = 100 * (1 - totals.get("vph_pisoti", 0.0) / vivtot)
    tasa_drenaje = 100 * totals.get("vph_drenaj", 0.0) / vivtot
    tasa_electricidad = 100 * totals.get("vph_c_elec", 0.0) / vivtot
    tasa_internet = 100 * totals.get("vph_inter", 0.0) / vivtot
    tasa_automovil = 100 * totals.get("vph_autom", 0.0) / vivtot
    tasa_escolaridad = 100 * (1 - totals.get("p15ym_se", 0.0) / pobtot)

    componentes = [tasa_piso_firme, tasa_drenaje, tasa_electricidad, tasa_internet, tasa_automovil, tasa_escolaridad]
    componentes = [max(0.0, min(100.0, c)) for c in componentes]
    return sum(componentes) / len(componentes)


def _percentiles_nse_estado() -> tuple[float, float, float] | None:
    """Calcula (p25, p50, p75) del índice socioeconómico bruto sobre TODOS los AGEBs de Baja
    California (los 7 municipios), para clasificar cada consulta por su posición relativa
    dentro del estado — no por un corte absoluto. Se recalcula en cada llamada (~1780 AGEBs,
    es rápido); no se cachea porque los datos pueden cambiar si se vuelve a correr run-etl."""
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute("SELECT * FROM inegi_censo WHERE cve_ent = ?;", (CVE_ENT_BC,)).fetchall()
    finally:
        conn.close()

    valores = []
    for row in rows:
        fila = {col: row[col] for col in NUMERIC_CENSO_COLUMNS}
        v = _indice_socioeconomico_bruto(fila)
        if v is not None:
            valores.append(v)
    if not valores:
        return None
    valores.sort()
    n = len(valores)
    return valores[int(n * 0.25)], valores[int(n * 0.5)], valores[int(n * 0.75)]


def estimar_nivel_socioeconomico(totals: dict[str, float]) -> dict | None:
    """Índice compuesto LOCAL (0-100) de nivel socioeconómico, construido únicamente con
    variables del Censo 2020 que ya tenemos por AGEB: acceso a servicios de la vivienda
    (drenaje, electricidad), bienes/conectividad del hogar (internet, automóvil), condición
    de la vivienda (piso firme) y escolaridad.

    La etiqueta Alto/Medio/Bajo/Muy bajo se asigna por PERCENTIL relativo a la distribución
    real de todos los AGEBs de Baja California (cuartiles, los 7 municipios), no por un
    umbral absoluto — un corte fijo (ej. ">=70 = Alto") clasificaba como "Alto" a más del 90%
    de la zona urbana, porque servicios básicos como drenaje/electricidad son casi
    universales ahí y no discriminan nada; con percentiles, "Alto" siempre significa "el 25%
    mejor posicionado del estado en este índice", una comparación relativa objetiva en vez de
    un estándar absoluto inventado.

    Esto NO es la clasificación oficial de Nivel Socioeconómico (NSE) de AMAI ni un producto
    de INEGI/DataMéxico — es un proxy simple calculable 100% offline con los datos ya
    cargados. Se debe mostrar siempre marcado como estimación/proxy, no como NSE oficial.
    Devuelve None si la zona no tiene viviendas/población (no se puede calcular ninguna tasa).
    """
    indice = _indice_socioeconomico_bruto(totals)
    if indice is None:
        return None

    percentiles = _percentiles_nse_estado()
    if percentiles is None:
        return {"indice": round(indice, 1), "nivel": "Sin referencia", "p25": None, "p50": None, "p75": None}

    p25, p50, p75 = percentiles
    return {
        "indice": round(indice, 1),
        "nivel": _clasificar_nivel(indice, percentiles),
        "p25": round(p25, 1),
        "p50": round(p50, 1),
        "p75": round(p75, 1),
    }


def _clasificar_nivel(indice: float, percentiles: tuple[float, float, float]) -> str:
    p25, p50, p75 = percentiles
    if indice >= p75:
        return "Alto"
    elif indice >= p50:
        return "Medio"
    elif indice >= p25:
        return "Bajo"
    return "Muy bajo"


def nse_por_ageb(cve_geos: list[str]) -> dict[str, str]:
    """Nivel socioeconómico (mismo proxy e igual de "no oficial" que estimar_nivel_
    socioeconomico, ver ese docstring) calculado POR CADA AGEB por separado — no el
    agregado de toda la zona, sino un color distinto por AGEB — para pintar el mapa como
    "semáforo" y ver de un vistazo qué partes de un municipio/zona grande son más altas o
    más bajas, en vez de un solo color promedio que esconde esa variación interna. Usa los
    mismos percentiles estatales que la versión agregada, así que un AGEB "Alto" aquí
    significa exactamente lo mismo que en el resto del agente. AGEBs sin datos suficientes
    (sin viviendas/población) simplemente no aparecen en el resultado."""
    if not cve_geos:
        return {}
    percentiles = _percentiles_nse_estado()
    if percentiles is None:
        return {}

    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(
            f"SELECT * FROM inegi_censo WHERE cve_geo IN ({placeholders});", cve_geos
        ).fetchall()
    finally:
        conn.close()

    niveles = {}
    for row in rows:
        fila = {col: row[col] for col in NUMERIC_CENSO_COLUMNS}
        indice = _indice_socioeconomico_bruto(fila)
        if indice is not None:
            niveles[row["cve_geo"]] = _clasificar_nivel(indice, percentiles)
    return niveles


# --- Capas de mapa de calor por AGEB (más allá de NSE) ---
# Cada capa "tasa" se muestra como "% sin/carencia de algo" — un valor SIEMPRE creciente con
# la carencia (mayor % = peor), calculado como 1 - (num/den) cuando el campo del censo mide
# cobertura ("tienen el servicio") o directamente num/den cuando ya mide la carencia
# ("no tienen"). Al clasificar en Alto/Medio/Bajo/Muy bajo se invierte el signo para que,
# igual que en NSE, "Alto" siga significando "mejor posicionado" (menos carencia) — nunca
# "alto en carencia", que confundiría leyendo la leyenda junto a la de NSE.
CAPAS_MAPA_TASA = {
    "sin_drenaje": {"etiqueta": "% viviendas sin drenaje", "num": "vph_drenaj", "den": "vivtot", "es_cobertura": True},
    "sin_internet": {"etiqueta": "% viviendas sin internet", "num": "vph_inter", "den": "vivtot", "es_cobertura": True},
    "sin_salud": {"etiqueta": "% población sin cobertura de salud", "num": "psinder", "den": "pobtot", "es_cobertura": False},
}
CAPAS_MAPA = {
    "nse": "Nivel socioeconómico (proxy, no oficial)",
    "poder_adquisitivo": "Poder adquisitivo estimado (proxy, no oficial)",
    "marginacion": "Marginación urbana (CONAPO, oficial)",
    "densidad": "Densidad de población (hab/km²)",
    **{k: v["etiqueta"] for k, v in CAPAS_MAPA_TASA.items()},
}


def _tasa_ageb(row: sqlite3.Row, campo_num: str, campo_den: str, es_cobertura: bool) -> float | None:
    """Fracción de CARENCIA (0-1, mayor = peor) — no de cobertura. Si el campo del censo ya
    mide cobertura (es_cobertura=True, ej. vph_drenaj = viviendas CON drenaje), se invierte
    aquí (1 - tasa) para que el resultado sea siempre "% sin/carencia de X", sin importar
    cómo esté orientado el campo original."""
    den = row[campo_den] or 0.0
    if den <= 0:
        return None
    tasa = (row[campo_num] or 0.0) / den
    return (1 - tasa) if es_cobertura else tasa


def _percentiles_tasa_estado(campo_num: str, campo_den: str, es_cobertura: bool) -> tuple[float, float, float] | None:
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute("SELECT * FROM inegi_censo WHERE cve_ent = ?;", (CVE_ENT_BC,)).fetchall()
    finally:
        conn.close()
    valores = [v for row in rows if (v := _tasa_ageb(row, campo_num, campo_den, es_cobertura)) is not None]
    if not valores:
        return None
    valores.sort()
    n = len(valores)
    return valores[int(n * 0.25)], valores[int(n * 0.5)], valores[int(n * 0.75)]


def _percentiles_densidad_estado() -> tuple[float, float, float] | None:
    conn = get_connection(SQLITE_DB_PATH)
    try:
        rows = conn.execute(
            """
            SELECT ic.pobtot, g.rings_json FROM inegi_censo ic
            JOIN inegi_geometrias g ON g.cve_geo = ic.cve_geo
            WHERE ic.cve_ent = ? AND g.rings_json IS NOT NULL;
            """,
            (CVE_ENT_BC,),
        ).fetchall()
    finally:
        conn.close()
    valores = []
    for row in rows:
        area = area_km2_multiring(json.loads(row["rings_json"]))
        if area > 0 and row["pobtot"]:
            valores.append(row["pobtot"] / area)
    if not valores:
        return None
    valores.sort()
    n = len(valores)
    return valores[int(n * 0.25)], valores[int(n * 0.5)], valores[int(n * 0.75)]


def capa_por_ageb(cve_geos: list[str], capa: str) -> dict[str, dict]:
    """Valor crudo + nivel (Alto/Medio/Bajo/Muy bajo, Alto=mejor siempre) por AGEB para
    cualquiera de las capas de CAPAS_MAPA — generaliza nse_por_ageb() a otras variables, para
    pintar el mapa de calor por la que el usuario elija en vez de solo NSE. 'marginacion' usa
    el grado OFICIAL de CONAPO (ya viene clasificado, no hay que calcular percentil); el
    resto usa percentiles estatales igual que NSE."""
    if not cve_geos or capa not in CAPAS_MAPA:
        return {}

    if capa in ("nse", "poder_adquisitivo"):
        # Mismo índice/percentiles que NSE (no hay una fuente distinta de poder adquisitivo
        # real por AGEB — ver estimar_nivel_socioeconomico()) pero como entrada de menú y
        # sección separada, a pedido explícito: aunque el cálculo de fondo sea el mismo, se
        # presentan como dos cosas distintas en la interfaz, no fusionadas en una.
        percentiles = _percentiles_nse_estado()
        if percentiles is None:
            return {}
        conn = get_connection(SQLITE_DB_PATH)
        try:
            placeholders = ",".join("?" for _ in cve_geos)
            rows = conn.execute(f"SELECT * FROM inegi_censo WHERE cve_geo IN ({placeholders});", cve_geos).fetchall()
        finally:
            conn.close()
        resultado = {}
        for row in rows:
            fila = {col: row[col] for col in NUMERIC_CENSO_COLUMNS}
            indice = _indice_socioeconomico_bruto(fila)
            if indice is not None:
                resultado[row["cve_geo"]] = {"valor": round(indice, 1), "nivel": _clasificar_nivel(indice, percentiles)}
        return resultado

    if capa == "marginacion":
        conn = get_connection(SQLITE_DB_PATH)
        try:
            placeholders = ",".join("?" for _ in cve_geos)
            rows = conn.execute(
                f"SELECT cve_geo, indice_normalizado, grado_marginacion FROM marginacion_ageb WHERE cve_geo IN ({placeholders});",
                cve_geos,
            ).fetchall()
        except sqlite3.OperationalError:
            return {}
        finally:
            conn.close()
        return {
            r["cve_geo"]: {"valor": round((r["indice_normalizado"] or 0) * 100, 1), "nivel": r["grado_marginacion"]}
            for r in rows if r["grado_marginacion"]
        }

    if capa == "densidad":
        percentiles = _percentiles_densidad_estado()
        if percentiles is None:
            return {}
        conn = get_connection(SQLITE_DB_PATH)
        try:
            placeholders = ",".join("?" for _ in cve_geos)
            rows = conn.execute(
                f"""
                SELECT ic.cve_geo, ic.pobtot, g.rings_json FROM inegi_censo ic
                JOIN inegi_geometrias g ON g.cve_geo = ic.cve_geo
                WHERE ic.cve_geo IN ({placeholders}) AND g.rings_json IS NOT NULL;
                """,
                cve_geos,
            ).fetchall()
        finally:
            conn.close()
        resultado = {}
        for row in rows:
            area = area_km2_multiring(json.loads(row["rings_json"]))
            if area > 0 and row["pobtot"]:
                densidad = row["pobtot"] / area
                # Densidad no es "mejor/peor" (una zona densa no es intrínsecamente mala), pero
                # se reusa la misma escala de 4 bandas para que el mapa de calor se lea con el
                # mismo lenguaje visual — aquí "Alto" significa "más densamente poblada".
                resultado[row["cve_geo"]] = {"valor": round(densidad, 1), "nivel": _clasificar_nivel(densidad, percentiles)}
        return resultado

    cfg = CAPAS_MAPA_TASA[capa]
    percentiles = _percentiles_tasa_estado(cfg["num"], cfg["den"], cfg["es_cobertura"])
    if percentiles is None:
        return {}
    # _tasa_ageb ya devuelve "% de carencia" (mayor = peor) en todos los casos — para que
    # "Alto" nivel siga significando "mejor posicionado" (menos carencia), se clasifica el
    # valor NEGADO contra los percentiles también negados (equivalente a invertir el orden).
    p25, p50, p75 = percentiles
    percentiles_para_clasificar = (-p75, -p50, -p25)

    conn = get_connection(SQLITE_DB_PATH)
    try:
        placeholders = ",".join("?" for _ in cve_geos)
        rows = conn.execute(f"SELECT * FROM inegi_censo WHERE cve_geo IN ({placeholders});", cve_geos).fetchall()
    finally:
        conn.close()
    resultado = {}
    for row in rows:
        tasa = _tasa_ageb(row, cfg["num"], cfg["den"], cfg["es_cobertura"])
        if tasa is None:
            continue
        resultado[row["cve_geo"]] = {
            "valor": round(tasa * 100, 1),
            "nivel": _clasificar_nivel(-tasa, percentiles_para_clasificar),
        }
    return resultado


def generar_reporte_xlsx(
    totals: dict[str, float],
    tipo_busqueda: str,
    valor_busqueda: str,
    agebs: list[dict] | None = None,
    colonias: list[dict] | None = None,
    municipio: str | None = None,
    radio_km: float | None = None,
) -> bytes:
    """Genera un .xlsx real (varias hojas, encabezados con color, columnas anchas, primera
    fila congelada) con la misma información que escribir_reporte_csv() — pensado para
    análisis (una fila por AGEB/colonia, no texto corrido), a diferencia del CSV que apila
    todo verticalmente en una sola hoja."""
    hoja_resumen = Hoja(nombre="Resumen", anchos_columnas=[34, 46], congelar_primera_fila=False)
    hoja_resumen.filas.append([
        Celda("Reporte de Análisis de Locación — INEGI", ESTILO_TITULO_SECCION),
        Celda("", ESTILO_TITULO_SECCION),
    ])
    hoja_resumen.filas.append([Celda("Tipo de búsqueda", ESTILO_NORMAL_NEGRITA), Celda(tipo_busqueda)])
    hoja_resumen.filas.append([Celda("Valor buscado", ESTILO_NORMAL_NEGRITA), Celda(valor_busqueda)])
    hoja_resumen.filas.append([
        Celda("Municipio", ESTILO_NORMAL_NEGRITA),
        Celda(municipio if municipio else "Todos (Baja California completa)"),
    ])
    if radio_km:
        hoja_resumen.filas.append([Celda("Radio de búsqueda (km)", ESTILO_NORMAL_NEGRITA), Celda(radio_km)])
    else:
        radio_equiv = estimar_radio_equivalente_km([a["cve_geo"] for a in agebs]) if agebs else None
        hoja_resumen.filas.append([
            Celda("Radio equivalente aproximado (km)", ESTILO_NORMAL_NEGRITA),
            Celda(round(radio_equiv, 2) if radio_equiv is not None else "N/D"),
        ])
    hoja_resumen.filas.append([Celda("Fuente", ESTILO_NORMAL_NEGRITA), Celda(FUENTE_DATOS)])
    hoja_resumen.filas.append([Celda("Fecha de datos", ESTILO_NORMAL_NEGRITA), Celda(FECHA_DATOS)])
    hoja_resumen.filas.append([
        Celda("Fecha de generación", ESTILO_NORMAL_NEGRITA),
        Celda(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ])
    hoja_resumen.filas.append([Celda(""), Celda("")])

    for categoria, variables in CATEGORIAS.items():
        hoja_resumen.filas.append([Celda(categoria.replace("_", " / "), ESTILO_TITULO_SECCION), Celda("", ESTILO_TITULO_SECCION)])
        hoja_resumen.filas.append([Celda("Indicador", ESTILO_ENCABEZADO_TABLA), Celda("Valor", ESTILO_ENCABEZADO_TABLA)])
        estimado = estimar_edades_15_59(totals) if categoria == "Poblacion" else None
        for var in variables:
            if var in VARIABLES_NO_DISPONIBLES_AGEB:
                if estimado is not None:
                    valor_est = round(estimado[f"{var}_est"], 2)
                    hoja_resumen.filas.append([
                        Celda(VARIABLE_LABELS[var]),
                        Celda(f"~{valor_est} (ESTIMADO, prorrateo municipal, no oficial a nivel AGEB)"),
                    ])
                else:
                    hoja_resumen.filas.append([Celda(VARIABLE_LABELS[var]), Celda("No publicado por INEGI a nivel AGEB")])
            else:
                hoja_resumen.filas.append([Celda(VARIABLE_LABELS[var]), Celda(round(totals.get(var, 0.0), 2))])
        if categoria == "Educacion_Socioeconomico":
            marg = obtener_marginacion([a["cve_geo"] for a in agebs]) if agebs else None
            if marg is not None:
                desglose = ", ".join(f"{n} {g}" for g, n in marg["conteo_grados"].items())
                hoja_resumen.filas.append([
                    Celda("Marginación urbana (CONAPO, índice OFICIAL)"),
                    Celda(f"{marg['grado_predominante']} — índice {marg['indice_normalizado_pct']}/100 — AGEBs: {desglose}"),
                ])
            nse = estimar_nivel_socioeconomico(totals)
            if nse is not None:
                # Mismo índice para ambas filas (no hay una fuente distinta de ingreso real
                # por AGEB), pero se listan como dos renglones separados a propósito.
                hoja_resumen.filas.append([
                    Celda("Nivel socioeconómico (índice estimado, no oficial)"),
                    Celda(f"{nse['indice']}/100 ({nse['nivel']}, percentil Baja California) — proxy local, no es NSE oficial AMAI/INEGI"),
                ])
                hoja_resumen.filas.append([
                    Celda("Poder adquisitivo estimado (proxy, no oficial)"),
                    Celda(f"{nse['indice']}/100 ({nse['nivel']}, percentil Baja California) — mismo índice que NSE, INEGI no publica ingreso real por AGEB"),
                ])
        elif categoria == "Salud":
            conteo_salud = contar_unidades_salud([a["cve_geo"] for a in agebs]) if agebs else None
            if conteo_salud is not None and conteo_salud["unidades_salud"] > 0:
                hoja_resumen.filas.append([
                    Celda("Unidades de salud, total (DENUE: sector SCIAN 62 + farmacias SCIAN 4641)"),
                    Celda(conteo_salud["unidades_salud"]),
                ])
                for cat in ORDEN_CATEGORIAS_DENUE:
                    n = conteo_salud["desglose"].get(cat)
                    if n:
                        hoja_resumen.filas.append([Celda(f"  {cat}"), Celda(n)])
            rec = obtener_recursos_hospitalarios([a["cve_geo"] for a in agebs]) if agebs else None
            if rec is not None:
                hoja_resumen.filas.append([
                    Celda("Hospitales privados con equipamiento verificado (ESEP, INEGI 2025)"),
                    Celda(rec["n_hospitales"]),
                ])
                for campo, etiqueta in ETIQUETAS_ESEP.items():
                    if rec[campo]:
                        hoja_resumen.filas.append([Celda(f"  {etiqueta}"), Celda(rec[campo])])
        hoja_resumen.filas.append([Celda(""), Celda("")])

    hojas = [hoja_resumen]

    if agebs:
        niveles = nse_por_ageb([a["cve_geo"] for a in agebs])
        # Columna "Municipio" agregada a partir de cve_geo (posiciones 2:5 = cve_mun) — sin
        # esto, una tabla dinámica no podría agrupar/filtrar por ciudad cuando el reporte junta
        # AGEBs de varios municipios (ej. zonas combinadas en /comparar).
        hoja_agebs = Hoja(nombre="AGEBs", anchos_columnas=[14, 18, 16, 16, 24], congelar_primera_fila=True)
        hoja_agebs.filas.append([
            Celda(h, ESTILO_ENCABEZADO_TABLA)
            for h in ("Clave AGEB", "Clave completa (cve_geo)", "Municipio", "Población total", "NSE / Poder adquisitivo (proxy)")
        ])
        for ageb in sorted(agebs, key=lambda a: a["cve_geo"]):
            hoja_agebs.filas.append([
                Celda(ageb["cve_ageb"]),
                Celda(ageb["cve_geo"]),
                Celda(MUNICIPIOS_BC.get(ageb["cve_geo"][2:5], "")),
                Celda(round(ageb["pobtot"], 2)),
                Celda(niveles.get(ageb["cve_geo"], "Sin datos suficientes")),
            ])
        hojas.append(hoja_agebs)

    if colonias:
        hoja_colonias = Hoja(nombre="Colonias-CP", anchos_columnas=[20, 14, 70], congelar_primera_fila=True)
        hoja_colonias.filas.append([Celda(h, ESTILO_ENCABEZADO_TABLA) for h in ("Municipio", "Código Postal", "Colonia(s)")])
        for c in colonias:
            hoja_colonias.filas.append([Celda(c["municipio"]), Celda(c["cp"] or ""), Celda(c["colonia"])])
        hojas.append(hoja_colonias)

    # Las siguientes hojas van en formato "tidy" (una fila por registro, mismas columnas en
    # todas las filas, sin encabezados de sección ni filas en blanco intercaladas) — pedido
    # explícito del usuario para poder armar tablas dinámicas sobre el Excel exportado, algo
    # que la hoja "Resumen" (pensada para leerse, no para pivotear) no permite.
    cve_geos_reporte = [a["cve_geo"] for a in agebs] if agebs else []

    if cve_geos_reporte:
        comercios = contar_comercios_referencia(cve_geos_reporte)
        if comercios and comercios["total"] > 0:
            hoja_comercios = Hoja(nombre="Comercios de referencia", anchos_columnas=[28, 14], congelar_primera_fila=True)
            hoja_comercios.filas.append([Celda(h, ESTILO_ENCABEZADO_TABLA) for h in ("Marca", "Cantidad")])
            for marca, n in sorted(comercios["desglose"].items(), key=lambda kv: -kv[1]):
                hoja_comercios.filas.append([Celda(marca), Celda(n)])
            hojas.append(hoja_comercios)

        cercanos = hospitales_cardio_cercanos(cve_geos_reporte)
        if cercanos:
            hoja_hosp = Hoja(
                nombre="Hospitales cercanos",
                anchos_columnas=[30, 10, 12, 14, 14, 12, 12, 60],
                congelar_primera_fila=True,
            )
            hoja_hosp.filas.append([
                Celda(h, ESTILO_ENCABEZADO_TABLA) for h in (
                    "Hospital", "Nivel", "Distancia (km)", "Quirófanos mín", "Quirófanos máx",
                    "Camas mín", "Camas máx", "Especialidades de cardiología",
                )
            ])
            for dist_km, h in cercanos:
                hoja_hosp.filas.append([
                    Celda(h["hospital"]), Celda(h["nivel"]), Celda(round(dist_km, 1)),
                    Celda(h["quirofanos_min"] or ""), Celda(h["quirofanos_max"] or ""),
                    Celda(h["camas_min"] or ""), Celda(h["camas_max"] or ""),
                    Celda(h["especialidades"] or ""),
                ])
            hojas.append(hoja_hosp)

        lab_cercanos = laboratorios_cercanos(cve_geos_reporte)
        if lab_cercanos:
            hoja_lab = Hoja(
                nombre="Laboratorios cercanos",
                anchos_columnas=[36, 22, 12, 14, 34, 36],
                congelar_primera_fila=True,
            )
            hoja_lab.filas.append([
                Celda(h, ESTILO_ENCABEZADO_TABLA) for h in (
                    "Laboratorio", "Cadena/marca", "Distancia (km)", "Colonia", "Dirección", "Teléfono",
                )
            ])
            for dist_km, lab in lab_cercanos:
                hoja_lab.filas.append([
                    Celda(lab["nombre"]), Celda(lab["cadena"]), Celda(round(dist_km, 1)),
                    Celda(lab["colonia"] or ""), Celda(lab["direccion"] or ""), Celda(lab["telefono"] or ""),
                ])
            hojas.append(hoja_lab)

        empresas_zona = empresas_en_zona(cve_geos_reporte)
        if empresas_zona:
            hoja_emp = Hoja(
                nombre="Empresas en la zona",
                anchos_columnas=[36, 18, 18, 30],
                congelar_primera_fila=True,
            )
            hoja_emp.filas.append([
                Celda(h, ESTILO_ENCABEZADO_TABLA) for h in ("Empresa", "Sector", "Empleados (est.)", "Colonia")
            ])
            for e in empresas_zona:
                hoja_emp.filas.append([
                    Celda(e["nombre"]), Celda(e["sector"] or ""),
                    Celda(e["empleados_estimados"] or ""), Celda(e["colonia"] or ""),
                ])
            hojas.append(hoja_emp)

    valor_zona = calcular_valor_zona_default(totals)
    if valor_zona is not None:
        hoja_valor = Hoja(nombre="Valor de la zona", anchos_columnas=[26, 12, 14, 18], congelar_primera_fila=True)
        hoja_valor.filas.append([
            Celda(h, ESTILO_ENCABEZADO_TABLA) for h in ("Frecuencia", "Tasa (%)", "Multiplicador", "Órdenes/año estimadas")
        ])
        for _id, etiqueta, tasa, mult, directo, _color in RETORNO_FRECUENCIAS:
            ordenes = valor_zona["poblacion_total"] * ((tasa if directo else tasa * mult) / 100)
            hoja_valor.filas.append([
                Celda(etiqueta), Celda(tasa), Celda("directo" if directo else mult), Celda(round(ordenes, 0)),
            ])
        hoja_valor.filas.append([
            Celda("TOTAL (todas las frecuencias)", ESTILO_NORMAL_NEGRITA), Celda(""), Celda(""),
            Celda(valor_zona["ordenes_anio"], ESTILO_NORMAL_NEGRITA),
        ])
        hoja_valor.filas.append([Celda("Población base"), Celda(round(valor_zona["poblacion_total"], 0))])
        hoja_valor.filas.append([Celda("Órdenes por día hábil (313 días/año)"), Celda(valor_zona["ordenes_dia"])])
        hoja_valor.filas.append([
            Celda("Nota"),
            Celda(
                "Estimado con TODAS las frecuencias marcadas y 0 pacientes actuales (default de la "
                "página web) — en el navegador puedes desmarcar frecuencias o capturar tus pacientes "
                "actuales para un cálculo ajustado a tu negocio; el Excel no puede reflejar esos ajustes "
                "interactivos."
            ),
        ])
        hojas.append(hoja_valor)

    if tipo_busqueda == "Municipio" and valor_busqueda:
        cve_mun_reporte = next((cve for cve, nom in MUNICIPIOS_BC.items() if nom == valor_busqueda), None)
        dato_mun = EIC2025_POBLACION_MUNICIPIOS.get(cve_mun_reporte) if cve_mun_reporte else None
        if dato_mun:
            nombre_mun, poblacion_mun, pct_estatal, edad_mediana_mun = dato_mun
            e = EIC2025_ESTATAL
            hoja_2025 = Hoja(nombre="Contexto 2025 (Intercensal)", anchos_columnas=[46, 24], congelar_primera_fila=True)
            hoja_2025.filas.append([Celda(h, ESTILO_ENCABEZADO_TABLA) for h in ("Indicador", "Valor")])
            hoja_2025.filas.append([Celda(f"Población de {nombre_mun} (2025)"), Celda(poblacion_mun)])
            hoja_2025.filas.append([Celda("% del total estatal"), Celda(pct_estatal)])
            hoja_2025.filas.append([Celda("Edad mediana (años)"), Celda(edad_mediana_mun)])
            hoja_2025.filas.append([Celda("Población BC en viviendas particulares (2025)"), Celda(e["poblacion_viviendas_particulares"])])
            hoja_2025.filas.append([
                Celda("Crecimiento vs. 2020 (%)"),
                Celda(round((e["poblacion_viviendas_particulares"] / e["poblacion_2020_viviendas_particulares"] - 1) * 100, 1)),
            ])
            hoja_2025.filas.append([Celda("% afiliado a algún servicio de salud (BC)"), Celda(e["pct_afiliacion_salud"])])
            hoja_2025.filas.append([Celda("Grado promedio de escolaridad (BC, años)"), Celda(e["grado_promedio_escolaridad"])])
            for etiqueta, pct in e["grupos_edad"].items():
                hoja_2025.filas.append([Celda(f"Grupo de edad: {etiqueta} (BC)"), Celda(pct)])
            for etiqueta, pct in e["afiliacion_por_institucion"].items():
                hoja_2025.filas.append([Celda(f"Afiliación salud: {etiqueta} (BC)"), Celda(pct)])
            for etiqueta, pct in e["sector_economico"].items():
                hoja_2025.filas.append([Celda(f"Sector económico: {etiqueta} (BC)"), Celda(pct)])
            hoja_2025.filas.append([
                Celda("Fuente"),
                Celda("INEGI, Encuesta Intercensal 2025 — cifras estatales/municipales, no combinables con el Censo 2020 por AGEB."),
            ])
            hojas.append(hoja_2025)

    return escribir_xlsx(hojas)


def escribir_reporte_csv(
    f,
    totals: dict[str, float],
    tipo_busqueda: str,
    valor_busqueda: str,
    agebs: list[dict] | None = None,
    colonias: list[dict] | None = None,
) -> None:
    """Escribe el reporte CSV completo (segmentos, marginación/NSE, salud, AGEBs incluidos y,
    si se da, la lista de colonias/CP) a un archivo o buffer de texto ya abierto `f` — separado
    de exportar_a_csv() para poder generarlo también en memoria (server.py, botón "Descargar
    CSV" de la web) sin tener que escribir a disco primero."""
    writer = csv.writer(f)
    writer.writerow(["Reporte de Análisis de Locación — INEGI"])
    writer.writerow(["Tipo de búsqueda", tipo_busqueda])
    writer.writerow(["Valor buscado", valor_busqueda])
    writer.writerow(["Fuente", FUENTE_DATOS])
    writer.writerow(["Fecha de datos", FECHA_DATOS])
    writer.writerow(["Fecha de generación", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    writer.writerow([])

    for categoria, variables in CATEGORIAS.items():
        writer.writerow([categoria.replace("_", " / ")])
        writer.writerow(["Indicador", "Valor"])
        estimado = estimar_edades_15_59(totals) if categoria == "Poblacion" else None
        for var in variables:
            if var in VARIABLES_NO_DISPONIBLES_AGEB:
                if estimado is not None:
                    valor_est = round(estimado[f"{var}_est"], 2)
                    writer.writerow([
                        VARIABLE_LABELS[var],
                        f"~{valor_est} (ESTIMADO, prorrateo municipal — no es dato oficial de INEGI a nivel AGEB)",
                    ])
                else:
                    writer.writerow([VARIABLE_LABELS[var], "No publicado por INEGI a nivel AGEB"])
            else:
                writer.writerow([VARIABLE_LABELS[var], round(totals.get(var, 0.0), 2)])
        if categoria == "Educacion_Socioeconomico":
            marg = obtener_marginacion([a["cve_geo"] for a in agebs]) if agebs else None
            if marg is not None:
                desglose = ", ".join(f"{n} {g}" for g, n in marg["conteo_grados"].items())
                writer.writerow([
                    "Marginación urbana (CONAPO, índice OFICIAL)",
                    f"{marg['grado_predominante']} — índice normalizado {marg['indice_normalizado_pct']}/100 "
                    f"(más alto = menos marginación) — AGEBs: {desglose}",
                ])
            nse = estimar_nivel_socioeconomico(totals)
            if nse is not None:
                ref = f" (percentiles Baja California: p25={nse['p25']}, p50={nse['p50']}, p75={nse['p75']})" if nse["p25"] is not None else ""
                # Mismo índice para ambas filas (no hay una fuente distinta de ingreso real
                # por AGEB), pero se listan como dos renglones separados a propósito.
                writer.writerow([
                    "Nivel socioeconómico (índice estimado, no oficial)",
                    f"{nse['indice']}/100 ({nse['nivel']}, por percentil relativo a Baja California){ref} — proxy local, "
                    "no es la clasificación oficial NSE de AMAI/INEGI",
                ])
                writer.writerow([
                    "Poder adquisitivo estimado (proxy, no oficial)",
                    f"{nse['indice']}/100 ({nse['nivel']}, por percentil relativo a Baja California){ref} — mismo índice "
                    "que NSE, INEGI no publica ingreso real por AGEB",
                ])
        elif categoria == "Salud":
            conteo_salud = contar_unidades_salud([a["cve_geo"] for a in agebs]) if agebs else None
            if conteo_salud is not None and conteo_salud["unidades_salud"] > 0:
                writer.writerow(["Unidades de salud, total (DENUE, INEGI: sector SCIAN 62 + farmacias SCIAN 4641)", conteo_salud["unidades_salud"]])
                for cat in ORDEN_CATEGORIAS_DENUE:
                    n = conteo_salud["desglose"].get(cat)
                    if n:
                        writer.writerow([f"  └ {cat}", n])
            rec = obtener_recursos_hospitalarios([a["cve_geo"] for a in agebs]) if agebs else None
            if rec is not None:
                writer.writerow([
                    "Hospitales privados con equipamiento verificado (ESEP, INEGI, encuesta 2025)",
                    rec["n_hospitales"],
                ])
                for campo, etiqueta in ETIQUETAS_ESEP.items():
                    if rec[campo]:
                        writer.writerow([f"  └ {etiqueta}", rec[campo]])
        writer.writerow([])

    if agebs:
        niveles = nse_por_ageb([a["cve_geo"] for a in agebs])
        writer.writerow([f"AGEBs incluidos en la consulta ({len(agebs)}) — para auditar contra INEGI"])
        writer.writerow(["Clave AGEB (cve_ageb)", "Clave completa (cve_geo)", "Población total (pobtot)", "NSE / Poder adquisitivo estimado (proxy, no oficial)"])
        for ageb in sorted(agebs, key=lambda a: a["cve_geo"]):
            writer.writerow([
                ageb["cve_ageb"], ageb["cve_geo"], round(ageb["pobtot"], 2),
                niveles.get(ageb["cve_geo"], "Sin datos suficientes"),
            ])
        writer.writerow([])

    if colonias:
        writer.writerow([f"Colonias/CP incluidas ({len(colonias)})"])
        writer.writerow(["Municipio", "Código Postal", "Colonia(s)"])
        for c in colonias:
            writer.writerow([c["municipio"], c["cp"] or "", c["colonia"]])
        writer.writerow([])

    cve_geos_reporte = [a["cve_geo"] for a in agebs] if agebs else []

    if cve_geos_reporte:
        comercios = contar_comercios_referencia(cve_geos_reporte)
        if comercios and comercios["total"] > 0:
            writer.writerow(["Comercios de referencia"])
            writer.writerow(["Marca", "Cantidad"])
            for marca, n in sorted(comercios["desglose"].items(), key=lambda kv: -kv[1]):
                writer.writerow([marca, n])
            writer.writerow([])

        cercanos = hospitales_cardio_cercanos(cve_geos_reporte)
        if cercanos:
            writer.writerow(["Hospitales privados con capacidad quirúrgica cerca de esta zona"])
            writer.writerow(["Hospital", "Nivel", "Distancia (km)", "Quirófanos mín", "Quirófanos máx", "Camas mín", "Camas máx", "Especialidades de cardiología"])
            for dist_km, h in cercanos:
                writer.writerow([
                    h["hospital"], h["nivel"], round(dist_km, 1),
                    h["quirofanos_min"] or "", h["quirofanos_max"] or "",
                    h["camas_min"] or "", h["camas_max"] or "", h["especialidades"] or "",
                ])
            writer.writerow([])

        lab_cercanos = laboratorios_cercanos(cve_geos_reporte)
        if lab_cercanos:
            writer.writerow(["Laboratorios de análisis cerca de esta zona"])
            writer.writerow(["Laboratorio", "Cadena/marca", "Distancia (km)", "Colonia", "Dirección", "Teléfono"])
            for dist_km, lab in lab_cercanos:
                writer.writerow([
                    lab["nombre"], lab["cadena"], round(dist_km, 1),
                    lab["colonia"] or "", lab["direccion"] or "", lab["telefono"] or "",
                ])
            writer.writerow([])

        empresas_zona = empresas_en_zona(cve_geos_reporte)
        if empresas_zona:
            writer.writerow(["Empresas con nómina alta (101+) en esta zona"])
            writer.writerow(["Empresa", "Sector", "Empleados (est.)", "Colonia"])
            for e in empresas_zona:
                writer.writerow([e["nombre"], e["sector"] or "", e["empleados_estimados"] or "", e["colonia"] or ""])
            writer.writerow([])

    valor_zona = calcular_valor_zona_default(totals)
    if valor_zona is not None:
        writer.writerow(["Valor de la zona (estimado, todas las frecuencias marcadas, 0 pacientes actuales)"])
        writer.writerow(["Frecuencia", "Tasa (%)", "Multiplicador", "Órdenes/año estimadas"])
        for _id, etiqueta, tasa, mult, directo, _color in RETORNO_FRECUENCIAS:
            ordenes = valor_zona["poblacion_total"] * ((tasa if directo else tasa * mult) / 100)
            writer.writerow([etiqueta, tasa, "directo" if directo else mult, round(ordenes, 0)])
        writer.writerow(["TOTAL", "", "", valor_zona["ordenes_anio"]])
        writer.writerow(["Población base", valor_zona["poblacion_total"]])
        writer.writerow(["Órdenes por día hábil (313 días/año)", valor_zona["ordenes_dia"]])
        writer.writerow([])

    if tipo_busqueda == "Municipio" and valor_busqueda:
        cve_mun_reporte = next((cve for cve, nom in MUNICIPIOS_BC.items() if nom == valor_busqueda), None)
        dato_mun = EIC2025_POBLACION_MUNICIPIOS.get(cve_mun_reporte) if cve_mun_reporte else None
        if dato_mun:
            nombre_mun, poblacion_mun, pct_estatal, edad_mediana_mun = dato_mun
            e = EIC2025_ESTATAL
            writer.writerow(["Contexto 2025 (Encuesta Intercensal, INEGI) — no combinable con el Censo 2020 por AGEB"])
            writer.writerow(["Indicador", "Valor"])
            writer.writerow([f"Población de {nombre_mun} (2025)", poblacion_mun])
            writer.writerow(["% del total estatal", pct_estatal])
            writer.writerow(["Edad mediana (años)", edad_mediana_mun])
            writer.writerow(["Población BC en viviendas particulares (2025)", e["poblacion_viviendas_particulares"]])
            writer.writerow(["% afiliado a algún servicio de salud (BC)", e["pct_afiliacion_salud"]])
            writer.writerow(["Grado promedio de escolaridad (BC, años)", e["grado_promedio_escolaridad"]])
            writer.writerow([])


def exportar_a_csv(
    totals: dict[str, float],
    tipo_busqueda: str,
    valor_busqueda: str,
    output_path: Path | None = None,
    agebs: list[dict] | None = None,
    colonias: list[dict] | None = None,
) -> Path:
    if output_path is None:
        safe_valor = "".join(c if c.isalnum() else "_" for c in valor_busqueda)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = OUTPUT_DIR / f"reporte_{tipo_busqueda}_{safe_valor}_{timestamp}.csv"

    with output_path.open("w", newline="", encoding="utf-8-sig") as f:
        escribir_reporte_csv(f, totals, tipo_busqueda, valor_busqueda, agebs, colonias)

    logger.info("Reporte exportado a %s", output_path)
    return output_path
