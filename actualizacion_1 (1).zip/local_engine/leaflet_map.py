"""Mapa interactivo con tiles reales (calles, relieve) vía Leaflet.js, servido 100% local
(sin CDN, sin llamadas de red en tiempo de uso) — ver local_engine/setup_mapa.py para cómo se
descargan los assets (una vez, con internet) antes de poder usar este renderer.

Se usa en vez del mapa SVG propio (local_engine/svg_map.py) cuando los assets ya están
descargados; server.py decide cuál de los dos usar según existan o no en disco.
"""
import json
import uuid

from config import TILE_MAX_ZOOM_DESCARGADO


def _bounds_zoom_sin_outliers(agebs_rings: dict[str, list], incluidos: set[str]) -> list[list[float]] | None:
    """Bounding box para el zoom inicial, IGNORANDO localidades sueltas muy alejadas del
    grueso de la zona consultada (p. ej. Ensenada o Mexicali tienen ejidos/localidades a
    decenas de km de la ciudad principal, dentro del mismo municipio) — si se usa el
    bounding box real de TODO lo incluido, esas localidades sueltas fuerzan un zoom-out
    enorme y la ciudad principal queda minúscula en una esquina. En vez de eso: se calcula
    el centro de masa de los AGEBs incluidos, se descarta el 10% más alejado de ese centro
    (percentil, no una lista fija de exclaves) y se ajusta el zoom a lo que queda — las
    localidades descartadas se siguen viendo en el mapa, solo no fuerzan el zoom inicial."""
    centroides = []
    for cve_geo in incluidos:
        rings = agebs_rings.get(cve_geo)
        if not rings or not rings[0]:
            continue
        anillo = rings[0]
        lon = sum(p[0] for p in anillo) / len(anillo)
        lat = sum(p[1] for p in anillo) / len(anillo)
        centroides.append((cve_geo, lon, lat))
    if not centroides:
        return None

    lon_medio = sum(c[1] for c in centroides) / len(centroides)
    lat_medio = sum(c[2] for c in centroides) / len(centroides)
    con_distancia = sorted(
        centroides, key=lambda c: (c[1] - lon_medio) ** 2 + (c[2] - lat_medio) ** 2
    )
    n_quedarse = max(1, int(len(con_distancia) * 0.9))
    cercanos = {c[0] for c in con_distancia[:n_quedarse]}

    puntos = [pt for cve_geo in cercanos for ring in agebs_rings.get(cve_geo, []) for pt in ring]
    if not puntos:
        return None
    lons = [p[0] for p in puntos]
    lats = [p[1] for p in puntos]
    return [[min(lats), min(lons)], [max(lats), max(lons)]]


def render_mapa_leaflet(
    agebs_rings: dict[str, list],
    incluidos: set[str],
    zonas_todas: list[dict],
    zonas_activas_ids: set,
    radio_km: float | None = None,
    color_incluido: str = "#3f6fb0",
    color_excluido: str = "#8f97a3",
    colores_por_ageb: dict[str, str] | None = None,
    gasolineras: list[dict] | None = None,
) -> str:
    """Devuelve (<div id="...">, <script>) como un solo string HTML: un mapa Leaflet con
    tiles OSM de fondo (calles, nombres, relieve real), los AGEBs de Tijuana como capa
    vectorial (resaltados los incluidos en la consulta) y un marcador clicable por cada zona
    coincidente (Colonia/CP), enlazado al mismo checkbox que ya usa el mapa SVG — para que el
    resto del formulario (incluir/excluir zona, recalcular) funcione igual sin cambios.

    colores_por_ageb: {cve_geo: color} opcional (típicamente el color de NSE de CADA AGEB,
    ver query_engine_local.nse_por_ageb) — si se da, cada AGEB incluido se pinta de SU propio
    color en vez de todos con color_incluido parejo; útil para ver de un vistazo qué zonas de
    un municipio/selección grande son más altas o más bajas, no solo el promedio de todo.

    gasolineras: [{nombre, lat, lon, precio_regular, precio_premium, precio_diesel}] opcional
    (ver query_engine_local.gasolineras_cercanas) — se dibujan con un ícono de diamante ⛽
    distinto de los círculos de "zona", para no confundirlas con el marcador del centro de
    búsqueda ni con los AGEBs coloreados."""
    centros = [z for z in zonas_todas if z["id"] in zonas_activas_ids]
    colores_por_ageb = colores_por_ageb or {}

    features = []
    for cve_geo, rings in agebs_rings.items():
        incluido = cve_geo in incluidos
        features.append({
            "type": "Feature",
            "properties": {
                "cve_geo": cve_geo,
                "incluido": incluido,
                "color": colores_por_ageb.get(cve_geo, color_incluido) if incluido else color_excluido,
            },
            "geometry": {"type": "Polygon", "coordinates": rings},
        })
    geojson = {"type": "FeatureCollection", "features": features}

    zonas_data = [
        {
            "id": z["id"],
            "lat": z["lat"],
            "lon": z["lon"],
            "titulo": f"CP {z['cp']} — {z['colonia']}",
            "activa": z["id"] in zonas_activas_ids,
        }
        for z in zonas_todas
    ]

    centro_lat_lon = None
    if centros:
        centro_lat_lon = [
            sum(c["lat"] for c in centros) / len(centros),
            sum(c["lon"] for c in centros) / len(centros),
        ]

    # Centro de respaldo (todo Tijuana) para cuando no hay zona/centro de búsqueda (p. ej.
    # consulta directa por AGEB) — necesario para poder llamar map.setView() ANTES de agregar
    # cualquier capa (ver MAPA_LEAFLET_SCRIPT: sin vista inicial, Leaflet truena al dibujar
    # los polígonos y toda la capa de AGEBs/marcadores/radio se queda sin mostrar).
    city_center = None
    todos_los_puntos = [pt for rings in agebs_rings.values() for ring in rings for pt in ring]
    if todos_los_puntos:
        lons = [p[0] for p in todos_los_puntos]
        lats = [p[1] for p in todos_los_puntos]
        city_center = [(min(lats) + max(lats)) / 2, (min(lons) + max(lons)) / 2]

    map_id = f"mapa-leaflet-{uuid.uuid4().hex[:8]}"
    config = {
        "geojson": geojson,
        "zonas": zonas_data,
        "radioKm": radio_km,
        "centro": centro_lat_lon,
        "cityCenter": city_center,
        "zoomBoundsSinOutliers": _bounds_zoom_sin_outliers(agebs_rings, incluidos),
        "tileMaxZoom": TILE_MAX_ZOOM_DESCARGADO,
        "colorIncluido": color_incluido,
        "colorExcluido": color_excluido,
        "gasolineras": gasolineras or [],
    }
    config_json = json.dumps(config, ensure_ascii=False)

    return (
        f'<div id="{map_id}" class="mapa-leaflet" data-config="{_html_attr_escape(config_json)}" '
        'style="width:100%;height:520px;border-radius:10px;border:1px solid var(--border);"></div>'
    )


def _html_attr_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;")


MAPA_LEAFLET_SCRIPT = """
<script>
(function () {
  function iniciarMapa(div) {
    if (typeof L === 'undefined') return; // leaflet.js no cargó (assets faltantes); no truena el resto de la página
    var cfg = JSON.parse(div.getAttribute('data-config'));
    var map = L.map(div, { scrollWheelZoom: false });
    // Leaflet necesita una vista (centro/zoom) ANTES de agregar capas vectoriales — si no,
    // internamente no puede calcular el recorte de los polígonos y truena en silencio (el
    // resto del script nunca corre: ni AGEBs resaltados, ni marcadores, ni círculo de radio).
    map.setView(cfg.centro || cfg.cityCenter || [32.5027, -117.0037], cfg.centro ? 14 : 11);
    L.tileLayer('/tiles/{z}/{x}/{y}.png', {
      // maxNativeZoom = zoom más alto realmente descargado (setup_mapa.py --zoom-max, 14 por
      // defecto); más allá de eso Leaflet AMPLÍA ese mismo tile en vez de pedir uno que no
      // existe (evita el fondo en blanco al acercarse mucho).
      maxNativeZoom: cfg.tileMaxZoom || 14, maxZoom: 19, minZoom: 3,
      attribution: '&copy; colaboradores de OpenStreetMap',
    }).addTo(map);

    var capaAgebs = L.geoJSON(cfg.geojson, {
      // feature.properties.color ya viene calculado del lado del servidor (color de NSE por
      // AGEB si se pidió, si no el color parejo de siempre) — el estilo aquí solo decide
      // grosor/opacidad según si el AGEB está incluido o no.
      style: function (feature) {
        var incluido = feature.properties.incluido;
        return {
          color: incluido ? '#ffffff' : cfg.colorExcluido,
          weight: incluido ? 1.5 : 0.6,
          fillColor: feature.properties.color,
          fillOpacity: incluido ? 0.65 : 0.12,
        };
      },
    }).addTo(map);

    if (cfg.radioKm && cfg.centro) {
      L.circle(cfg.centro, {
        radius: cfg.radioKm * 1000,
        color: cfg.colorIncluido, weight: 1.5, dashArray: '4 3',
        fillColor: cfg.colorIncluido, fillOpacity: 0.08,
      }).addTo(map);
    }

    cfg.zonas.forEach(function (z) {
      var marker = L.circleMarker([z.lat, z.lon], {
        radius: 7,
        color: '#fff', weight: 2,
        fillColor: z.activa ? '#c0392b' : '#8f97a3',
        fillOpacity: 1,
      }).addTo(map).bindTooltip(z.titulo);

      var checkbox = document.querySelector('input[name="zona"][value="' + z.id + '"]');
      if (!checkbox) return;
      marker.on('click', function () {
        checkbox.checked = !checkbox.checked;
        marker.setStyle({ fillColor: checkbox.checked ? '#c0392b' : '#8f97a3' });
        if (checkbox.form) {
          if (checkbox.form.requestSubmit) checkbox.form.requestSubmit();
          else checkbox.form.submit();
        }
      });
      checkbox.addEventListener('change', function () {
        marker.setStyle({ fillColor: checkbox.checked ? '#c0392b' : '#8f97a3' });
      });
    });

    // Gasolineras cercanas (ver query_engine_local.gasolineras_cercanas) — ícono de diamante
    // ⛽ distinto de los círculos de zona de arriba, para no confundirlas a simple vista.
    // Se agrupan en una sola capa (capaGasolineras) para poder prenderla/apagarla de un
    // jalón con el checkbox "Mostrar gasolineras" de la barra de herramientas del mapa,
    // en vez de tener que agregar/quitar cada marcador uno por uno.
    var capaGasolineras = L.layerGroup();
    (cfg.gasolineras || []).forEach(function (g) {
      var icono = L.divIcon({
        className: 'gas-icon-wrap',
        html: '<div class="gas-icon-diamond" style="background:#2f9e6f;"><span>⛽</span></div>',
        iconSize: [20, 20], iconAnchor: [10, 10], popupAnchor: [0, -10],
      });
      var precios = [];
      if (g.precio_regular) precios.push('Regular: $' + g.precio_regular);
      if (g.precio_premium) precios.push('Premium: $' + g.precio_premium);
      if (g.precio_diesel) precios.push('Diésel: $' + g.precio_diesel);
      // Marca comercial primero (lo que de verdad identifica la estación para quien ve el
      // mapa), razón social de CNE/CRE como subtítulo chico debajo — ver _gas_nombre_celda_html
      // en server.py, mismo criterio aplicado aquí para el popup del mapa.
      var tituloPopup = g.marca
        ? '<b>' + g.marca + '</b><div style="color:#8a8f98;font-size:0.78em;">' + g.nombre + '</div>'
        : '<b style="color:#8a8f98;font-style:italic;">Marca sin identificar</b><div style="color:#8a8f98;font-size:0.78em;">' + g.nombre + '</div>';
      L.marker([g.lat, g.lon], { icon: icono }).addTo(capaGasolineras).bindPopup(
        tituloPopup + (precios.length ? '<div style="color:#8a8f98;">' + precios.join(' · ') + '</div>' : '')
      );
    });
    var wrapGas = div.closest('.mapa-details');
    var toggleGas = wrapGas && wrapGas.querySelector('.mapa-gas-toggle');
    if ((cfg.gasolineras || []).length) {
      if (!toggleGas || toggleGas.checked) capaGasolineras.addTo(map);
      if (toggleGas) {
        toggleGas.addEventListener('change', function () {
          if (toggleGas.checked) capaGasolineras.addTo(map);
          else map.removeLayer(capaGasolineras);
        });
      }
    }

    var bounds = capaAgebs.getBounds();
    // Preferir el bounding box sin outliers calculado del lado del servidor (ver
    // _bounds_zoom_sin_outliers en leaflet_map.py) — evita que una localidad suelta muy
    // lejos de la ciudad principal fuerce un zoom-out enorme. Si no viene (zona chica, sin
    // AGEBs suficientes para el cálculo), cae al bounding box real de lo incluido.
    var boundsZoom;
    if (cfg.zoomBoundsSinOutliers) {
      boundsZoom = L.latLngBounds(cfg.zoomBoundsSinOutliers);
    } else {
      var incluidosLayer = L.geoJSON({
        type: 'FeatureCollection',
        features: cfg.geojson.features.filter(function (f) { return f.properties.incluido; }),
      });
      boundsZoom = incluidosLayer.getBounds();
    }
    if (boundsZoom.isValid()) {
      map.fitBounds(boundsZoom, { padding: [60, 60] });
    } else if (bounds.isValid()) {
      map.fitBounds(bounds);
    }

    var wrap = div.closest('.mapa-details');
    if (wrap) {
      var btnZona = wrap.querySelector('.mapa-centrar');
      if (btnZona) btnZona.addEventListener('click', function () {
        if (boundsZoom.isValid()) map.fitBounds(boundsZoom, { padding: [60, 60] });
      });
      var btnFull = wrap.querySelector('.mapa-completa');
      if (btnFull) btnFull.addEventListener('click', function () {
        if (bounds.isValid()) map.fitBounds(bounds);
      });
    }

    div.addEventListener('wheel', function (ev) {
      if (ev.ctrlKey || ev.metaKey) { map.scrollWheelZoom.enable(); }
    });
  }

  function iniciar() {
    document.querySelectorAll('.mapa-leaflet:not([data-activado])').forEach(function (div) {
      div.setAttribute('data-activado', '1');
      iniciarMapa(div);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
  document.addEventListener('toggle', function (ev) {
    if (ev.target.matches('.mapa-details')) iniciar();
  }, true);
})();
</script>
"""
